﻿using System;
using System.Windows.Forms;
using DXFReaderNET;
using DXFReaderNET.Entities;
using System.IO;
using System.Collections.Generic;
using Microsoft.Win32;
using System.Drawing;


namespace DXFReaderNETDemoProgram
{
#pragma warning disable IDE0016, IDE0017, IDE0018, IDE0032, IDE0028, IDE1006
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        #region declarations
        internal enum FunctionsEnum
        {
            None,
            Point,
            Line1,
            Line2,
            Lines,
            EntityProperties,
            GetEntity,
            GetGroupEntities,
            ListXdata,
            GetEntities,
            GetEntities1,
            GetEntities2,
            CopyEntities1,
            CopyEntities2,
            MoveEntitiesRubber1,
            MoveEntitiesRubber2,
            MoveEntitiesRubber3,
            MoveEntities1,
            MoveEntities2,
            RotateEntities,
            ScaleEntities,
            Circle1,
            Circle2,
            Circle2p1,
            Circle2p2,
            Circle3p1,
            Circle3p2,
            Circle3p3,
            Ellipse1,
            Ellipse2,
            Ellipse3,
            ZoomWindow1,
            ZoomWindow2,
            Pan1,
            Pan2,
            Distance1,
            Distance2,
            LocatePoint,
            Radius,
            Area,
            LwPolyline,
            Polyline,
            PolylineLenght,
            Spline,
            SetLimits1,
            SetLimits2,
            Ray1,
            Ray2,
            Xline1,
            Xline2,
            Rectangle1,
            Rectangle2,
            Trace1,
            Trace2,
            Solid1,
            Solid2,
            Solid3,
            Solid4,
            Polygon1,
            Polygon2,
            MoveEnt1,
            MoveEnt2,
            PlotWindow1,
            PlotWindow2,
            Image1,
            Image2,
            ImageFixedSize,
            PDFUnderlay,
            Hatch,
            HatchOutermost,
            HatchBoundaries,
            GradientHatch,
            GradientHatchOutermost,
            GradientHatchBoundaries,
            Arc1,
            Arc2,
            Arc3,
            ArcStartMiddleEnd1,
            ArcStartMiddleEnd2,
            ArcStartMiddleEnd3,
            DrawPoint,
            DrawLine1,
            DrawLine2,
            DrawCircle1,
            DrawCircle2,
            DrawArc1,
            DrawArc2,
            DrawArc3,
            DrawPolygon,
            DrawImage1,
            DrawImage2,
            DrawImageFixedSize,
            DrawText,
            ExplodeInsert,
            ExplodePoly,
            ExplodeCircle,
            ExplodeSpline,
            ExplodeSplineRect1,
            ExplodeSplineRect2,
            ExplodeArc,
            ExplodeEllipse,
            Offset1,
            Offset2,
            Block,
            Insert,
            RotateAxis1,
            RotateAxis2,
            Text,
            AlignedDimension1,
            AlignedDimension2,
            AlignedDimension3,
            AlignedDimensionLine1,
            AlignedDimensionLine2,
            LinearDimension1,
            LinearDimension2,
            LinearDimension3,
            LinearDimensionLine1,
            LinearDimensionLine2,
            AngularDimension2Lines1,
            AngularDimension2Lines2,
            AngularDimension2Lines3,
            AngularDimensionArc1,
            AngularDimensionArc2,
            AngularDimensionCenterStartEnd1,
            AngularDimensionCenterStartEnd2,
            AngularDimensionCenterStartEnd3,
            AngularDimensionCenterStartEnd4,
            DiametricDimension1,
            DiametricDimension2,
            RadialDimension1,
            RadialDimension2,
            WindowDrag
        }
        private string cmdCoord = "";
        private FunctionsEnum _CurrentFunction = FunctionsEnum.None;
        private FunctionsEnum CurrentFunction
        {
            get { return _CurrentFunction; }
            set
            {
                _CurrentFunction = value;
                ShowCommandLine();
            }
        }

        private Vector2 p = Vector2.Zero;
        private Vector2 p1 = Vector2.Zero;
        private Vector2 pstart = Vector2.Zero;
        private bool leftPressed = false;
        private Vector2 p2 = Vector2.Zero;
        private Vector2 p3 = Vector2.Zero;
        private Vector2 p4 = Vector2.Zero;
        private char decimalSeparetor = System.Globalization.CultureInfo.CurrentCulture.NumberFormat.NumberDecimalSeparator.ToCharArray()[0];
        private List<Vector2> vertexes = new List<Vector2>();
        private List<EntityObject> Boundary = new List<EntityObject>();
        private List<EntityObject> BoundaryOutermost = new List<EntityObject>();

        private Cyotek.Windows.Forms.ColorPickerDialog Cdialog = new Cyotek.Windows.Forms.ColorPickerDialog();
        private string CurrentLoadDXFPath = Application.StartupPath;
        private string CurrentLoadOBJPath = Application.StartupPath;
        private string CurrentSaveDXFPath = Application.StartupPath;
        private string CurrentSaveBMPPath = Application.StartupPath;
        private RubberBandType m_RubberBandType = RubberBandType.Solid;
        private Color m_RubberBandColor = Color.FromArgb(150, 150, 150);

        private bool OnPlotPreview = false;

        private double VideoSize = 0;

        private List<string> FileInfos = new List<string>();

        private short PolygonSides = 6;


        private EntityObject m_entOffset = null;
        private string m_ImageFileName = "";
        private string m_ImageRotation = "0";
        private string m_ImageTransparency = "0";
        private string m_PatternName = "SOLID";
        private string m_HatchRotation = "0";
        private string m_HatchBoundaries = "Choose entities";
        private string m_HatchScale = "1";
        private string m_newBlockName = "";
        private string m_BlockName = "";
        private string m_BlockRotation = "0";
        private string m_BlockScale = "1";
        private string m_Text = "";
        private string m_DrawText = "";
        private double m_DrawTextHeight = 2.5;

        private string m_GradientPatternName = "Linear";
        private string m_GradientHatchRotation = "0";
        private string m_GradientHatchBoundaries = "Choose entities";
        private bool m_GradientHatchCentered = true;
        private short m_GradientAciColor1 = 1;
        private short m_GradientAciColor2 = 5;

        private string m_PDFFileName = "";
        private string m_PDFRotation = "0";
        private string m_PDFScale = "1";
        private string m_PDFTransparency = "0";

        private Color CurrentDrawColor = Color.Red;
        private float CurrentDrawPenWidth = 0;
        private string CurrentDrawPenStyle = "Continuous";
        private float CurrentDrawDashLength = 10;
        private float CurrentDrawSkipLength = 10;

        private Pen DrawPen;
        private Vector2 screenP;
        private double m_rotation = 0;
        private double m_scale = 1;
        private double m_offset = 0;

        private int m_ImageWidth = 0;
        private int m_ImageHeight = 0;
        private bool m_ImageScaleOnScreen = true;

        private EntityObject m_LastAddedEntity = null;
        private EntityObject SelectedEntity = null;
        private Line SelectedLine = null;
        private Line SelectedLine1 = null;

        private List<HatchPattern> hatchPatternsCustom = new List<HatchPattern>();

        #endregion


        private void TestRoutine()
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

            LoadRegistry();

            dxfReaderNETControl1.NewDrawing();

            InitDrawing();
#if DEBUG
            ribbonButtonInquiryTest.Visible = true;
            ribbonComboBoxLayout.Visible = true;
            ribbonButtonCommandLine.Visible = true;
            ribbonButtonTest3.Visible = true;
#endif
        }



        private void InitDrawing()
        {
            dxfReaderNETControl1.Dock = DockStyle.Fill;
            //printPreviewControl1.Dock = DockStyle.Fill;
            dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHair;
            StatusLabel.Text = "";
            StatusLabelX.Text = "";
            StatusLabelY.Text = "";
            toolStripStatusLabelInfo.Text = "";
            StatusLabelGrid.Text = "";
            CurrentFunction = FunctionsEnum.None;

            this.Text = "DXFReader.NET Component - Demo Program";
            ribbonColors();
            ////////////////////////////////////////////////////////////////////////
            ribbonComboBoxLayers.DropDownItems.Clear();
            ribbonComboBoxLayers.DrawIconsBar = false;
            foreach (DXFReaderNET.Tables.Layer layer in dxfReaderNETControl1.DXF.Layers)
            {
                RibbonButton newItem = new RibbonButton();
                newItem.Text = layer.Name;
                ribbonComboBoxLayers.DropDownItems.Add(newItem);
                if (dxfReaderNETControl1.DXF.CurrentLayer == layer.Name)
                {
                    ribbonComboBoxLayers.SelectedItem = newItem;
                }
            }

            ////////////////////////////////////////////////////////////////////////

            ////////////////////////////////////////////////////////////////////////
            ribbonButtonModPropLayer.DropDownItems.Clear();

            foreach (DXFReaderNET.Tables.Layer layer in dxfReaderNETControl1.DXF.Layers)
            {
                RibbonButton newItem = new RibbonButton();
                newItem.Text = layer.Name;
                ribbonButtonModPropLayer.DropDownItems.Add(newItem);

            }

            ////////////////////////////////////////////////////////////////////////

            ///////////////////////////////////////////////////////////////////////////
            ribbonButtonModPropLineType.DropDownItems.Clear();

            foreach (DXFReaderNET.Tables.Linetype linetype in dxfReaderNETControl1.DXF.Linetypes)
            {
                RibbonButton newItem = new RibbonButton();
                newItem.Text = linetype.Name;
                ribbonButtonModPropLineType.DropDownItems.Add(newItem);

            }

            ///////////////////////////////////////////////////////////////////////////


            for (int k = ribbonButtonModPropGroup.DropDownItems.Count - 1; k > 0; k--)
            {
                ribbonButtonModPropGroup.DropDownItems.Remove(ribbonButtonModPropGroup.DropDownItems[k]);
            }


            foreach (DXFReaderNET.Objects.Group _group in dxfReaderNETControl1.DXF.Groups)
            {
                RibbonButton newItem = new RibbonButton();
                newItem.Text = _group.Name;
                ribbonButtonModPropGroup.DropDownItems.Add(newItem);

            }

            ////////////////////////////////////////////////////////////////////////

            ribbonComboBoxDimensionStyle.DropDownItems.Clear();
            foreach (DXFReaderNET.Tables.DimensionStyle _dimStyle in dxfReaderNETControl1.DXF.DimensionStyles.Items)
            {
                RibbonButton newItem = new RibbonButton();
                newItem.Text = _dimStyle.Name;
                ribbonComboBoxDimensionStyle.DropDownItems.Add(newItem);
                if (dxfReaderNETControl1.DXF.DrawingVariables.DimStyle.ToLower() == _dimStyle.Name.ToLower())
                {
                    ribbonComboBoxDimensionStyle.SelectedItem = newItem;
                }
            }

            ////////////////////////////////////////////////////////////////////////


            ribbonComboBoxTextStyle.DropDownItems.Clear();
            foreach (DXFReaderNET.Tables.TextStyle _TableSymbol in dxfReaderNETControl1.DXF.TextStyles.Items)
            {
                RibbonButton newItem = new RibbonButton();
                newItem.Text = _TableSymbol.Name;
                ribbonComboBoxTextStyle.DropDownItems.Add(newItem);
                if (dxfReaderNETControl1.DXF.CurrentTextStyle.ToLower() == _TableSymbol.Name.ToLower())
                {
                    ribbonComboBoxTextStyle.SelectedItem = newItem;
                }
            }

            ////////////////////////////////////////////////////////////////////////


            ribbonComboBoxViews.DropDownItems.Clear();
            foreach (DXFReaderNET.Tables.View view in dxfReaderNETControl1.DXF.Views)
            {
                RibbonButton newItem = new RibbonButton();
                newItem.Text = view.Name;
                ribbonComboBoxViews.DropDownItems.Add(newItem);
            }

            ////////////////////////////////////////////////////////////////////////

            ribbonComboBoxLineTypes.DropDownItems.Clear();
            ribbonComboBoxLineTypes.DrawIconsBar = false;
            foreach (DXFReaderNET.Tables.Linetype linetype in dxfReaderNETControl1.DXF.Linetypes)
            {
                RibbonButton newItem = new RibbonButton();
                newItem.Text = linetype.Name;
                //if (linetype.Description.Trim() != "")
                //{
                //    newItem.Text += " - " + linetype.Description.Trim();

                //}
                ribbonComboBoxLineTypes.DropDownItems.Add(newItem);
                if (dxfReaderNETControl1.DXF.CurrentLineTypeName == linetype.Name)
                {
                    ribbonComboBoxLineTypes.SelectedItem = newItem;
                }
            }

            ////////////////////////////////////////////////////////////////////////


            ribbonComboBoxLayout.DropDownItems.Clear();
            foreach (DXFReaderNET.Objects.Layout _layout in dxfReaderNETControl1.DXF.Layouts)
            {
                RibbonButton newItem = new RibbonButton();
                newItem.Text = _layout.Name;
                ribbonComboBoxLayout.DropDownItems.Add(newItem);

                if (dxfReaderNETControl1.DXF.ActiveLayout == _layout.Name)

                {
                    ribbonComboBoxLayout.SelectedItem = newItem;
                }

            }

            ////////////////////////////////////////////////////////////////////////
            ribbonComboBox3D.Image = ribbonButtonView3DTop.LargeImage;
            ribbonComboBox3D.TextBoxText = "";

            ribbonComboBoxRendering.Image = ribbonButtonRenderingWireframe.SmallImage;

            ribbonColorChooserColor.Color = dxfReaderNETControl1.DXF.CurrentColor.ToColor();
            ribbonLabelCurrentColor.Text = dxfReaderNETControl1.DXF.CurrentColor.ToString();



            ribbonTextBoxElevation.TextBoxText = MathHelper.ToFormattedUnit(dxfReaderNETControl1.DXF.CurrentElevation);
            ribbonTextBoxThickness.TextBoxText = MathHelper.ToFormattedUnit(dxfReaderNETControl1.DXF.CurrentThickness);
            ribbonTextBoxLtScale.TextBoxText = MathHelper.ToFormattedUnit(dxfReaderNETControl1.DXF.CurrentLineTypeScale);

            ////////////////////////////////////////////////////////////////////////
            switch (dxfReaderNETControl1.PlotMode)
            {
                case PlotModeType.Display:
                    ribbonComboBoxPlotMode.SelectedItem = ribbonButtonPlotModeDisplay;
                    break;
                case PlotModeType.Extents:
                    ribbonComboBoxPlotMode.SelectedItem = ribbonButtonPlotModeExtents;
                    break;
                case PlotModeType.Limits:
                    ribbonComboBoxPlotMode.SelectedItem = ribbonButtonPlotModeLimits;
                    break;
                case PlotModeType.Window:
                    ribbonComboBoxPlotMode.SelectedItem = ribbonButtonPlotModeWindow;
                    break;
            }

            ////////////////////////////////////////////////////////////////////////
            switch (dxfReaderNETControl1.PlotRendering)
            {
                case PlotRenderingType.GrayScale:
                    ribbonComboBoxPlotRendering.SelectedItem = ribbonButtonPlotRenderingGrayScale;
                    break;
                case PlotRenderingType.Monochrome:
                    ribbonComboBoxPlotRendering.SelectedItem = ribbonButtonPlotRenderingMonochrome;
                    break;
                case PlotRenderingType.Color:
                    ribbonComboBoxPlotRendering.SelectedItem = ribbonButtonPlotRenderingColor;
                    break;

            }
            ////////////////////////////////////////////////////////////////////////
            switch (dxfReaderNETControl1.PlotRotation)
            {
                case PlotOrientationType.Portrait:
                    ribbonComboBoxPlotRotation.SelectedItem = ribbonButtonPlotRotationPortrait;
                    break;
                case PlotOrientationType.Landscape:
                    ribbonComboBoxPlotRotation.SelectedItem = ribbonButtonPlotRotationLandscape;
                    break;


            }

            ////////////////////////////////////////////////////////////////////////
            switch (dxfReaderNETControl1.PlotUnits)
            {
                case PlotUnitsType.Millimeters:
                    ribbonComboBoxPlotUnits.SelectedItem = ribbonButtonPlotUnitsMillimeters;
                    break;
                case PlotUnitsType.Inchs:
                    ribbonComboBoxPlotUnits.SelectedItem = ribbonButtonPlotUnitsInchs;
                    break;


            }
            ////////////////////////////////////////////////////////////////////////
            switch (dxfReaderNETControl1.PlotUnits)
            {
                case PlotUnitsType.Millimeters:
                    ribbonUpDownPlotMarginTop.TextBoxText = dxfReaderNETControl1.PlotMarginTop.ToString("###0");
                    ribbonUpDownPlotMarginBottom.TextBoxText = dxfReaderNETControl1.PlotMarginBottom.ToString("###0");
                    ribbonUpDownPlotMarginLeft.TextBoxText = dxfReaderNETControl1.PlotMarginLeft.ToString("###0");
                    ribbonUpDownPlotMarginRight.TextBoxText = dxfReaderNETControl1.PlotMarginRight.ToString("###0");
                    ribbonTextBoxPlotOriginX.TextBoxText = dxfReaderNETControl1.PlotOffset.X.ToString("###0");
                    ribbonTextBoxPlotOriginY.TextBoxText = dxfReaderNETControl1.PlotOffset.Y.ToString("###0");
                    break;
                case PlotUnitsType.Inchs:
                    ribbonUpDownPlotMarginTop.TextBoxText = dxfReaderNETControl1.PlotMarginTop.ToString("#0.0");
                    ribbonUpDownPlotMarginBottom.TextBoxText = dxfReaderNETControl1.PlotMarginBottom.ToString("#0.0");
                    ribbonUpDownPlotMarginLeft.TextBoxText = dxfReaderNETControl1.PlotMarginLeft.ToString("#0.0");
                    ribbonUpDownPlotMarginRight.TextBoxText = dxfReaderNETControl1.PlotMarginRight.ToString("#0.0");
                    ribbonTextBoxPlotOriginX.TextBoxText = dxfReaderNETControl1.PlotOffset.X.ToString("#0.00");
                    ribbonTextBoxPlotOriginY.TextBoxText = dxfReaderNETControl1.PlotOffset.Y.ToString("#0.00");

                    break;

            }
            ribbonUpDownPlotPenWidth.TextBoxText = MathHelper.ToFormattedUnit(dxfReaderNETControl1.PlotPenWidth);
            ribbonTextBoxPlotScale.TextBoxText = dxfReaderNETControl1.PlotScale.ToString();


            ShowStatusLabels();

        }


        private void ribbonColors()
        {
            ribbonColorChooserForeColor.Color = dxfReaderNETControl1.ForeColor;
            ribbonColorChooserBackColor.Color = dxfReaderNETControl1.BackColor;

            ribbonColorChooserGrid.Color = dxfReaderNETControl1.GridColor;
            ribbonColorChooserAxes.Color = dxfReaderNETControl1.AxesColor;
            ribbonColorChooserAxisX.Color = dxfReaderNETControl1.AxisXColor;
            ribbonColorChooserAxisY.Color = dxfReaderNETControl1.AxisYColor;
            ribbonColorChooserAxisZ.Color = dxfReaderNETControl1.AxisZColor;

            ribbonColorChooserHighlight.Color = dxfReaderNETControl1.HighlightColor;
            ribbonColorChooserHighlightMarker.Color = dxfReaderNETControl1.HighlightMarkerColor;
            ribbonColorChooserHighlightMarker2.Color = dxfReaderNETControl1.HighlightMarkerColor2;
            ribbonColorChooserRubberBand.Color = m_RubberBandColor;


            ribbonButtonShowAxes.Checked = dxfReaderNETControl1.ShowAxes;
            ribbonButtonShowBasepoint.Checked = dxfReaderNETControl1.ShowBasePoint;
            ribbonButtonShowLimits.Checked = dxfReaderNETControl1.ShowLimits;
            ribbonButtonShowgrid.Checked = dxfReaderNETControl1.ShowGrid;
            ribbonButtonGridRuler.Checked = dxfReaderNETControl1.ShowGridRuler;
            ribbonButtonAntialias.Checked = dxfReaderNETControl1.AntiAlias;
            ribbonColorChooserDrawMethodsColor.Color = CurrentDrawColor;


        }

        private void ShowStatusLabels()
        {

            if (dxfReaderNETControl1.ShowGrid)
            {
                StatusLabelGrid.Image = imageListStatusBar.Images[1];
            }
            else
            {
                StatusLabelGrid.Image = imageListStatusBar.Images[0];
            }


            if (dxfReaderNETControl1.DXF.DrawingVariables.OrthoMode != 0)
            {
                StatusLabelOrtho.Image = imageListStatusBar.Images[3];
            }
            else
            {
                StatusLabelOrtho.Image = imageListStatusBar.Images[2];
            }


            if (dxfReaderNETControl1.DXF.VPorts["*Active"].SnapMode)
            {
                StatusLabelSnap.Image = imageListStatusBar.Images[5];
            }
            else
            {
                StatusLabelSnap.Image = imageListStatusBar.Images[4];
            }



        }


        private void ribbonButton1_Click(object sender, EventArgs e)
        {
            openFileDialog1.DefaultExt = "dxf";
            openFileDialog1.Filter = "DXF|*.dxf|All files (*.*)|*.*";
            openFileDialog1.FileName = "";

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                if (!dxfReaderNETControl1.ReadDXF(openFileDialog1.FileName))
                {

                    dxfReaderNETControl1.NewDrawing();
                }
                InitDrawing();

            }
        }

        private void ribbonButton6_Click(object sender, EventArgs e)
        {
            dxfReaderNETControl1.ZoomExtents();
        }

        private void ribbonButton5_Click(object sender, EventArgs e)
        {
            dxfReaderNETControl1.ZoomLimits();
        }

        private void dxfReaderNETControl1_MouseMove(object sender, MouseEventArgs e)
        {

            p = dxfReaderNETControl1.CurrentWCSpoint;
            StatusLabelX.Text = "x: " + dxfReaderNETControl1.DXF.ToFormattedUnit(p.X);
            StatusLabelY.Text = "y: " + dxfReaderNETControl1.DXF.ToFormattedUnit(p.Y);

            if (e.Button == MouseButtons.Left && CurrentFunction == FunctionsEnum.None)
            {
                dxfReaderNETControl1.ShowRubberBandBox(pstart, p);
                leftPressed = true;
            }

            switch (CurrentFunction)
            {

                case FunctionsEnum.DiametricDimension2:
                    dxfReaderNETControl1.ShowRubberBandLine(((Circle)SelectedEntity).Center.ToVector2(), p, m_RubberBandColor, m_RubberBandType);


                    break;

                case FunctionsEnum.LinearDimensionLine2:

                    double rotation = 0;
                    if (SelectedLine.StartPoint.X < SelectedLine.EndPoint.X)
                    {
                        if (p.X > SelectedLine.EndPoint.X || p.X < SelectedLine.StartPoint.X)
                        {
                            rotation = 90;
                        }
                    }
                    else
                    {
                        if (p.X < SelectedLine.EndPoint.X || p.X > SelectedLine.StartPoint.X)
                        {
                            rotation = 90;
                        }
                    }

                    dxfReaderNETControl1.ShowRubberBandLinearDimension(SelectedLine, p, rotation, m_RubberBandColor, m_RubberBandType);


                    break;

                case FunctionsEnum.LinearDimension3:

                    rotation = 0;

                    if (p.X > p2.X || p.X < p1.X)
                    {
                        rotation = 90;

                    }

                    dxfReaderNETControl1.ShowRubberBandLinearDimension(p1, p2, p, rotation, m_RubberBandColor, m_RubberBandType);


                    break;

                case FunctionsEnum.AlignedDimensionLine2:
                    dxfReaderNETControl1.ShowRubberBandAlignedDimension(SelectedLine, p, m_RubberBandColor, m_RubberBandType);
                    break;
                case FunctionsEnum.AlignedDimension3:
                    dxfReaderNETControl1.ShowRubberBandAlignedDimension(p1, p2, p, m_RubberBandColor, m_RubberBandType);
                    break;
                case FunctionsEnum.GradientHatchBoundaries:
                case FunctionsEnum.HatchBoundaries:
                case FunctionsEnum.Spline:
                case FunctionsEnum.Lines:
                case FunctionsEnum.PolylineLenght:
                case FunctionsEnum.Polyline:
                case FunctionsEnum.LwPolyline:
                case FunctionsEnum.Area:
                case FunctionsEnum.DrawPolygon:
                    if (vertexes.Count > 0)
                    {

                        dxfReaderNETControl1.ShowRubberBandLine(vertexes[vertexes.Count - 1], p, null, RubberBandType.Dashed, true);
                        toolStripStatusLabelInfo.Text = "Distance: " + MathHelper.ToFormattedUnit(Vector2.Distance(vertexes[vertexes.Count - 1], p));
                    }
                    break;
                case FunctionsEnum.DrawImageFixedSize:
                case FunctionsEnum.ImageFixedSize:

                    dxfReaderNETControl1.ShowRubberBandBox(p, m_ImageWidth, m_ImageHeight);


                    break;

                case FunctionsEnum.SetLimits2:
                case FunctionsEnum.ZoomWindow2:
                case FunctionsEnum.Image2:
                case FunctionsEnum.DrawImage2:
                case FunctionsEnum.MoveEntitiesRubber2:
                case FunctionsEnum.PlotWindow2:
                case FunctionsEnum.GetEntities2:
                case FunctionsEnum.Rectangle2:
                case FunctionsEnum.ExplodeSplineRect2:
                    dxfReaderNETControl1.ShowRubberBandBox(p1, p);
                    toolStripStatusLabelInfo.Text = "Delta X: " + MathHelper.ToFormattedUnit(p.X - p1.X) + " Delta Y: " + MathHelper.ToFormattedUnit(p.Y - p1.Y);
                    break;

                case FunctionsEnum.Pan2:
                case FunctionsEnum.Distance2:

                    dxfReaderNETControl1.ShowRubberBandLine(p1, p);
                    toolStripStatusLabelInfo.Text = "Distance: " + MathHelper.ToFormattedUnit(Vector2.Distance(p1, p));
                    break;
                case FunctionsEnum.CopyEntities2:

                case FunctionsEnum.DrawLine2:
                case FunctionsEnum.Line2:
                case FunctionsEnum.Arc2:
                case FunctionsEnum.DrawArc2:
                case FunctionsEnum.Trace2:
                case FunctionsEnum.Circle3p2:
                case FunctionsEnum.AlignedDimension2:
                case FunctionsEnum.LinearDimension2:

                    dxfReaderNETControl1.ShowRubberBandLine(p1, p);
                    toolStripStatusLabelInfo.Text = "Distance: " + MathHelper.ToFormattedUnit(Vector2.Distance(p1, p)) + " Delta X: " + MathHelper.ToFormattedUnit(p.X - p1.X) + " Delta Y: " + MathHelper.ToFormattedUnit(p.Y - p1.Y);
                    break;

                case FunctionsEnum.MoveEntities2:
                    dxfReaderNETControl1.ShowRubberBandEntities(dxfReaderNETControl1.DXF.SelectedEntities, p - p1, m_RubberBandColor, m_RubberBandType);
                    break;
                case FunctionsEnum.Solid2:

                    dxfReaderNETControl1.ShowRubberBandLine(p1, p, m_RubberBandColor, m_RubberBandType, true);
                    toolStripStatusLabelInfo.Text = "Distance: " + MathHelper.ToFormattedUnit(Vector2.Distance(p1, p)) + " Delta X: " + MathHelper.ToFormattedUnit(p.X - p1.X) + " Delta Y: " + MathHelper.ToFormattedUnit(p.Y - p1.Y);
                    break;
                case FunctionsEnum.Solid3:

                    dxfReaderNETControl1.ShowRubberBandLine(p2, p, m_RubberBandColor, m_RubberBandType, true);
                    toolStripStatusLabelInfo.Text = "Distance: " + MathHelper.ToFormattedUnit(Vector2.Distance(p2, p)) + " Delta X: " + MathHelper.ToFormattedUnit(p.X - p2.X) + " Delta Y: " + MathHelper.ToFormattedUnit(p.Y - p2.Y);
                    break;
                case FunctionsEnum.Solid4:

                    dxfReaderNETControl1.ShowRubberBandLine(p3, p, m_RubberBandColor, m_RubberBandType, true);
                    toolStripStatusLabelInfo.Text = "Distance: " + MathHelper.ToFormattedUnit(Vector2.Distance(p3, p)) + " Delta X: " + MathHelper.ToFormattedUnit(p.X - p3.X) + " Delta Y: " + MathHelper.ToFormattedUnit(p.Y - p3.Y);
                    break;

                case FunctionsEnum.DrawCircle2:

                case FunctionsEnum.Circle2:

                    dxfReaderNETControl1.ShowRubberBandCircle(p1, Vector2.Distance(p1, p));
                    toolStripStatusLabelInfo.Text = "Radius: " + MathHelper.ToFormattedUnit(Vector2.Distance(p1, p));
                    break;


                case FunctionsEnum.Insert:
                    List<EntityObject> blockEntities = new List<EntityObject>();
                    foreach (EntityObject entity in dxfReaderNETControl1.DXF.Blocks[m_BlockName].Entities)
                    {
                        blockEntities.Add((EntityObject)entity.Clone());
                    }
                    dxfReaderNETControl1.ShowRubberBandEntities(blockEntities, p - dxfReaderNETControl1.DXF.Blocks[m_BlockName].Origin.ToVector2());

                    break;

                case FunctionsEnum.MoveEntitiesRubber3:

                    dxfReaderNETControl1.ShowRubberBandEntities(dxfReaderNETControl1.DXF.SelectedEntities, p - p2, m_RubberBandColor, m_RubberBandType);

                    break;
                case FunctionsEnum.MoveEnt2:

                    switch (SelectedEntity.Type)
                    {
                        case EntityType.Line:
                            dxfReaderNETControl1.ShowRubberBandLine(((Line)SelectedEntity).StartPoint.ToVector2() + p - p1, ((Line)SelectedEntity).EndPoint.ToVector2() + p - p1);

                            break;
                        case EntityType.Arc:
                            dxfReaderNETControl1.ShowRubberBandArc(((Arc)SelectedEntity).Center.ToVector2() + p - p1, ((Arc)SelectedEntity).Radius, ((Arc)SelectedEntity).StartAngle, ((Arc)SelectedEntity).EndAngle);
                            break;
                        case EntityType.Circle:
                            dxfReaderNETControl1.ShowRubberBandCircle(((Circle)SelectedEntity).Center.ToVector2() + p - p1, ((Circle)SelectedEntity).Radius);
                            break;
                        case EntityType.LightWeightPolyline:
                            vertexes.Clear();
                            foreach (LwPolylineVertex v in ((LwPolyline)SelectedEntity).Vertexes)
                            {
                                vertexes.Add(new Vector2(v.Position.X, v.Position.Y) + p - p1);
                            }
                            dxfReaderNETControl1.ShowRubberBandPolygon(vertexes);
                            break;

                        case EntityType.Polyline:
                            vertexes.Clear();
                            foreach (PolylineVertex v in ((Polyline)SelectedEntity).Vertexes)
                            {
                                vertexes.Add(new Vector2(v.Position.X, v.Position.Y) + p - p1);
                            }
                            dxfReaderNETControl1.ShowRubberBandPolygon(vertexes);
                            break;
                    }


                    break;
                case FunctionsEnum.Polygon2:
                    vertexes.Clear();
                    double stepAng = (double)360 / (double)PolygonSides * MathHelper.DegToRad;

                    double Radius = Vector2.Distance(p, p1);
                    double Rotation = Vector2.Angle(p, p1);
                    if (PolygonSides % 2 != 0)
                    {
                        Rotation += stepAng / 2;
                    }
                    for (double k = 0; k < PolygonSides; k++)
                    {

                        vertexes.Add(new Vector2(p1.X + Radius * Math.Cos(stepAng * k + Rotation), p1.Y + Radius * Math.Sin(stepAng * k + Rotation)));
                    }
                    dxfReaderNETControl1.ShowRubberBandPolygon(vertexes);
                    break;
                case FunctionsEnum.Circle3p3:

                    Vector2 CenterPoint = MathHelper.CircleCenterFrom3Points(p1, p2, p);
                    double radius = Vector2.Distance(CenterPoint, p2);

                    dxfReaderNETControl1.ShowRubberBandCircle(CenterPoint, radius);

                    toolStripStatusLabelInfo.Text = "Radius: " + MathHelper.ToFormattedUnit(radius);
                    break;
                case FunctionsEnum.Ray2:

                    double m = Vector2.Angle(p1, p);
                    p2 = new Vector2(p1.X + VideoSize * Math.Cos(m), p1.Y + VideoSize * Math.Sin(m));

                    dxfReaderNETControl1.ShowRubberBandLine(p1, p2);
                    toolStripStatusLabelInfo.Text = "Angle in XY Plane: " + MathHelper.ToFormattedAngle(m);
                    break;
                case FunctionsEnum.RotateAxis2:
                    m = Vector2.Angle(p1, p);
                    dxfReaderNETControl1.ShowRubberBandLine(p1, p);
                    toolStripStatusLabelInfo.Text = "Angle in XY Plane: " + MathHelper.ToFormattedAngle(m);

                    break;
                case FunctionsEnum.Xline2:

                    m = Vector2.Angle(p1, p);
                    p2 = new Vector2(p1.X + VideoSize * Math.Cos(m), p1.Y + VideoSize * Math.Sin(m));
                    p3 = new Vector2(p1.X + VideoSize * Math.Cos(m + MathHelper.PI), p1.Y + VideoSize * Math.Sin(m + MathHelper.PI));

                    dxfReaderNETControl1.ShowRubberBandLine(p1, p2);
                    dxfReaderNETControl1.ShowRubberBandLine(p1, p3);
                    toolStripStatusLabelInfo.Text = "Angle in XY Plane: " + MathHelper.ToFormattedAngle(m);
                    break;

                case FunctionsEnum.Ellipse2:

                    dxfReaderNETControl1.ShowRubberBandLine(p1, p, m_RubberBandColor, RubberBandType.Dashed, true);
                    toolStripStatusLabelInfo.Text = "Distance: " + MathHelper.ToFormattedUnit(Vector2.Distance(p1, p)) + " Delta X: " + MathHelper.ToFormattedUnit(p.X - p1.X) + " Delta Y: " + MathHelper.ToFormattedUnit(p.Y - p1.Y);
                    break;

                case FunctionsEnum.Ellipse3:

                    //////////////////////////////////////////////////////

                    vertexes.Clear();
                    int precision = 100;
                    Vector2 center = Vector2.MidPoint(p1, p2);
                    double beta = Vector2.Angle(p1, p2);
                    double majorAxis = Vector2.Distance(p1, p2);
                    double minorAxis = Vector2.Distance(center, p);
                    double sinbeta = Math.Sin(beta);
                    double cosbeta = Math.Cos(beta);

                    double delta = MathHelper.TwoPI / precision;
                    for (int i = 0; i < precision; i++)
                    {
                        double angle = delta * i;
                        double sinalpha = Math.Sin(angle);
                        double cosalpha = Math.Cos(angle);

                        double pointX = 0.5 * (majorAxis * cosalpha * cosbeta - minorAxis * sinalpha * sinbeta);
                        double pointY = 0.5 * (majorAxis * cosalpha * sinbeta + minorAxis * sinalpha * cosbeta);

                        vertexes.Add(new Vector2(pointX, pointY) + center);
                    }

                    dxfReaderNETControl1.ShowRubberBandPolygon(vertexes);
                    break;


                case FunctionsEnum.Circle2p2:


                    dxfReaderNETControl1.ShowRubberBandCircle(Vector2.MidPoint(p1, p), Vector2.Distance(p1, p) / 2);
                    toolStripStatusLabelInfo.Text = "Radius: " + MathHelper.ToFormattedUnit(Vector2.Distance(p1, p) / 2);
                    break;

                case FunctionsEnum.DrawArc3:
                case FunctionsEnum.Arc3:
                    dxfReaderNETControl1.ShowRubberBandArc(p1, Vector2.Distance(p1, p2), Vector2.Angle(p1, p2) * MathHelper.RadToDeg, Vector2.Angle(p1, p) * MathHelper.RadToDeg);
                    break;
                case FunctionsEnum.ArcStartMiddleEnd3:
                    CenterPoint = MathHelper.CircleCenterFrom3Points(p1, p2, p);
                    radius = Vector2.Distance(CenterPoint, p2);


                    double StartAngle = Vector2.Angle(CenterPoint, p1) * MathHelper.RadToDeg;
                    double EndAngle = Vector2.Angle(CenterPoint, p) * MathHelper.RadToDeg;
                    double MiddleAngle = Vector2.Angle(CenterPoint, p2) * MathHelper.RadToDeg;

                    if (MiddleAngle > EndAngle)
                    {
                        double buffer = StartAngle;
                        StartAngle = EndAngle;
                        EndAngle = buffer;
                    }

                    dxfReaderNETControl1.ShowRubberBandArc(CenterPoint, radius, StartAngle, EndAngle);
                    break;
            }
        }

        private void ribbonButton7_Click(object sender, EventArgs e)
        {
            dxfReaderNETControl1.ZoomIn();
        }

        private void ribbonButton8_Click(object sender, EventArgs e)
        {
            dxfReaderNETControl1.ZoomOut();
        }

        private void ribbonButton9_Click(object sender, EventArgs e)
        {
            CurrentFunction = FunctionsEnum.ZoomWindow1;

            StatusLabel.Text = "Select start point of the window";
        }

        private void ribbonButton11_Click(object sender, EventArgs e)
        {
            dxfReaderNETControl1.ZoomPrevious();
        }

        private void ribbonButton12_Click(object sender, EventArgs e)
        {
            dxfReaderNETControl1.ZoomNext();
        }

        private void dxfReaderNETControl1_MouseUp(object sender, MouseEventArgs e)
        {
            if (leftPressed)
            {
                p1 = pstart;

                CurrentFunction = FunctionsEnum.GetEntities2;
                setPoint();
                leftPressed = false;
            }
            DrawPen = new Pen(CurrentDrawColor, CurrentDrawPenWidth);
            if (CurrentDrawPenStyle == "Continuous")
            {
                DrawPen.DashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            }
            else
            {
                DrawPen.DashStyle = System.Drawing.Drawing2D.DashStyle.Custom;
                DrawPen.DashPattern = new float[] { CurrentDrawDashLength, CurrentDrawSkipLength };
            }
            screenP = dxfReaderNETControl1.CoordsToWorld(e.X, e.Y);
            if (e.Button == MouseButtons.Left)
            {

                if (dxfReaderNETControl1.ObjectOsnapMode != ObjectOsnapTypeFlags.None || dxfReaderNETControl1.DXF.DrawingVariables.OrthoMode != 0)
                {
                    p = dxfReaderNETControl1.CurrentWCSpoint;
                }

                setPoint();

            }
            else
            {

                StatusLabel.Text = "";
                switch (CurrentFunction)
                {

                    case FunctionsEnum.GradientHatchBoundaries:
                        CurrentFunction = FunctionsEnum.None;
                        dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHair;
                        LwPolyline lw = new LwPolyline();
                        List<LwPolylineVertex> lwvertexes = new List<LwPolylineVertex>();
                        foreach (Vector2 v in vertexes)
                        {
                            LwPolylineVertex lwvertex = new LwPolylineVertex(v.X, v.Y);

                            lwvertexes.Add(lwvertex);
                        }
                        lw.Vertexes = lwvertexes;
                        lw.StartWidth = 0;
                        lw.EndWidth = 0;
                        lw.IsClosed = true;
                        Boundary.Add(lw);
                        m_LastAddedEntity = dxfReaderNETControl1.AddGradientHatch((HatchGradientPatternType)Enum.Parse(typeof(HatchGradientPatternType), m_GradientPatternName), Boundary, BoundaryOutermost, m_GradientAciColor1, m_GradientAciColor2, double.Parse(m_GradientHatchRotation, System.Globalization.CultureInfo.CurrentCulture), m_GradientHatchCentered);

                        Boundary.Clear();
                        BoundaryOutermost.Clear();
                        vertexes.Clear();
                        break;
                    case FunctionsEnum.HatchBoundaries:
                        CurrentFunction = FunctionsEnum.None;
                        dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHair;
                        lw = new LwPolyline();
                        lwvertexes = new List<LwPolylineVertex>();
                        foreach (Vector2 v in vertexes)
                        {
                            LwPolylineVertex lwvertex = new LwPolylineVertex(v.X, v.Y);

                            lwvertexes.Add(lwvertex);
                        }
                        lw.Vertexes = lwvertexes;
                        lw.StartWidth = 0;
                        lw.EndWidth = 0;
                        lw.IsClosed = true;
                        Boundary.Add(lw);
                        m_LastAddedEntity = dxfReaderNETControl1.AddHatch(m_PatternName, Boundary, BoundaryOutermost, double.Parse(m_HatchRotation, System.Globalization.CultureInfo.CurrentCulture), double.Parse(m_HatchScale, System.Globalization.CultureInfo.CurrentCulture), dxfReaderNETControl1.DXF.CurrentColor.Index);
                        Boundary.Clear();
                        BoundaryOutermost.Clear();
                        vertexes.Clear();
                        break;


                    case FunctionsEnum.GradientHatchOutermost:
                        CurrentFunction = FunctionsEnum.None;
                        dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHair;
                        m_LastAddedEntity = dxfReaderNETControl1.AddGradientHatch((HatchGradientPatternType)Enum.Parse(typeof(HatchGradientPatternType), m_GradientPatternName), Boundary, BoundaryOutermost, m_GradientAciColor1, m_GradientAciColor2, double.Parse(m_GradientHatchRotation, System.Globalization.CultureInfo.CurrentCulture), m_GradientHatchCentered);



                        Boundary.Clear();
                        BoundaryOutermost.Clear();
                        break;

                    case FunctionsEnum.GradientHatch:
#if DEBUG
                        if (MessageBox.Show("Do you want to select hollow parts?", "DXFReader.NET Demo Program", MessageBoxButtons.YesNo, MessageBoxIcon.Information, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                        {
                            CurrentFunction = FunctionsEnum.GradientHatchOutermost;
                        }
                        else
                        {
                            CurrentFunction = FunctionsEnum.None;
                            dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHair;
                            m_LastAddedEntity = dxfReaderNETControl1.AddGradientHatch((HatchGradientPatternType)Enum.Parse(typeof(HatchGradientPatternType), m_GradientPatternName), Boundary, BoundaryOutermost, m_GradientAciColor1, m_GradientAciColor2, double.Parse(m_GradientHatchRotation, System.Globalization.CultureInfo.CurrentCulture), m_GradientHatchCentered);



                            Boundary.Clear();
                            BoundaryOutermost.Clear();
                            break;
                        }
                        break;
#else 
                         CurrentFunction = FunctionsEnum.None;
                            dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHair;
                            m_LastAddedEntity = dxfReaderNETControl1.AddGradientHatch((HatchGradientPatternType)Enum.Parse(typeof(HatchGradientPatternType), m_GradientPatternName), Boundary, BoundaryOutermost, m_GradientAciColor1, m_GradientAciColor2, double.Parse(m_GradientHatchRotation, System.Globalization.CultureInfo.CurrentCulture), m_GradientHatchCentered);



                            Boundary.Clear();
                            BoundaryOutermost.Clear();
                            break;
#endif
                    case FunctionsEnum.HatchOutermost:
                        CurrentFunction = FunctionsEnum.None;
                        dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHair;
                        m_LastAddedEntity = dxfReaderNETControl1.AddHatch(m_PatternName, Boundary, BoundaryOutermost, double.Parse(m_HatchRotation, System.Globalization.CultureInfo.CurrentCulture), double.Parse(m_HatchScale, System.Globalization.CultureInfo.CurrentCulture), dxfReaderNETControl1.DXF.CurrentColor.Index);



                        Boundary.Clear();
                        BoundaryOutermost.Clear();
                        break;

                    case FunctionsEnum.Hatch:
#if DEBUG
                        if (MessageBox.Show("Do you want to select hollow parts?", "DXFReader.NET Demo Program", MessageBoxButtons.YesNo, MessageBoxIcon.Information, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                        {
                            CurrentFunction = FunctionsEnum.HatchOutermost;
                            StatusLabel.Text = "Select entities with left mouse click. Right mouse clic to finish.";
                        }
                        else
                        {
                            CurrentFunction = FunctionsEnum.None;
                            dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHair;
                            m_LastAddedEntity = dxfReaderNETControl1.AddHatch(m_PatternName, Boundary, BoundaryOutermost, double.Parse(m_HatchRotation, System.Globalization.CultureInfo.CurrentCulture), double.Parse(m_HatchScale, System.Globalization.CultureInfo.CurrentCulture), dxfReaderNETControl1.DXF.CurrentColor.Index);



                            Boundary.Clear();
                            BoundaryOutermost.Clear();
                            break;
                        }
                        break;
#else
                         CurrentFunction = FunctionsEnum.None;
                            dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHair;
                            m_LastAddedEntity = dxfReaderNETControl1.AddHatch(m_PatternName, Boundary, BoundaryOutermost, double.Parse(m_HatchRotation, System.Globalization.CultureInfo.CurrentCulture), double.Parse(m_HatchScale, System.Globalization.CultureInfo.CurrentCulture), dxfReaderNETControl1.DXF.CurrentColor.Index);



                            Boundary.Clear();
                            BoundaryOutermost.Clear();
                            break;
#endif
                    case FunctionsEnum.GetEntities:
                        StatusLabel.Text = "";
                        CurrentFunction = FunctionsEnum.None;

                        break;
                    case FunctionsEnum.Lines:
                        CurrentFunction = FunctionsEnum.None;
                        dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHair;

                        for (int k = 0; k < vertexes.Count - 1; k++)
                        {
                            dxfReaderNETControl1.DrawEntity(dxfReaderNETControl1.AddLine(new Vector3(vertexes[k].X, vertexes[k].Y, dxfReaderNETControl1.DXF.CurrentElevation), new Vector3(vertexes[k + 1].X, vertexes[k + 1].Y, dxfReaderNETControl1.DXF.CurrentElevation), dxfReaderNETControl1.DXF.CurrentColor.Index));

                        }
                        if (MessageBox.Show("Close?", "DXFReader.NET Demo Program", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
                        {
                            dxfReaderNETControl1.DrawEntity(dxfReaderNETControl1.AddLine(new Vector3(vertexes[vertexes.Count - 1].X, vertexes[vertexes.Count - 1].Y, dxfReaderNETControl1.DXF.CurrentElevation), new Vector3(vertexes[0].X, vertexes[0].Y, dxfReaderNETControl1.DXF.CurrentElevation), dxfReaderNETControl1.DXF.CurrentColor.Index));

                        }

                        vertexes.Clear();
                        break;



                    case FunctionsEnum.Spline:
                        CurrentFunction = FunctionsEnum.None;
                        dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHair;
                        List<SplineVertex> splinevertexes = new List<SplineVertex>();
                        foreach (Vector2 v in vertexes)
                        {
                            SplineVertex splinevertex = new SplineVertex(v.X, v.Y, dxfReaderNETControl1.DXF.CurrentElevation);

                            splinevertexes.Add(splinevertex);
                        }
                        m_LastAddedEntity = dxfReaderNETControl1.AddSpline(splinevertexes, false, dxfReaderNETControl1.DXF.CurrentColor.Index);
                        vertexes.Clear();
                        break;
                    case FunctionsEnum.LwPolyline:
                        CurrentFunction = FunctionsEnum.None;
                        dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHair;
                        List<LwPolylineVertex> lwpolyvertexes = new List<LwPolylineVertex>();
                        foreach (Vector2 v in vertexes)
                        {
                            LwPolylineVertex polyvertex = new LwPolylineVertex(v.X, v.Y);
                            polyvertex.StartWidth = dxfReaderNETControl1.DXF.DrawingVariables.Polylinewidth;
                            polyvertex.EndWidth = dxfReaderNETControl1.DXF.DrawingVariables.Polylinewidth;
                            lwpolyvertexes.Add(polyvertex);
                        }
                        bool isClosed = MessageBox.Show("Close?", "DXFReader.NET Demo Program", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes;
                        m_LastAddedEntity = dxfReaderNETControl1.AddLightWeightPolyline(lwpolyvertexes, isClosed, dxfReaderNETControl1.DXF.DrawingVariables.Polylinewidth, dxfReaderNETControl1.DXF.CurrentColor.Index);
                        vertexes.Clear();
                        break;
                    case FunctionsEnum.PolylineLenght:


                        CurrentFunction = FunctionsEnum.None;
                        dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHair;
                        isClosed = MessageBox.Show("Close?", "DXFReader.NET Demo Program", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes;

                        if (isClosed)
                        {
                            StatusLabel.Text = "Lenght: " + MathHelper.ToFormattedUnit((MathHelper.PolygonLenght(vertexes, isClosed))) + " Area: " + MathHelper.ToFormattedUnit(MathHelper.Area(vertexes));

                        }
                        else
                        {
                            StatusLabel.Text = "Lenght: " + MathHelper.ToFormattedUnit((MathHelper.PolygonLenght(vertexes, isClosed)));

                        }
                        vertexes.Clear();
                        break;
                    case FunctionsEnum.Polyline:
                        CurrentFunction = FunctionsEnum.None;
                        dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHair;
                        List<PolylineVertex> polyvertexes = new List<PolylineVertex>();
                        foreach (Vector2 v in vertexes)
                        {
                            PolylineVertex polyvertex = new PolylineVertex(v.X, v.Y, dxfReaderNETControl1.DXF.CurrentElevation);
                            polyvertex.StartWidth = dxfReaderNETControl1.DXF.DrawingVariables.Polylinewidth;
                            polyvertex.EndWidth = dxfReaderNETControl1.DXF.DrawingVariables.Polylinewidth;
                            polyvertexes.Add(polyvertex);
                        }
                        isClosed = MessageBox.Show("Close?", "DXFReader.NET Demo Program", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes;

                        m_LastAddedEntity = dxfReaderNETControl1.AddPolyline(polyvertexes, isClosed, dxfReaderNETControl1.DXF.DrawingVariables.Polylinewidth, dxfReaderNETControl1.DXF.CurrentColor.Index);
                        vertexes.Clear();
                        break;
                    case FunctionsEnum.Area:
                        CurrentFunction = FunctionsEnum.None;
                        dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHair;

                        StatusLabel.Text = "Area: " + MathHelper.ToFormattedUnit(MathHelper.Area(vertexes)) + " Lenght: " + MathHelper.ToFormattedUnit((MathHelper.PolygonLenght(vertexes, true)));
                        vertexes.Clear();
                        break;
                    case FunctionsEnum.Solid4:
                        CurrentFunction = FunctionsEnum.None;
                        dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHair;

                        p4 = p3;

                        m_LastAddedEntity = dxfReaderNETControl1.AddSolid(new Vector3(p1.X, p1.Y, dxfReaderNETControl1.DXF.CurrentElevation), new Vector3(p2.X, p2.Y, dxfReaderNETControl1.DXF.CurrentElevation), new Vector3(p4.X, p4.Y, dxfReaderNETControl1.DXF.CurrentElevation), new Vector3(p3.X, p3.Y, dxfReaderNETControl1.DXF.CurrentElevation), dxfReaderNETControl1.DXF.CurrentColor.Index);
                        break;
                    case FunctionsEnum.DrawPolygon:
                        CurrentFunction = FunctionsEnum.None;
                        dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHair;
                        dxfReaderNETControl1.DrawPolygon(DrawPen, vertexes, ribbonButtonDrawMethodsFill.Checked, ribbonButtonDrawMethodsStore.Checked);
                        vertexes.Clear();
                        break;

                }
            }
            if (m_LastAddedEntity != null)
            {
                if (m_LastAddedEntity.Type != EntityType.Hatch)
                {
                    dxfReaderNETControl1.DrawEntity(m_LastAddedEntity);
                }
                else
                {
                    dxfReaderNETControl1.Refresh();
                }
            }
        }

        private void ribbonButton13_Click(object sender, EventArgs e)
        {
            dxfReaderNETControl1.DisplayPredefinedView(PredefinedViewType.Top);
        }

        private void ribbonButton15_Click(object sender, EventArgs e)
        {
            dxfReaderNETControl1.DisplayPredefinedView(PredefinedViewType.Bottom);
        }

        private void ribbonButton16_Click(object sender, EventArgs e)
        {
            dxfReaderNETControl1.DisplayPredefinedView(PredefinedViewType.Left);
        }

        private void ribbonButton17_Click(object sender, EventArgs e)
        {
            dxfReaderNETControl1.DisplayPredefinedView(PredefinedViewType.Right);
        }

        private void ribbonButton18_Click(object sender, EventArgs e)
        {
            dxfReaderNETControl1.DisplayPredefinedView(PredefinedViewType.Front);
        }

        private void ribbonButton19_Click(object sender, EventArgs e)
        {
            dxfReaderNETControl1.DisplayPredefinedView(PredefinedViewType.Back);
        }

        private void ribbonButton20_Click(object sender, EventArgs e)
        {
            dxfReaderNETControl1.DisplayPredefinedView(PredefinedViewType.SW_Isometric);
        }

        private void ribbonButton21_Click(object sender, EventArgs e)
        {
            dxfReaderNETControl1.DisplayPredefinedView(PredefinedViewType.SE_Isometric);
        }

        private void ribbonButton22_Click(object sender, EventArgs e)
        {
            dxfReaderNETControl1.DisplayPredefinedView(PredefinedViewType.NE_Isometric);
        }

        private void ribbonButton23_Click(object sender, EventArgs e)
        {
            dxfReaderNETControl1.DisplayPredefinedView(PredefinedViewType.NW_Isometric);
        }



        private void ribbonColorChooserForeColor_Click(object sender, EventArgs e)
        {

            //ColorDialog colorSelector = new ColorDialog();
            //colorSelector.Text = "Fore color";
            //colorSelector.colorWheel1.Color = dxfReaderNETControl1.ForeColor;
            //if (colorSelector.ShowDialog() == DialogResult.OK)
            //{
            //    dxfReaderNETControl1.ForeColor = colorSelector.colorWheel1.Color;
            //    ribbonColorChooserForeColor.Color = dxfReaderNETControl1.ForeColor;
            //}

            colorDialog1.Color = dxfReaderNETControl1.ForeColor;

            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                dxfReaderNETControl1.ForeColor = colorDialog1.Color;
                //dxfReaderNETControl1.Refresh();
                ribbonColorChooserForeColor.Color = colorDialog1.Color;
            }
        }

        private void ribbonColorChooserBackColor_Click(object sender, EventArgs e)
        {

            colorDialog1.Color = dxfReaderNETControl1.BackColor;

            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                dxfReaderNETControl1.BackColor = colorDialog1.Color;

                ribbonColorChooserBackColor.Color = colorDialog1.Color;
            }
        }

        private void ribbonColorChooserAxes_Click(object sender, EventArgs e)
        {
            colorDialog1.Color = dxfReaderNETControl1.AxesColor;

            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                dxfReaderNETControl1.AxesColor = colorDialog1.Color;
                dxfReaderNETControl1.Refresh();
                ribbonColorChooserAxes.Color = colorDialog1.Color;
            }
        }

        private void ribbonColorChooserAxisX_Click(object sender, EventArgs e)
        {
            colorDialog1.Color = dxfReaderNETControl1.AxisXColor;

            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                dxfReaderNETControl1.AxisXColor = colorDialog1.Color;
                dxfReaderNETControl1.Refresh();
                ribbonColorChooserAxisX.Color = colorDialog1.Color;
            }
        }

        private void ribbonColorChooserAxisY_Click(object sender, EventArgs e)
        {

            colorDialog1.Color = dxfReaderNETControl1.AxisYColor;

            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                dxfReaderNETControl1.AxisYColor = colorDialog1.Color;
                dxfReaderNETControl1.Refresh();
                ribbonColorChooserAxisY.Color = colorDialog1.Color;
            }
        }

        private void ribbonColorChooserAxisZ_Click(object sender, EventArgs e)
        {

            colorDialog1.Color = dxfReaderNETControl1.AxisZColor;

            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                dxfReaderNETControl1.AxisZColor = colorDialog1.Color;
                dxfReaderNETControl1.Refresh();
                ribbonColorChooserAxisZ.Color = colorDialog1.Color;
            }

        }

        private void ribbonColorChooserGrid_Click(object sender, EventArgs e)
        {

            colorDialog1.Color = dxfReaderNETControl1.GridColor;

            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                dxfReaderNETControl1.GridColor = colorDialog1.Color;
                dxfReaderNETControl1.Refresh();
                ribbonColorChooserGrid.Color = colorDialog1.Color;
            }
        }

        private void ribbonColorChooserHighlight_Click(object sender, EventArgs e)
        {
            colorDialog1.Color = dxfReaderNETControl1.HighlightColor;

            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                dxfReaderNETControl1.HighlightColor = colorDialog1.Color;
                dxfReaderNETControl1.Refresh();
                ribbonColorChooserHighlight.Color = colorDialog1.Color;
            }
        }

        private void ribbonColorChooserHighlightMarker_Click(object sender, EventArgs e)
        {


            colorDialog1.Color = dxfReaderNETControl1.HighlightMarkerColor;

            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                dxfReaderNETControl1.HighlightMarkerColor = colorDialog1.Color;
                dxfReaderNETControl1.Refresh();
                ribbonColorChooserHighlightMarker.Color = colorDialog1.Color;
            }
        }

        private void ribbonColorChooserHighlightMarker2_Click(object sender, EventArgs e)
        {

            colorDialog1.Color = dxfReaderNETControl1.HighlightMarkerColor2;

            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                dxfReaderNETControl1.HighlightMarkerColor2 = colorDialog1.Color;
                dxfReaderNETControl1.Refresh();
                ribbonColorChooserHighlightMarker2.Color = colorDialog1.Color;
            }
        }

        private void ribbonButtonLightColorScheme_Click(object sender, EventArgs e)
        {
            dxfReaderNETControl1.LightColorScheme();
            ribbonColors();
        }

        private void ribbonButtonDefaultColorScheme_Click(object sender, EventArgs e)
        {
            dxfReaderNETControl1.DefaultColorScheme();
            ribbonColors();
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.F5:
                    dxfReaderNETControl1.Refresh();
                    break;
                case Keys.F7:
                    dxfReaderNETControl1.ShowGrid = !dxfReaderNETControl1.ShowGrid;
                    ShowStatusLabels();
                    dxfReaderNETControl1.Refresh();
                    break;
                case Keys.F8:
                    if (dxfReaderNETControl1.DXF.DrawingVariables.OrthoMode == 0)
                    {
                        dxfReaderNETControl1.DXF.DrawingVariables.OrthoMode = 1;
                    }
                    else
                    {
                        dxfReaderNETControl1.DXF.DrawingVariables.OrthoMode = 0;
                    }

                    ShowStatusLabels();

                    break;
                case Keys.F9:
                    dxfReaderNETControl1.DXF.VPorts["*Active"].SnapMode = !dxfReaderNETControl1.DXF.VPorts["*Active"].SnapMode;
                    ShowStatusLabels();

                    break;
                case Keys.Escape:
                    CurrentFunction = FunctionsEnum.None;
                    dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHair;
                    StatusLabel.Text = "";

                    break;
                case Keys.Delete:
                    if (dxfReaderNETControl1.DXF.SelectedEntities.Count > 0)
                        ribbonButtonModifyDeleteSelected_Click(sender, e);
                    break;
                case Keys.A:
                    if (ModifierKeys == Keys.Control)
                    {
                        ribbonButtonModifySelectAll_Click(sender, e);
                    }
                    break;
                case Keys.S:
                    if (ModifierKeys == Keys.Control)
                    {
                        ribbonOrbMenuItem3_Click(sender, e);
                    }
                    break;
                case Keys.O:
                    if (ModifierKeys == Keys.Control)
                    {
                        ribbonOrbMenuItemOpen_Click(sender, e);
                    }
                    break;
                case Keys.NumPad9:
                case Keys.D9:
                    if (ModifierKeys == Keys.Control)
                    {
                        labelCommands.Visible = !labelCommands.Visible;

                        ribbonButtonCommandLine.Checked = labelCommands.Visible;
                    }
                    break;

            }

            {
                if (ModifierKeys == Keys.None && labelCommands.Visible && labelCommands.Text != "")
                {
                    switch (e.KeyCode)
                    {
                        case Keys.Enter:
                            string[] coords = cmdCoord.Split((char)44);
                            double coordX = 0;
                            double coordY = 0;
                            float output;

                            if (float.TryParse(coords[0], out output))
                            {
                                coordX = double.Parse(coords[0].Replace(",", "."), System.Globalization.CultureInfo.InvariantCulture);
                            }
                            if (coords.Length == 2)
                            {
                                if (float.TryParse(coords[1], out output))
                                {

                                    coordY = double.Parse(coords[1].Replace(",", "."), System.Globalization.CultureInfo.InvariantCulture);
                                }
                            }
                            p = new Vector2(coordX, coordY);
                            setPoint();
                            if (m_LastAddedEntity != null)
                            {
                                if (m_LastAddedEntity.Type != EntityType.Hatch)
                                {
                                    dxfReaderNETControl1.DrawEntity(m_LastAddedEntity);
                                }
                                else
                                {
                                    dxfReaderNETControl1.Refresh();
                                }
                            }
                            break;
                        case Keys.NumPad0:
                        case Keys.D0:
                        case Keys.NumPad1:
                        case Keys.D1:
                        case Keys.NumPad2:
                        case Keys.D2:
                        case Keys.NumPad3:
                        case Keys.D3:
                        case Keys.NumPad4:
                        case Keys.D4:
                        case Keys.NumPad5:
                        case Keys.D5:
                        case Keys.NumPad6:
                        case Keys.D6:
                        case Keys.NumPad7:
                        case Keys.D7:
                        case Keys.NumPad8:
                        case Keys.D8:
                        case Keys.NumPad9:
                        case Keys.D9:
                            if (e.KeyValue > 57)
                            {
                                cmdCoord += (char)(e.KeyValue - 48);
                            }
                            else
                            {
                                cmdCoord += (char)e.KeyValue;
                            }

                            break;
                        case Keys.OemMinus:
                            if (cmdCoord == "" || cmdCoord.Substring(cmdCoord.Length - 1) == ",")
                                cmdCoord += "-";
                            break;
                        case Keys.Oemcomma:
                            if (!cmdCoord.Contains(","))
                                cmdCoord += ",";
                            break;
                        case Keys.OemPeriod:
                            cmdCoord += ".";
                            break;
                    }
                    labelCommands.Text = labelCommands.Text.Substring(0, labelCommands.Text.IndexOf(":") + 1) + " " + cmdCoord;

                }
            }
        }

        private void ribbonColorChooserCurrentColor_Click(object sender, EventArgs e)
        {
            dxfReaderNETControl1.DXF.CurrentColor = dxfReaderNETControl1.ShowPalette(dxfReaderNETControl1.DXF.CurrentColor);
            ribbonColors();
        }

        private void ribbonButtonLayers_Click(object sender, EventArgs e)
        {
            dxfReaderNETControl1.ShowLayers();
        }

        private void ribbonOrbMenuItem1_Click(object sender, EventArgs e)
        {

            if (DiscardChanges())
            {
                dxfReaderNETControl1.NewDrawing();
                InitDrawing();
                //dxfReaderNETControl1.UnRegisterComponent();
            }

        }

        private bool DiscardChanges()
        {
            bool ret = true;
            if (dxfReaderNETControl1.DXF != null)
            {
                if (dxfReaderNETControl1.DXF.Modified)
                {
                    if (MessageBox.Show("The current drawing has been modified. Do you want to discard changes?", "DXFReader.NET Demo Program", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.No)
                    {
                        ret = false;
                    }
                }
            }
            return ret;
        }

        private void ribbonOrbOptionButtonExit_Click(object sender, EventArgs e)
        {
            if (DiscardChanges())
            {
                SaveRegistry();
                System.Environment.Exit(0);
            }
        }

        private void ribbonOrbMenuItemOpen_Click(object sender, EventArgs e)
        {
            if (DiscardChanges())
            {
                StatusLabel.Text = "";
                openFileDialog1.DefaultExt = "dxf";
                openFileDialog1.Filter = "DXF|*.dxf|All files (*.*)|*.*";
                openFileDialog1.FileName = "";
                openFileDialog1.InitialDirectory = CurrentLoadDXFPath;
                if (openFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    if (dxfReaderNETControl1.ReadDXF(openFileDialog1.FileName))
                    {


                        InitDrawing();
                        this.Text = "DXFReader.NET Component - Demo Program  - " + dxfReaderNETControl1.FileName;
                        AddMRU(dxfReaderNETControl1.FileName);

                        CurrentLoadDXFPath = Path.GetDirectoryName(dxfReaderNETControl1.FileName);
                        SaveRegistry();
                    }
                    else
                    {
                        dxfReaderNETControl1.NewDrawing();
                        InitDrawing();
                    }

                }
            }
        }
        private void newRecent_Click(object sender, System.EventArgs e)
        {
            // Add event handler code here.
            // System.Diagnostics.Debugger.Break(); //stop
            if (DiscardChanges())
            {
                RibbonOrbRecentItem se = (RibbonOrbRecentItem)sender;

                if (dxfReaderNETControl1.ReadDXF(se.Text))
                {
                    InitDrawing();
                    this.Text = "DXFReader.NET Component - Demo Program  - " + dxfReaderNETControl1.FileName;
                    AddMRU(dxfReaderNETControl1.FileName);
                }
                else
                {
                    dxfReaderNETControl1.NewDrawing();
                    InitDrawing();
                }
            }
        }
        private void AddMRU(string file_name)
        {
            if (FileInfos.Contains(file_name))
            {
                FileInfos.Remove(file_name);
            }
            if (FileInfos.Count >= 10)
            {
                FileInfos.Remove(FileInfos[9]);
            }
            FileInfos.Insert(0, file_name);

            ribbon1.OrbDropDown.RecentItems.Clear();
            int i = 0;
            foreach (string file_info in FileInfos)
            {
                if (i < 10)
                {
                    RibbonOrbRecentItem newRecent = new RibbonOrbRecentItem(file_info);
                    newRecent.Click += new EventHandler(newRecent_Click);
                    ribbon1.OrbDropDown.RecentItems.Add(newRecent);
                }
                i++;
            }

        }

        private void ribbonOrbMenuItem4_Click(object sender, EventArgs e)
        {
            saveFileDialog1.DefaultExt = "dxf";
            saveFileDialog1.Filter = "DXF|*.dxf";
            saveFileDialog1.FileName = "";

            saveFileDialog1.Filter = "AutoCAD R10 DXF|*.dxf"; //1
            saveFileDialog1.Filter += "|AutoCAD R11 and R12 DXF|*.dxf"; //2
            saveFileDialog1.Filter += "|AutoCAD R13 DXF|*.dxf"; //3
            saveFileDialog1.Filter += "|AutoCAD R14 DXF|*.dxf"; //4
            saveFileDialog1.Filter += "|AutoCAD 2000 DXF|*.dxf"; //5
            saveFileDialog1.Filter += "|AutoCAD 2004 DXF|*.dxf"; //6
            saveFileDialog1.Filter += "|AutoCAD 2007 DXF|*.dxf"; //7
            saveFileDialog1.Filter += "|AutoCAD 2010 DXF|*.dxf"; //8
            saveFileDialog1.Filter += "|AutoCAD 2013 DXF|*.dxf"; //9
            saveFileDialog1.Filter += "|AutoCAD 2018 DXF|*.dxf"; //10

            saveFileDialog1.Filter += "|AutoCAD R10 binary DXF|*.dxf"; //11
            saveFileDialog1.Filter += "|AutoCAD R11 and R12 binary DXF|*.dxf"; //12
            saveFileDialog1.Filter += "|AutoCAD R13 binary DXF|*.dxf"; //13
            saveFileDialog1.Filter += "|AutoCAD R14 binary DXF|*.dxf"; //14
            saveFileDialog1.Filter += "|AutoCAD 2000 binary DXF|*.dxf"; //15
            saveFileDialog1.Filter += "|AutoCAD 2004 binary DXF|*.dxf"; //16
            saveFileDialog1.Filter += "|AutoCAD 2007 binary DXF|*.dxf"; //17
            saveFileDialog1.Filter += "|AutoCAD 2010 binary DXF|*.dxf"; //18
            saveFileDialog1.Filter += "|AutoCAD 2013 binary DXF|*.dxf"; //19
            saveFileDialog1.Filter += "|AutoCAD 2018 binary DXF|*.dxf"; //20

            switch (dxfReaderNETControl1.DXF.DrawingVariables.AcadVer)
            {
                case DXFReaderNET.Header.DxfVersion.AutoCad10:
                    saveFileDialog1.FilterIndex = 1;
                    break;
                case DXFReaderNET.Header.DxfVersion.AutoCad12:
                    saveFileDialog1.FilterIndex = 2;
                    break;

                case DXFReaderNET.Header.DxfVersion.AutoCad13:
                    saveFileDialog1.FilterIndex = 3;
                    break;
                case DXFReaderNET.Header.DxfVersion.AutoCad14:

                    saveFileDialog1.FilterIndex = 4;
                    break;
                case DXFReaderNET.Header.DxfVersion.AutoCad2000:
                    saveFileDialog1.FilterIndex = 5;
                    break;
                case DXFReaderNET.Header.DxfVersion.AutoCad2004:

                    saveFileDialog1.FilterIndex = 6;
                    break;
                case DXFReaderNET.Header.DxfVersion.AutoCad2007:
                    saveFileDialog1.FilterIndex = 7;
                    break;
                case DXFReaderNET.Header.DxfVersion.AutoCad2010:

                    saveFileDialog1.FilterIndex = 8;
                    break;
                case DXFReaderNET.Header.DxfVersion.AutoCad2013:

                    saveFileDialog1.FilterIndex = 9;
                    break;
                case DXFReaderNET.Header.DxfVersion.AutoCad2018:
                    saveFileDialog1.FilterIndex = 10;
                    break;

            }


            if (dxfReaderNETControl1.DXF.IsBinary) saveFileDialog1.FilterIndex += 10; ;

            saveFileDialog1.InitialDirectory = CurrentSaveDXFPath;
            if (dxfReaderNETControl1.FileName == null)
            {
                saveFileDialog1.FileName = "drawing.dxf";
            }
            else
            {
                saveFileDialog1.FileName = Path.GetFileName(dxfReaderNETControl1.FileName); ;
            }


            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                DXFReaderNET.Header.DxfVersion dxfver = DXFReaderNET.Header.DxfVersion.AutoCad2013;
                switch (saveFileDialog1.FilterIndex)
                {
                    case 1:
                    case 11:
                        dxfver = DXFReaderNET.Header.DxfVersion.AutoCad10;
                        break;
                    case 2:
                    case 12:
                        dxfver = DXFReaderNET.Header.DxfVersion.AutoCad12;
                        break;
                    case 3:
                    case 13:
                        dxfver = DXFReaderNET.Header.DxfVersion.AutoCad13;
                        break;
                    case 4:
                    case 14:
                        dxfver = DXFReaderNET.Header.DxfVersion.AutoCad14;
                        break;
                    case 5:
                    case 15:
                        dxfver = DXFReaderNET.Header.DxfVersion.AutoCad2000;
                        break;
                    case 6:
                    case 16:
                        dxfver = DXFReaderNET.Header.DxfVersion.AutoCad2004;
                        break;
                    case 7:
                    case 17:
                        dxfver = DXFReaderNET.Header.DxfVersion.AutoCad2007;
                        break;
                    case 8:
                    case 18:
                        dxfver = DXFReaderNET.Header.DxfVersion.AutoCad2010;
                        break;
                    case 9:
                    case 19:
                        dxfver = DXFReaderNET.Header.DxfVersion.AutoCad2013;
                        break;
                    case 10:
                    case 20:
                        dxfver = DXFReaderNET.Header.DxfVersion.AutoCad2018;
                        break;
                }
                if (saveFileDialog1.FilterIndex > 10) dxfReaderNETControl1.DXF.IsBinary = true;

                if (dxfReaderNETControl1.WriteDXF(saveFileDialog1.FileName, dxfver, dxfReaderNETControl1.DXF.IsBinary))
                {
                    StatusLabel.Text = "DXF file saved";
                }
                else
                {
                    StatusLabel.Text = "Error in saving DXF file";
                }
                CurrentSaveDXFPath = Path.GetDirectoryName(saveFileDialog1.FileName);
                AddMRU(saveFileDialog1.FileName);
                this.Text = "DXFReader.NET Component - Demo Program  - " + dxfReaderNETControl1.FileName;
                SaveRegistry();
            }
        }

        private void ribbonOrbMenuItem3_Click(object sender, EventArgs e)
        {
            if (dxfReaderNETControl1.FileName != null)
            {
                dxfReaderNETControl1.WriteDXF(dxfReaderNETControl1.FileName);
            }
            else
            {
                ribbonOrbMenuItem4_Click(sender, e);
            }
        }

        private void ribbonButtonUnits_Click(object sender, EventArgs e)
        {
            dxfReaderNETControl1.ShowDrawingUnits();
        }

        private void ribbonOrbMenuItem5_Click(object sender, EventArgs e)
        {
            OnPlotPreview = true;
            if (dxfReaderNETControl1.PlotMode == PlotModeType.Window)
            {
                CurrentFunction = FunctionsEnum.PlotWindow1;
                StatusLabel.Text = "Select start point of the ploting window";
            }
            else
            {
                PlotPreview();
            }
        }

        private void PlotPreview()
        {
            ribbon1.Visible = false;
            toolStripPlotPreview.Visible = true;

            printPreviewControl1.Visible = true;
            dxfReaderNETControl1.Visible = false;

            printPreviewControl1.Top = toolStripPlotPreview.Top + toolStripPlotPreview.Height;
            printPreviewControl1.Width = dxfReaderNETControl1.Width;
            printPreviewControl1.Left = 0;
            printPreviewControl1.Height = this.ClientSize.Height - toolStripPlotPreview.Height - statusStrip1.Height;

            dxfReaderNETControl1.PlotPreview(printPreviewControl1);
        }

        private void ribbonButtonOpen_Click(object sender, EventArgs e)
        {
            ribbonOrbMenuItemOpen_Click(sender, e);
        }

        private void ribbonButtonZoomExt_Click(object sender, EventArgs e)
        {
            ribbonButton6_Click(sender, e);
        }


        private void LoadRegistry()
        {

            Registry.CurrentUser.OpenSubKey("Software", true).CreateSubKey("DXFReaderNETDemoProgram");


            this.Width = (int)Registry.GetValue(@"HKEY_CURRENT_USER\Software\DXFReaderNETDemoProgram", "wWidth", Screen.PrimaryScreen.Bounds.Width - 40);
            this.Height = (int)Registry.GetValue(@"HKEY_CURRENT_USER\Software\DXFReaderNETDemoProgram", "wHeight", Screen.PrimaryScreen.Bounds.Height - 60);
            this.Left = (int)Registry.GetValue(@"HKEY_CURRENT_USER\Software\DXFReaderNETDemoProgram", "wLeft", 20);
            this.Top = (int)Registry.GetValue(@"HKEY_CURRENT_USER\Software\DXFReaderNETDemoProgram", "wTop", 20);

            dxfReaderNETControl1.ShowAxes = Convert.ToBoolean(Registry.GetValue(@"HKEY_CURRENT_USER\Software\DXFReaderNETDemoProgram", "ShowAxes", false).ToString());
            dxfReaderNETControl1.ShowBasePoint = Convert.ToBoolean(Registry.GetValue(@"HKEY_CURRENT_USER\Software\DXFReaderNETDemoProgram", "ShowBasePoint", false).ToString());
            dxfReaderNETControl1.ShowLimits = Convert.ToBoolean(Registry.GetValue(@"HKEY_CURRENT_USER\Software\DXFReaderNETDemoProgram", "ShowLimits", false).ToString());
            dxfReaderNETControl1.ShowGrid = Convert.ToBoolean(Registry.GetValue(@"HKEY_CURRENT_USER\Software\DXFReaderNETDemoProgram", "ShowGrid", true).ToString());
            dxfReaderNETControl1.ShowGridRuler = Convert.ToBoolean(Registry.GetValue(@"HKEY_CURRENT_USER\Software\DXFReaderNETDemoProgram", "ShowGridRuler", false).ToString());

            dxfReaderNETControl1.AntiAlias = Convert.ToBoolean(Registry.GetValue(@"HKEY_CURRENT_USER\Software\DXFReaderNETDemoProgram", "AntiAlias", false).ToString());

            dxfReaderNETControl1.ForeColor = Color.FromArgb((int)Registry.GetValue(@"HKEY_CURRENT_USER\Software\DXFReaderNETDemoProgram", "ForeColor", Color.White.ToArgb()));
            dxfReaderNETControl1.BackColor = Color.FromArgb((int)Registry.GetValue(@"HKEY_CURRENT_USER\Software\DXFReaderNETDemoProgram", "BackColor", Color.FromArgb(33, 40, 48).ToArgb()));

            dxfReaderNETControl1.HighlightMarkerColor = Color.FromArgb((int)Registry.GetValue(@"HKEY_CURRENT_USER\Software\DXFReaderNETDemoProgram", "HighlightMarkerColor", Color.FromArgb(255, 255, 0).ToArgb()));
            dxfReaderNETControl1.HighlightColor = Color.FromArgb((int)Registry.GetValue(@"HKEY_CURRENT_USER\Software\DXFReaderNETDemoProgram", "HighlightColor", Color.FromArgb(255, 0, 0).ToArgb()));
            dxfReaderNETControl1.AxisXColor = Color.FromArgb((int)Registry.GetValue(@"HKEY_CURRENT_USER\Software\DXFReaderNETDemoProgram", "AxisXColor", Color.FromArgb(72, 38, 43).ToArgb()));
            dxfReaderNETControl1.AxisYColor = Color.FromArgb((int)Registry.GetValue(@"HKEY_CURRENT_USER\Software\DXFReaderNETDemoProgram", "AxisYColor", Color.FromArgb(34, 102, 39).ToArgb()));
            dxfReaderNETControl1.AxisZColor = Color.FromArgb((int)Registry.GetValue(@"HKEY_CURRENT_USER\Software\DXFReaderNETDemoProgram", "AxisZColor", Color.FromArgb(32, 35, 175).ToArgb()));
            dxfReaderNETControl1.AxesColor = Color.FromArgb((int)Registry.GetValue(@"HKEY_CURRENT_USER\Software\DXFReaderNETDemoProgram", "AxesColor", Color.FromArgb(255, 0, 0).ToArgb()));
            dxfReaderNETControl1.GridColor = Color.FromArgb((int)Registry.GetValue(@"HKEY_CURRENT_USER\Software\DXFReaderNETDemoProgram", "GridColor", Color.FromArgb(38, 45, 55).ToArgb()));

            switch ((int)Registry.GetValue(@"HKEY_CURRENT_USER\Software\DXFReaderNETDemoProgram", "RubberBandType", 0))
            {
                case 1:
                    m_RubberBandType = RubberBandType.Solid;
                    break;
                case 0:
                    m_RubberBandType = RubberBandType.Dashed;
                    break;
            }


            m_RubberBandColor = Color.FromArgb((int)Registry.GetValue(@"HKEY_CURRENT_USER\Software\DXFReaderNETDemoProgram", "RubberBandColor", Color.FromArgb(150, 150, 150).ToArgb()));

            dxfReaderNETControl1.GridDisplay = (GridDisplayType)Registry.GetValue(@"HKEY_CURRENT_USER\Software\DXFReaderNETDemoProgram", "GridDisplay", 0);

            dxfReaderNETControl1.PlotRotation = (PlotOrientationType)Registry.GetValue(@"HKEY_CURRENT_USER\Software\DXFReaderNETDemoProgram", "PlotRotation", 0);
            dxfReaderNETControl1.PlotRendering = (PlotRenderingType)Registry.GetValue(@"HKEY_CURRENT_USER\Software\DXFReaderNETDemoProgram", "PlotRendering", 0);
            dxfReaderNETControl1.PlotMode = (PlotModeType)Registry.GetValue(@"HKEY_CURRENT_USER\Software\DXFReaderNETDemoProgram", "PlotMode", 0);
            dxfReaderNETControl1.PlotUnits = (PlotUnitsType)Registry.GetValue(@"HKEY_CURRENT_USER\Software\DXFReaderNETDemoProgram", "PlotUnits", 0);

            CurrentLoadDXFPath = Registry.GetValue(@"HKEY_CURRENT_USER\Software\DXFReaderNETDemoProgram", "CurrentLoadDXFPath", CurrentLoadDXFPath).ToString();
            CurrentSaveDXFPath = Registry.GetValue(@"HKEY_CURRENT_USER\Software\DXFReaderNETDemoProgram", "CurrentSaveDXFPath", CurrentSaveDXFPath).ToString();


            CurrentLoadOBJPath = Registry.GetValue(@"HKEY_CURRENT_USER\Software\DXFReaderNETDemoProgram", "CurrentLoadOBJPath", CurrentLoadOBJPath).ToString();
            CurrentSaveBMPPath = Registry.GetValue(@"HKEY_CURRENT_USER\Software\DXFReaderNETDemoProgram", "CurrentSaveBMPPath", CurrentLoadDXFPath).ToString();




            dxfReaderNETControl1.PlotMarginTop = float.Parse(Registry.GetValue(@"HKEY_CURRENT_USER\Software\DXFReaderNETDemoProgram", "PlotMarginTop", 0.0F).ToString(), System.Globalization.CultureInfo.CurrentCulture);
            dxfReaderNETControl1.PlotMarginBottom = float.Parse(Registry.GetValue(@"HKEY_CURRENT_USER\Software\DXFReaderNETDemoProgram", "PlotMarginBottom", 0.0F).ToString(), System.Globalization.CultureInfo.CurrentCulture);
            dxfReaderNETControl1.PlotMarginLeft = float.Parse(Registry.GetValue(@"HKEY_CURRENT_USER\Software\DXFReaderNETDemoProgram", "PlotMarginLeft", 0.0F).ToString(), System.Globalization.CultureInfo.CurrentCulture);
            dxfReaderNETControl1.PlotMarginRight = float.Parse(Registry.GetValue(@"HKEY_CURRENT_USER\Software\DXFReaderNETDemoProgram", "PlotMarginRight", 0.0F).ToString(), System.Globalization.CultureInfo.CurrentCulture);

            dxfReaderNETControl1.PlotMarginTop = float.Parse(Registry.GetValue(@"HKEY_CURRENT_USER\Software\DXFReaderNETDemoProgram", "PlotMarginTop", 0.0F).ToString(), System.Globalization.CultureInfo.CurrentCulture);

            Vector2 po = new Vector2(float.Parse(Registry.GetValue(@"HKEY_CURRENT_USER\Software\DXFReaderNETDemoProgram", "PlotOffsetX", 0.0F).ToString(), System.Globalization.CultureInfo.CurrentCulture), float.Parse(Registry.GetValue(@"HKEY_CURRENT_USER\Software\DXFReaderNETDemoProgram", "PlotOffsetY", 0.0F).ToString(), System.Globalization.CultureInfo.CurrentCulture));
            dxfReaderNETControl1.PlotOffset = po;

            dxfReaderNETControl1.PlotScale = float.Parse(Registry.GetValue(@"HKEY_CURRENT_USER\Software\DXFReaderNETDemoProgram", "PlotScale", 1.0F).ToString(), System.Globalization.CultureInfo.CurrentCulture);
            dxfReaderNETControl1.PlotPenWidth = float.Parse(Registry.GetValue(@"HKEY_CURRENT_USER\Software\DXFReaderNETDemoProgram", "PlotPenWidth", 0.0F).ToString(), System.Globalization.CultureInfo.CurrentCulture);


            for (int i = 0; i < 10; i++)
            {
                string file_name = Registry.GetValue(@"HKEY_CURRENT_USER\Software\DXFReaderNETDemoProgram", "mru" + i.ToString(), "").ToString();

                if (file_name != "")
                {
                    FileInfos.Add(file_name);


                    RibbonOrbRecentItem newRecent = new RibbonOrbRecentItem(file_name);

                    newRecent.Click += new EventHandler(newRecent_Click);
                    ribbon1.OrbDropDown.RecentItems.Add(newRecent);
                }
            }


        }

        private void SaveRegistry()
        {
            Registry.SetValue(@"HKEY_CURRENT_USER\Software\DXFReaderNETDemoProgram", "CurrentLoadDXFPath", CurrentLoadDXFPath);
            Registry.SetValue(@"HKEY_CURRENT_USER\Software\DXFReaderNETDemoProgram", "CurrentSaveDXFPath", CurrentSaveDXFPath);
            Registry.SetValue(@"HKEY_CURRENT_USER\Software\DXFReaderNETDemoProgram", "CurrentLoadOBJPath", CurrentLoadOBJPath);
            Registry.SetValue(@"HKEY_CURRENT_USER\Software\DXFReaderNETDemoProgram", "CurrentSaveBMPPath", CurrentSaveBMPPath);


            Registry.SetValue(@"HKEY_CURRENT_USER\Software\DXFReaderNETDemoProgram", "GridDisplay", System.Convert.ToInt32(dxfReaderNETControl1.GridDisplay));

            Registry.SetValue(@"HKEY_CURRENT_USER\Software\DXFReaderNETDemoProgram", "ShowAxes", dxfReaderNETControl1.ShowAxes);
            Registry.SetValue(@"HKEY_CURRENT_USER\Software\DXFReaderNETDemoProgram", "ShowBasePoint", dxfReaderNETControl1.ShowBasePoint);
            Registry.SetValue(@"HKEY_CURRENT_USER\Software\DXFReaderNETDemoProgram", "ShowLimits", dxfReaderNETControl1.ShowLimits);
            Registry.SetValue(@"HKEY_CURRENT_USER\Software\DXFReaderNETDemoProgram", "ShowGrid", dxfReaderNETControl1.ShowGrid);
            Registry.SetValue(@"HKEY_CURRENT_USER\Software\DXFReaderNETDemoProgram", "ShowGridRuler", dxfReaderNETControl1.ShowGridRuler);
            Registry.SetValue(@"HKEY_CURRENT_USER\Software\DXFReaderNETDemoProgram", "AntiAlias", dxfReaderNETControl1.AntiAlias);



            switch (m_RubberBandType)
            {
                case RubberBandType.Solid:
                    Registry.SetValue(@"HKEY_CURRENT_USER\Software\DXFReaderNETDemoProgram", "RubberBandType", 1);
                    break;
                case RubberBandType.Dashed:
                    Registry.SetValue(@"HKEY_CURRENT_USER\Software\DXFReaderNETDemoProgram", "RubberBandType", 0);
                    break;
            }



            Registry.SetValue(@"HKEY_CURRENT_USER\Software\DXFReaderNETDemoProgram", "RubberBandColor", m_RubberBandColor.ToArgb());


            // Save the current entries.
            int i = 0;
            foreach (string file_info in FileInfos)
            {
                Registry.SetValue(@"HKEY_CURRENT_USER\Software\DXFReaderNETDemoProgram", "mru" + i.ToString(), file_info);

                i++;
            }

            Registry.SetValue(@"HKEY_CURRENT_USER\Software\DXFReaderNETDemoProgram", "ForeColor", dxfReaderNETControl1.ForeColor.ToArgb());
            Registry.SetValue(@"HKEY_CURRENT_USER\Software\DXFReaderNETDemoProgram", "BackColor", dxfReaderNETControl1.BackColor.ToArgb());
            Registry.SetValue(@"HKEY_CURRENT_USER\Software\DXFReaderNETDemoProgram", "HighlightMarkerColor", dxfReaderNETControl1.HighlightMarkerColor.ToArgb());
            Registry.SetValue(@"HKEY_CURRENT_USER\Software\DXFReaderNETDemoProgram", "HighlightColor", dxfReaderNETControl1.HighlightColor.ToArgb());
            Registry.SetValue(@"HKEY_CURRENT_USER\Software\DXFReaderNETDemoProgram", "AxisXColor", dxfReaderNETControl1.AxisXColor.ToArgb());
            Registry.SetValue(@"HKEY_CURRENT_USER\Software\DXFReaderNETDemoProgram", "AxisYColor", dxfReaderNETControl1.AxisYColor.ToArgb());
            Registry.SetValue(@"HKEY_CURRENT_USER\Software\DXFReaderNETDemoProgram", "AxisZColor", dxfReaderNETControl1.AxisZColor.ToArgb());
            Registry.SetValue(@"HKEY_CURRENT_USER\Software\DXFReaderNETDemoProgram", "AxesColor", dxfReaderNETControl1.AxesColor.ToArgb());
            Registry.SetValue(@"HKEY_CURRENT_USER\Software\DXFReaderNETDemoProgram", "GridColor", dxfReaderNETControl1.GridColor.ToArgb());

            Registry.SetValue(@"HKEY_CURRENT_USER\Software\DXFReaderNETDemoProgram", "wWidth", this.Width);
            Registry.SetValue(@"HKEY_CURRENT_USER\Software\DXFReaderNETDemoProgram", "wHeight", this.Height);
            Registry.SetValue(@"HKEY_CURRENT_USER\Software\DXFReaderNETDemoProgram", "wLeft", this.Left);
            Registry.SetValue(@"HKEY_CURRENT_USER\Software\DXFReaderNETDemoProgram", "wTop", this.Top);

            Registry.SetValue(@"HKEY_CURRENT_USER\Software\DXFReaderNETDemoProgram", "PlotRotation", System.Convert.ToInt32(dxfReaderNETControl1.PlotRotation));
            Registry.SetValue(@"HKEY_CURRENT_USER\Software\DXFReaderNETDemoProgram", "PlotRendering", System.Convert.ToInt32(dxfReaderNETControl1.PlotRendering));
            Registry.SetValue(@"HKEY_CURRENT_USER\Software\DXFReaderNETDemoProgram", "PlotMode", System.Convert.ToInt32(dxfReaderNETControl1.PlotMode));
            Registry.SetValue(@"HKEY_CURRENT_USER\Software\DXFReaderNETDemoProgram", "PlotUnits", System.Convert.ToInt32(dxfReaderNETControl1.PlotUnits));

            Registry.SetValue(@"HKEY_CURRENT_USER\Software\DXFReaderNETDemoProgram", "PlotMarginTop", dxfReaderNETControl1.PlotMarginTop);
            Registry.SetValue(@"HKEY_CURRENT_USER\Software\DXFReaderNETDemoProgram", "PlotMarginBottom", dxfReaderNETControl1.PlotMarginBottom);
            Registry.SetValue(@"HKEY_CURRENT_USER\Software\DXFReaderNETDemoProgram", "PlotMarginLeft", dxfReaderNETControl1.PlotMarginLeft);
            Registry.SetValue(@"HKEY_CURRENT_USER\Software\DXFReaderNETDemoProgram", "PlotMarginRight", dxfReaderNETControl1.PlotMarginRight);

            Registry.SetValue(@"HKEY_CURRENT_USER\Software\DXFReaderNETDemoProgram", "PlotOffsetX", dxfReaderNETControl1.PlotOffset.X);
            Registry.SetValue(@"HKEY_CURRENT_USER\Software\DXFReaderNETDemoProgram", "PlotOffsetY", dxfReaderNETControl1.PlotOffset.Y);

            Registry.SetValue(@"HKEY_CURRENT_USER\Software\DXFReaderNETDemoProgram", "PlotScale", dxfReaderNETControl1.PlotScale);
            Registry.SetValue(@"HKEY_CURRENT_USER\Software\DXFReaderNETDemoProgram", "PlotPenWidth", dxfReaderNETControl1.PlotPenWidth);


        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (!DiscardChanges())
            {
                e.Cancel = true;

            }
            else
            {
                SaveRegistry();
            }

        }



        private void ribbonButtonLineSingle_Click(object sender, EventArgs e)
        {
            CheckSnap();
            CurrentFunction = FunctionsEnum.Line1;
            StatusLabel.Text = "Select start point of the line";

        }

        private void CheckSnap()
        {
            if (dxfReaderNETControl1.ObjectOsnapMode != ObjectOsnapTypeFlags.None)
            {
                dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHairObjectSnap;
                if (CurrentFunction == FunctionsEnum.Area || CurrentFunction == FunctionsEnum.Distance1)
                    dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHairObjectSnapQuestionMark;
            }
        }


        private void ribbonButtonObjectSnapEndpoint_Click(object sender, EventArgs e)
        {

            SetObjectSnapMode();

        }

        private void ribbonButtonObjectSnapMidpoint_Click(object sender, EventArgs e)
        {

            SetObjectSnapMode();
        }
        private void SetObjectSnapMode()
        {
            ObjectOsnapTypeFlags m_OsnapMode = ObjectOsnapTypeFlags.None;
            if (ribbonButtonObjectSnapEndpoint.Checked)
                m_OsnapMode = m_OsnapMode | ObjectOsnapTypeFlags.Endpoint;

            if (ribbonButtonObjectSnapMidpoint.Checked)
                m_OsnapMode = m_OsnapMode | ObjectOsnapTypeFlags.Midpoint;

            if (ribbonButtonObjectSnapCenter.Checked)
                m_OsnapMode = m_OsnapMode | ObjectOsnapTypeFlags.Center;

            if (ribbonButtonObjectSnapIntersection.Checked)
                m_OsnapMode = m_OsnapMode | ObjectOsnapTypeFlags.Intersection;

            if (ribbonButtonObjectSnapQuadrant.Checked)
                m_OsnapMode = m_OsnapMode | ObjectOsnapTypeFlags.Quadrant;

            if (ribbonButtonObjectSnapPerpendicular.Checked)
                m_OsnapMode = m_OsnapMode | ObjectOsnapTypeFlags.Perpendicular;

            if (ribbonButtonObjectSnapTangent.Checked)
                m_OsnapMode = m_OsnapMode | ObjectOsnapTypeFlags.Tangent;

            if (ribbonButtonObjectSnapInsertion.Checked)
                m_OsnapMode = m_OsnapMode | ObjectOsnapTypeFlags.Insertion;

            if (ribbonButtonObjectSnapNearest.Checked)
                m_OsnapMode = m_OsnapMode | ObjectOsnapTypeFlags.Nearest;

            if (ribbonButtonObjectSnapNode.Checked)
                m_OsnapMode = m_OsnapMode | ObjectOsnapTypeFlags.Node;

            dxfReaderNETControl1.ObjectOsnapMode = m_OsnapMode;
        }

        private void ribbonButtonObjectSnapCenter_Click(object sender, EventArgs e)
        {
            SetObjectSnapMode();
        }

        private void ribbonButtonObjectSnapIntersection_Click(object sender, EventArgs e)
        {
            SetObjectSnapMode();
        }

        private void ribbonButtonObjectSnapQuadrant_Click(object sender, EventArgs e)
        {
            SetObjectSnapMode();
        }

        private void ribbonButtonObjectSnapPerpendicular_Click(object sender, EventArgs e)
        {
            SetObjectSnapMode();
        }

        private void ribbonButtonObjectSnapTangent_Click(object sender, EventArgs e)
        {
            SetObjectSnapMode();
        }

        private void ribbonButtonObjectSnapNode_Click(object sender, EventArgs e)
        {
            SetObjectSnapMode();
        }

        private void ribbonButtonObjectSnapNearest_Click(object sender, EventArgs e)
        {
            SetObjectSnapMode();
        }

        private void ribbonButtonObjectSnapInsertion_Click(object sender, EventArgs e)
        {
            SetObjectSnapMode();
        }

        private void ribbonButtonObjectSnapCenter_Click_1(object sender, EventArgs e)
        {
            SetObjectSnapMode();
        }

        private void ribbonButtonObjectSnapIntersection_Click_1(object sender, EventArgs e)
        {
            SetObjectSnapMode();
        }

        private void ribbonButtonRay_Click(object sender, EventArgs e)
        {
            VideoSize = Vector2.Distance(dxfReaderNETControl1.LowerLeftCorner, dxfReaderNETControl1.UpperRightCorner);
            StatusLabel.Text = "Select origin of the ray";
            CurrentFunction = FunctionsEnum.Ray1;
            CheckSnap();
        }

        private void ribbonButtonConstructionLine_Click(object sender, EventArgs e)
        {
            VideoSize = Vector2.Distance(dxfReaderNETControl1.LowerLeftCorner, dxfReaderNETControl1.UpperRightCorner);
            StatusLabel.Text = "Select origin of construction line";
            CurrentFunction = FunctionsEnum.Xline1;
            CheckSnap();
        }

        private void ribbonButtonRectangle_Click(object sender, EventArgs e)
        {
            CheckSnap();
            CurrentFunction = FunctionsEnum.Rectangle1;

            StatusLabel.Text = "Select start corner of the rectangle";
        }

        private void ribbonButtonTrace_Click(object sender, EventArgs e)
        {

            string inputValue = dxfReaderNETControl1.DXF.DrawingVariables.Tracewidth.ToString();
            if (ShowInputDialog(ref inputValue, "Trace width?", true) == DialogResult.OK)
            {
                double Tracewidth = double.Parse(inputValue, System.Globalization.CultureInfo.CurrentCulture);

                if (Tracewidth > 0)
                {
                    dxfReaderNETControl1.DXF.DrawingVariables.Tracewidth = Tracewidth;
                    CheckSnap();
                    CurrentFunction = FunctionsEnum.Trace1;

                    StatusLabel.Text = "Select start point of the trace";
                }
            }

        }
        private static DialogResult ShowInputDialog(ref string inputValue, string prompt, bool forceNumeric)
        {

            InputDialog inputBox = new InputDialog();
            inputBox.textBox1.Text = inputValue;
            inputBox.label1.Text = prompt;
            inputBox.ForceNumeric = forceNumeric;

            DialogResult result = inputBox.ShowDialog();
            inputValue = inputBox.textBox1.Text;
            return result;
        }

        private void ribbonButtonSolid_Click(object sender, EventArgs e)
        {
            CheckSnap();
            CurrentFunction = FunctionsEnum.Solid1;

            StatusLabel.Text = "Select first point";
        }

        private void ribbonButtonSave_Click(object sender, EventArgs e)
        {
            ribbonOrbMenuItem3_Click(sender, e);
        }

        private void ribbonButtonUndo_Click(object sender, EventArgs e)
        {
            if (m_LastAddedEntity != null)
            {
                dxfReaderNETControl1.DXF.RemoveEntity(m_LastAddedEntity);
                m_LastAddedEntity = null;
                dxfReaderNETControl1.Refresh();
            }
        }

        private void ribbonButtonEllipse_Click(object sender, EventArgs e)
        {
            CheckSnap();
            CurrentFunction = FunctionsEnum.Ellipse1;
            StatusLabel.Text = "Select axis start point";
        }



        private void ribbonButtonCircleTwoPoints_Click(object sender, EventArgs e)
        {
            CheckSnap();
            CurrentFunction = FunctionsEnum.Circle2p1;
            StatusLabel.Text = "Select diameter start point";
        }

        private void dxfReaderNETControl1_EndRead(object sender, EndReadEventArgs e)
        {
            toolStripProgressBar1.Value = 0;
            StatusLabel.Text = "DXF file loaded";
            Application.DoEvents();
        }

        private void dxfReaderNETControl1_EndDrawing(object sender, EndDrawingEventArgs e)
        {
            toolStripProgressBar1.Value = 0;
            StatusLabel.Text = "";
            Application.DoEvents();
        }

        private void ribbonButtonNew_Click(object sender, EventArgs e)
        {
            ribbonOrbMenuItem1_Click(sender, e);
        }

        private void ribbonButtonDrawingInfo_Click(object sender, EventArgs e)
        {
            dxfReaderNETControl1.ShowDrawingInfo();
        }

        private void ribbonButtonShowAxes_Click(object sender, EventArgs e)
        {
            dxfReaderNETControl1.ShowAxes = ribbonButtonShowAxes.Checked;
            dxfReaderNETControl1.Refresh();
        }

        private void ribbonButtonShowBasepoint_Click(object sender, EventArgs e)
        {
            dxfReaderNETControl1.ShowBasePoint = ribbonButtonShowBasepoint.Checked;
            dxfReaderNETControl1.Refresh();
        }

        private void ribbonButtonShowLimits_Click(object sender, EventArgs e)
        {
            dxfReaderNETControl1.ShowLimits = ribbonButtonShowLimits.Checked;
            dxfReaderNETControl1.Refresh();
        }

        private void ribbonButtonAntialias_Click(object sender, EventArgs e)
        {
            dxfReaderNETControl1.AntiAlias = ribbonButtonAntialias.Checked;
            dxfReaderNETControl1.Refresh();
        }


        private void ribbonButtonDrawPolylineRectangle_Click(object sender, EventArgs e)
        {
            CheckSnap();
            CurrentFunction = FunctionsEnum.Rectangle1;

            StatusLabel.Text = "Select start corner of the rectangle";
        }

        private void ribbonPanelProperites_ButtonMoreClick(object sender, EventArgs e)
        {
            dxfReaderNETControl1.ShowLayers();
        }

        private void ribbonButtonDrawLineTrace_Click(object sender, EventArgs e)
        {
            string inputValue = dxfReaderNETControl1.DXF.DrawingVariables.Tracewidth.ToString();
            if (ShowInputDialog(ref inputValue, "Trace width", true) == DialogResult.OK)
            {
                double Tracewidth = double.Parse(inputValue, System.Globalization.CultureInfo.CurrentCulture);

                if (Tracewidth > 0)
                {
                    dxfReaderNETControl1.DXF.DrawingVariables.Tracewidth = Tracewidth;
                    CheckSnap();
                    CurrentFunction = FunctionsEnum.Trace1;

                    StatusLabel.Text = "Select start point of the trace";
                }
            }
        }

        private void ribbonButtonDrawPolylineSolid_Click(object sender, EventArgs e)
        {
            CheckSnap();
            CurrentFunction = FunctionsEnum.Solid1;

            StatusLabel.Text = "Select first point";
        }

        private void ribbonButtonDrawPolylinePolygon_Click(object sender, EventArgs e)
        {
            string inputValue = PolygonSides.ToString();
            if (ShowInputDialog(ref inputValue, "Polygon sides", true) == DialogResult.OK)
            {
                short nSides = short.Parse(inputValue, System.Globalization.CultureInfo.CurrentCulture);

                if (nSides > 2)
                {
                    PolygonSides = nSides;
                    CheckSnap();
                    CurrentFunction = FunctionsEnum.Polygon1;

                    StatusLabel.Text = "Select center point";
                }
            }
        }

        private void ribbonButtonDrawImageImage_Click(object sender, EventArgs e)
        {
            ImageSelector imageSelector = new ImageSelector();
            imageSelector.TextBoxFileName.Text = m_ImageFileName;
            imageSelector.TextBoxRotation.Text = m_ImageRotation;
            imageSelector.ComboBox1.SelectedIndex = imageSelector.ComboBox1.FindString(m_ImageTransparency);
            imageSelector.checkBoxScaleOnScreen.Checked = m_ImageScaleOnScreen;
            if (imageSelector.ShowDialog() == DialogResult.OK)
            {
                m_ImageFileName = imageSelector.TextBoxFileName.Text;
                if (m_ImageFileName != "")
                {
                    m_ImageRotation = imageSelector.TextBoxRotation.Text;
                    m_ImageTransparency = imageSelector.ComboBox1.Text;

                    CheckSnap();

                    var imgsrc = new Bitmap(m_ImageFileName);
                    m_ImageWidth = imgsrc.Width;
                    m_ImageHeight = imgsrc.Height;
                    imgsrc.Dispose();
                    m_ImageScaleOnScreen = imageSelector.checkBoxScaleOnScreen.Checked;
                    if (m_ImageScaleOnScreen)
                    {
                        StatusLabel.Text = "Select start corner of the image";
                        CurrentFunction = FunctionsEnum.Image1;
                    }
                    else
                    {
                        StatusLabel.Text = "Select the position of the image";
                        CurrentFunction = FunctionsEnum.ImageFixedSize;

                    }

                }
            }
        }

        private void ribbonButtonDrawImagePDF_Click(object sender, EventArgs e)
        {
            PDFSelector pdfSelector = new PDFSelector();
            pdfSelector.TextBoxFileName.Text = m_PDFFileName;
            pdfSelector.TextBoxRotation.Text = m_PDFRotation;
            pdfSelector.TextBoxScale.Text = m_PDFScale;
            pdfSelector.ComboBox1.SelectedIndex = pdfSelector.ComboBox1.FindString(m_PDFTransparency);

            if (pdfSelector.ShowDialog() == DialogResult.OK)
            {
                m_PDFFileName = pdfSelector.TextBoxFileName.Text;
                m_PDFRotation = pdfSelector.TextBoxRotation.Text;
                m_PDFTransparency = pdfSelector.ComboBox1.Text;
                m_PDFScale = pdfSelector.TextBoxScale.Text;
                CheckSnap();
                CurrentFunction = FunctionsEnum.PDFUnderlay;

                StatusLabel.Text = "Select the position of the PDF underlay";
            }
        }

        private void ribbonButtonDrawImage_Click(object sender, EventArgs e)
        {
            if (NumBlocks() > 0)
                ribbonButtonDrawInsertBlock_Click(sender, e);
        }

        private void ribbonButtonDrawLineSingle_Click(object sender, EventArgs e)
        {
            CheckSnap();
            CurrentFunction = FunctionsEnum.Line1;

            StatusLabel.Text = "Select start point of the line";
        }

        private void ribbonButtonDrawLine_Click(object sender, EventArgs e)
        {
            ribbonButtonDrawLineSingle_Click(sender, e);
        }

        private void ribbonButtonDrawLineRay_Click(object sender, EventArgs e)
        {
            VideoSize = Vector2.Distance(dxfReaderNETControl1.LowerLeftCorner, dxfReaderNETControl1.UpperRightCorner);
            StatusLabel.Text = "Select origin of the ray";
            CurrentFunction = FunctionsEnum.Ray1;
            CheckSnap();
        }

        private void ribbonButtonDrawContructionLine_Click(object sender, EventArgs e)
        {
            VideoSize = Vector2.Distance(dxfReaderNETControl1.LowerLeftCorner, dxfReaderNETControl1.UpperRightCorner);
            StatusLabel.Text = "Select origin of construction line";
            CurrentFunction = FunctionsEnum.Xline1;
            CheckSnap();
        }

        private void ribbonButtonDrawCircleRadius_Click(object sender, EventArgs e)
        {
            StatusLabel.Text = "Select center point";
            CurrentFunction = FunctionsEnum.Circle1;
            CheckSnap();
        }

        private void ribbonButtonDrawCircle2Points_Click(object sender, EventArgs e)
        {
            CheckSnap();
            CurrentFunction = FunctionsEnum.Circle2p1;

            StatusLabel.Text = "Select diameter start point";
        }

        private void ribbonButtonDrawCircle3Points_Click(object sender, EventArgs e)
        {
            StatusLabel.Text = "Select first point";
            CurrentFunction = FunctionsEnum.Circle3p1;
            CheckSnap();
        }

        private void ribbonButtonDrawCircle_Click(object sender, EventArgs e)
        {
            ribbonButtonDrawCircleRadius_Click(sender, e);
        }

        private void ribbonComboBox3D_DropDownItemClicked(object sender, RibbonItemEventArgs e)
        {
            switch (((RibbonComboBox)sender).SelectedItem.Text)
            {
                case "Top":
                    dxfReaderNETControl1.DisplayPredefinedView(PredefinedViewType.Top);
                    ribbonComboBox3D.Image = ribbonButtonView3DTop.SmallImage;

                    break;
                case "Bottom":
                    dxfReaderNETControl1.DisplayPredefinedView(PredefinedViewType.Bottom);
                    ribbonComboBox3D.Image = ribbonButtonView3DBottom.SmallImage;
                    break;
                case "Left":
                    dxfReaderNETControl1.DisplayPredefinedView(PredefinedViewType.Left);
                    ribbonComboBox3D.Image = ribbonButtonView3DLeft.SmallImage;
                    break;
                case "Right":
                    dxfReaderNETControl1.DisplayPredefinedView(PredefinedViewType.Right);
                    ribbonComboBox3D.Image = ribbonButtonView3DRight.SmallImage;
                    break;
                case "Front":
                    dxfReaderNETControl1.DisplayPredefinedView(PredefinedViewType.Front);
                    ribbonComboBox3D.Image = ribbonButtonView3DFront.SmallImage;
                    break;
                case "Back":
                    dxfReaderNETControl1.DisplayPredefinedView(PredefinedViewType.Back);
                    ribbonComboBox3D.Image = ribbonButtonView3DBack.SmallImage;
                    break;
                case "SW Isometric":
                    dxfReaderNETControl1.DisplayPredefinedView(PredefinedViewType.SW_Isometric);
                    ribbonComboBox3D.Image = ribbonButtonView3DSW.SmallImage;
                    break;
                case "SE Isometric":
                    dxfReaderNETControl1.DisplayPredefinedView(PredefinedViewType.SE_Isometric);
                    ribbonComboBox3D.Image = ribbonButtonView3DSE.SmallImage;
                    break;
                case "NE Isometric":
                    dxfReaderNETControl1.DisplayPredefinedView(PredefinedViewType.NE_Isometric);
                    ribbonComboBox3D.Image = ribbonButtonView3DNE.SmallImage;
                    break;
                case "NW Isometric":
                    dxfReaderNETControl1.DisplayPredefinedView(PredefinedViewType.NW_Isometric);
                    ribbonComboBox3D.Image = ribbonButtonView3DNW.SmallImage;
                    break;
            }

        }


        private void ribbonComboBoxViews_DropDownItemClicked(object sender, RibbonItemEventArgs e)
        {
            if (((RibbonComboBox)sender).SelectedItem.Text != "")
            {
                dxfReaderNETControl1.DisplayView(((RibbonComboBox)sender).SelectedItem.Text.Trim());
            }

        }

        private void ribbonComboBoxRendering_DropDownItemClicked(object sender, RibbonItemEventArgs e)
        {
            switch (((RibbonComboBox)sender).SelectedItem.Text)
            {
                case "Wireframe":
                    dxfReaderNETControl1.Rendering = RenderingType.WireFrame;
                    ribbonComboBoxRendering.Image = ribbonButtonRenderingWireframe.SmallImage;
                    break;
                case "Shaded":
                    dxfReaderNETControl1.Rendering = RenderingType.Shaded;
                    ribbonComboBoxRendering.Image = ribbonButtonRenderingShaded.SmallImage;
                    break;
                case "Shaded edges":
                    dxfReaderNETControl1.Rendering = RenderingType.ShadedEdges;
                    ribbonComboBoxRendering.Image = ribbonButtonRenderingShadedEdges.SmallImage;
                    break;

            }
        }

        private void ribbonComboBoxLayers_DropDownItemClicked(object sender, RibbonItemEventArgs e)
        {
            if (((RibbonComboBox)sender).SelectedItem.Text != "")
            {
                dxfReaderNETControl1.DXF.CurrentLayer = ((RibbonComboBox)sender).SelectedItem.Text.Trim();
            }
        }

        private void ribbonColorChooserColor_Click(object sender, EventArgs e)
        {
            dxfReaderNETControl1.DXF.CurrentColor = dxfReaderNETControl1.ShowPalette(dxfReaderNETControl1.DXF.CurrentColor);
            ribbonColorChooserColor.Color = dxfReaderNETControl1.DXF.CurrentColor.ToColor();
            ribbonLabelCurrentColor.Text = dxfReaderNETControl1.DXF.CurrentColor.ToString();
        }

        private void ribbonLabel3_Click(object sender, EventArgs e)
        {
            ribbonColorChooserColor_Click(sender, e);
        }

        private void ribbonLabelCurrentColor_Click(object sender, EventArgs e)
        {
            ribbonColorChooserColor_Click(sender, e);
        }

        private void ribbonPanelInquiry_ButtonMoreClick(object sender, EventArgs e)
        {
            dxfReaderNETControl1.ShowDrawingInfo();
        }

        private void ribbonButtonInquiryMeasureDistance_Click(object sender, EventArgs e)
        {
            CheckSnap();
            CurrentFunction = FunctionsEnum.Distance1;

            StatusLabel.Text = "Select start point";
        }

        private void ribbonButtonInquiryMeasure_Click(object sender, EventArgs e)
        {
            ribbonButtonInquiryMeasureDistance_Click(sender, e);
        }

        private void ribbonButtonInquiryEntityInfo_Click(object sender, EventArgs e)
        {
            CurrentFunction = FunctionsEnum.EntityProperties;
            dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHairSquareQuestionMark;
            StatusLabel.Text = "Select entity";
        }

        private void ribbonButtonInquiryTest_Click(object sender, EventArgs e)
        {

            TestRoutine();



        }

        private void ribbonComboBoxLineTypes_DropDownItemClicked(object sender, RibbonItemEventArgs e)
        {
            if (((RibbonComboBox)sender).SelectedItem.Text != "")
            {
                dxfReaderNETControl1.DXF.CurrentLineTypeName = ((RibbonComboBox)sender).SelectedItem.Text.Trim();
            }
        }

        private void ribbonButtonDrawPolyline_Click(object sender, EventArgs e)
        {
            string inputValue = dxfReaderNETControl1.DXF.DrawingVariables.Polylinewidth.ToString();
            if (ShowInputDialog(ref inputValue, "Polyline width", true) == DialogResult.OK)
            {
                double Polylinewidth = double.Parse(inputValue, System.Globalization.CultureInfo.CurrentCulture);

                if (Polylinewidth >= 0)
                {
                    dxfReaderNETControl1.DXF.DrawingVariables.Polylinewidth = Polylinewidth;
                    CheckSnap();
                    CurrentFunction = FunctionsEnum.Polyline;
                    vertexes.Clear();
                    StatusLabel.Text = "Select points with left mouse click. Right mouse click to end.";
                }
            }
        }

        private void ribbonButtonInquiryMeasureArea_Click(object sender, EventArgs e)
        {
            CheckSnap();
            CurrentFunction = FunctionsEnum.Area;
            vertexes.Clear();
            StatusLabel.Text = "Select points with left mouse click. Right mouse click to end.";
        }

        private void ribbonButtonDrawPoint_Click(object sender, EventArgs e)
        {
            CurrentFunction = FunctionsEnum.Point;

            StatusLabel.Text = "Select point";
        }

        private void ribbonButtonDrawMethodsLine_Click(object sender, EventArgs e)
        {
            CheckSnap();
            CurrentFunction = FunctionsEnum.DrawLine1;

            StatusLabel.Text = "Select start point of the line";
        }

        private void ribbonButtonDrawMethodsColor_Click(object sender, EventArgs e)
        {
            Cdialog.Text = "Drawing methods color";
            Cdialog.Color = CurrentDrawColor;

            if (Cdialog.ShowDialog() == DialogResult.OK)
            {
                CurrentDrawColor = Cdialog.Color;

            }
        }

        private void ribbonButtonDrawMethodsPenWidth_Click(object sender, EventArgs e)
        {

            PenSelector penSelector = new PenSelector();
            penSelector.TextBoxPenWidth.Text = CurrentDrawPenWidth.ToString();
            penSelector.textBoxDashLength.Text = CurrentDrawDashLength.ToString();
            penSelector.textBoxSkipLength.Text = CurrentDrawSkipLength.ToString();
            penSelector.ComboBox1.SelectedIndex = penSelector.ComboBox1.FindString(CurrentDrawPenStyle);


            if (penSelector.ShowDialog() == DialogResult.OK)
            {
                CurrentDrawPenWidth = float.Parse(penSelector.TextBoxPenWidth.Text, System.Globalization.CultureInfo.CurrentCulture);
                CurrentDrawDashLength = float.Parse(penSelector.textBoxDashLength.Text, System.Globalization.CultureInfo.CurrentCulture);
                CurrentDrawSkipLength = float.Parse(penSelector.textBoxSkipLength.Text, System.Globalization.CultureInfo.CurrentCulture);

                CurrentDrawPenStyle = penSelector.ComboBox1.Text;

            }
        }

        private void ribbonButton9_Click_1(object sender, EventArgs e)
        {
            dxfReaderNETControl1.ClearDrawnElements();
        }

        private void ribbonButtonDrawMethodsCircle_Click(object sender, EventArgs e)
        {
            StatusLabel.Text = "Select center point";
            CurrentFunction = FunctionsEnum.DrawCircle1;
            CheckSnap();
        }

        private void ribbonButtonArcCenterStartEnd_Click(object sender, EventArgs e)
        {
            StatusLabel.Text = "Select center point";
            CurrentFunction = FunctionsEnum.Arc1;
            CheckSnap();
        }

        private void ribbonButtonArc_Click(object sender, EventArgs e)
        {
            ribbonButtonArcCenterStartEnd_Click(sender, e);
        }

        private void ribbonButtonArcStartMiddleEnd_Click(object sender, EventArgs e)
        {


            StatusLabel.Text = "Select start point";
            CurrentFunction = FunctionsEnum.ArcStartMiddleEnd1;
            CheckSnap();
        }

        private void ribbonButtonDrawMethodsArc_Click(object sender, EventArgs e)
        {
            StatusLabel.Text = "Select center point";
            CurrentFunction = FunctionsEnum.DrawArc1;
            CheckSnap();
        }

        private void ribbonColorChooserDrawMethodsColor_Click(object sender, EventArgs e)
        {
            Cdialog.Text = "Drawing methods pen color";
            Cdialog.Color = CurrentDrawColor;

            if (Cdialog.ShowDialog() == DialogResult.OK)
            {
                CurrentDrawColor = Cdialog.Color;
                ribbonColorChooserDrawMethodsColor.Color = CurrentDrawColor;
            }
        }

        private void ribbonButtonDrawMethodsPoint_Click(object sender, EventArgs e)
        {
            StatusLabel.Text = "Select point";
            CurrentFunction = FunctionsEnum.DrawPoint;
            CheckSnap();
        }

        private void ribbonButtonDrawMethodsPolygon_Click(object sender, EventArgs e)
        {
            CheckSnap();
            CurrentFunction = FunctionsEnum.DrawPolygon;
            vertexes.Clear();
            StatusLabel.Text = "Select points with left mouse click. Right mouse click to end.";
        }

        private void ribbonButtonDrawPolylinePolyline_Click(object sender, EventArgs e)
        {
            ribbonButtonDrawPolyline_Click(sender, e);
        }

        private void ribbonButtonDrawPolylineLwPolyline_Click(object sender, EventArgs e)
        {
            string inputValue = dxfReaderNETControl1.DXF.DrawingVariables.Polylinewidth.ToString();
            if (ShowInputDialog(ref inputValue, "Polyline width", true) == DialogResult.OK)
            {
                double Polylinewidth = double.Parse(inputValue, System.Globalization.CultureInfo.CurrentCulture);

                if (Polylinewidth >= 0)
                {
                    dxfReaderNETControl1.DXF.DrawingVariables.Polylinewidth = Polylinewidth;
                    CheckSnap();
                    CurrentFunction = FunctionsEnum.LwPolyline;
                    vertexes.Clear();
                    StatusLabel.Text = "Select points with left mouse click. Right mouse click to end.";
                }
            }
        }

        private void ribbonButtonDrawMethodsImage_Click(object sender, EventArgs e)
        {
            ImageSelector imageSelector = new ImageSelector();
            imageSelector.TextBoxFileName.Text = m_ImageFileName;
            imageSelector.TextBoxRotation.Text = m_ImageRotation;
            imageSelector.ComboBox1.SelectedIndex = imageSelector.ComboBox1.FindString(m_ImageTransparency);
            imageSelector.checkBoxScaleOnScreen.Checked = m_ImageScaleOnScreen;
            if (imageSelector.ShowDialog() == DialogResult.OK)
            {
                m_ImageFileName = imageSelector.TextBoxFileName.Text;
                if (m_ImageFileName != "")
                {
                    m_ImageRotation = imageSelector.TextBoxRotation.Text;
                    m_ImageTransparency = imageSelector.ComboBox1.Text;


                    var imgsrc = new Bitmap(m_ImageFileName);
                    m_ImageWidth = imgsrc.Width;
                    m_ImageHeight = imgsrc.Height;
                    imgsrc.Dispose();
                    m_ImageScaleOnScreen = imageSelector.checkBoxScaleOnScreen.Checked;
                    if (m_ImageScaleOnScreen)
                    {
                        StatusLabel.Text = "Select start corner of the image";
                        CurrentFunction = FunctionsEnum.DrawImage1;
                    }
                    else
                    {
                        StatusLabel.Text = "Select the position of the image";
                        CurrentFunction = FunctionsEnum.DrawImageFixedSize;

                    }

                }
            }
        }

        private void ribbonButtonModifySelectSinlge_Click(object sender, EventArgs e)
        {

            CurrentFunction = FunctionsEnum.GetEntity;
            dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHairSquare;
            StatusLabel.Text = "Select entity";
        }

        private void ribbonButtonModifySelect_Click(object sender, EventArgs e)
        {
            ribbonButtonModifySelectSinlge_Click(sender, e);
        }

        private void ribbonButtonModifySelectRectangle_Click(object sender, EventArgs e)
        {
            CurrentFunction = FunctionsEnum.GetEntities1;

            StatusLabel.Text = "Select start point of selection rectangle";
        }

        private void ribbonButtonModifySelectAll_Click(object sender, EventArgs e)
        {
            dxfReaderNETControl1.DXF.SelectedEntities.Clear();

            foreach (EntityObject ent in dxfReaderNETControl1.DXF.Entities)
            {
                if (ent.IsVisible && dxfReaderNETControl1.DXF.Layers[ent.Layer.Name].IsVisible)
                {
                    if (!dxfReaderNETControl1.DXF.SelectedEntities.Contains(ent))
                        dxfReaderNETControl1.DXF.SelectedEntities.Add(ent);
                }
            }

            dxfReaderNETControl1.HighLight(dxfReaderNETControl1.DXF.SelectedEntities);
        }

        private void ribbonButtonModyfiSelectClear_Click(object sender, EventArgs e)
        {
            dxfReaderNETControl1.DXF.SelectedEntities.Clear();
            dxfReaderNETControl1.Refresh();
        }

        private void ribbonButtonModifyDeleteSelected_Click(object sender, EventArgs e)
        {

            if (MessageBox.Show("Are you sure?", "DXFReader.NET Demo Program", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                dxfReaderNETControl1.DXF.RemoveEntities(dxfReaderNETControl1.DXF.SelectedEntities);
                dxfReaderNETControl1.DXF.SelectedEntities.Clear();
                dxfReaderNETControl1.Refresh();

            }

        }

        private void ribbonButtonModifyDelete_Click(object sender, EventArgs e)
        {
            if (dxfReaderNETControl1.DXF.SelectedEntities.Count > 0)
                ribbonButtonModifyDeleteSelected_Click(sender, e);
        }

        private void ribbonButtonModifyDeleteNotSelected_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure?", "DXFReader.NET Demo Program", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                if (dxfReaderNETControl1.DXF.SelectedEntities != null)
                {
                    dxfReaderNETControl1.DXF.RemoveEntities();
                    dxfReaderNETControl1.DXF.AddEntities(dxfReaderNETControl1.DXF.SelectedEntities);
                    dxfReaderNETControl1.DXF.SelectedEntities.Clear();
                    dxfReaderNETControl1.Refresh();
                }

            }
        }

        private void ribbonButtonModifyDeleteHandle_Click(object sender, EventArgs e)
        {
            string handle = "";
            if (ShowInputDialog(ref handle, "Delete entity with handle?", false) == DialogResult.OK)
            {
                if (handle != "")
                {
                    dxfReaderNETControl1.DXF.RemoveObject(handle);
                    dxfReaderNETControl1.Refresh();
                }
            }
        }

        private void ribbonButtonModifyDeleteButHandle_Click(object sender, EventArgs e)
        {
            string handle = "";
            if (ShowInputDialog(ref handle, "Delete all entities BUT entity with handle?", false) == DialogResult.OK)
            {
                if (handle != "")
                {
                    List<EntityObject> myEntities = dxfReaderNETControl1.DXF.Entities;
                    for (int k = 0; k < myEntities.Count; k++)
                    {
                        if (myEntities[k].Handle.ToLower() != handle.ToLower())
                        {
                            dxfReaderNETControl1.DXF.RemoveObject(myEntities[k].Handle);
                        }
                    }

                    dxfReaderNETControl1.Refresh();
                }
            }
        }

        private void ribbonButtonModidyCopyCopy_Click(object sender, EventArgs e)
        {
            if (dxfReaderNETControl1.DXF.SelectedEntities.Count > 0)
            {
                CurrentFunction = FunctionsEnum.CopyEntities1;
                StatusLabel.Text = "Select base point";
            }
        }

        private void ribbonButtonModifyCopyMove_Click(object sender, EventArgs e)
        {
            CurrentFunction = FunctionsEnum.MoveEntities1;

            StatusLabel.Text = "Select base point";
        }

        private void ribbonButtonModifyCopy_Click(object sender, EventArgs e)
        {
            ribbonButtonModidyCopyCopy_Click(sender, e);
        }

        private void ribbonButtonModifyCopyRotate_Click(object sender, EventArgs e)
        {


            string inputValue = m_rotation.ToString();
            if (ShowInputDialog(ref inputValue, "Rotation angle [°]", true) == DialogResult.OK)
            {
                m_rotation = double.Parse(inputValue, System.Globalization.CultureInfo.CurrentCulture);

                if (m_rotation != 0)
                {
                    CurrentFunction = FunctionsEnum.RotateEntities;
                    CheckSnap();
                    StatusLabel.Text = "Select base point";
                }
            }

        }

        private void ribbonButtonModifyDelete_DropDownShowing(object sender, EventArgs e)
        {
            if (dxfReaderNETControl1.DXF.SelectedEntities.Count == 0)
            {
                ribbonButtonModifyDeleteSelected.Enabled = false;
                ribbonButtonModifyDeleteNotSelected.Enabled = false;
            }
            else
            {
                ribbonButtonModifyDeleteSelected.Enabled = true;
                ribbonButtonModifyDeleteNotSelected.Enabled = true;
            }
        }

        private void ribbonButtonModifySelect_DropDownShowing(object sender, EventArgs e)
        {
            if (dxfReaderNETControl1.DXF.SelectedEntities.Count == 0)
            {
                ribbonButtonModyfiSelectClear.Enabled = false;

            }
            else
            {
                ribbonButtonModyfiSelectClear.Enabled = true;

            }
        }

        private void ribbonOrbMenuItemImport_Click(object sender, EventArgs e)
        {

            openFileDialog1.DefaultExt = "obj";
            openFileDialog1.Filter = "Wavefront .OBJ file|*.obj";
            openFileDialog1.FileName = "";
            openFileDialog1.InitialDirectory = CurrentLoadOBJPath;
            openFileDialog1.Title = "Import file";
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                if (dxfReaderNETControl1.ReadOBJ(openFileDialog1.FileName))
                {
                    StatusLabel.Text = "File '" + openFileDialog1.FileName + "' imported.";
                    CurrentLoadOBJPath = Path.GetDirectoryName(openFileDialog1.FileName);
                }
            }
        }

        private void ribbonOrbMenuItemExport_Click(object sender, EventArgs e)
        {
            saveFileDialog1.DefaultExt = "jpg";
            saveFileDialog1.Filter = "JPEG (*.jpg)|*.jpg|PNG (*.png)|*.png|BMP (*.bmp)|*.bmp";
            saveFileDialog1.FileName = "";
            saveFileDialog1.FilterIndex = 1;
            saveFileDialog1.Title = "Export file";

            saveFileDialog1.InitialDirectory = CurrentSaveBMPPath;

            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                CurrentSaveBMPPath = Path.GetDirectoryName(saveFileDialog1.FileName);
                switch (saveFileDialog1.FilterIndex)
                {
                    case 1:
                        dxfReaderNETControl1.Image.Save(saveFileDialog1.FileName, System.Drawing.Imaging.ImageFormat.Jpeg);
                        break;
                    case 2:
                        dxfReaderNETControl1.Image.Save(saveFileDialog1.FileName, System.Drawing.Imaging.ImageFormat.Png);
                        break;
                    case 3:
                        dxfReaderNETControl1.Image.Save(saveFileDialog1.FileName, System.Drawing.Imaging.ImageFormat.Bmp);
                        break;

                }

            }
        }

        private void ribbonButtonSaveAs_Click(object sender, EventArgs e)
        {
            ribbonOrbMenuItem4_Click(sender, e);
        }

        private void ribbonButtonModifySelectSingleMulti_Click(object sender, EventArgs e)
        {
            CurrentFunction = FunctionsEnum.GetEntities;
            dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHairSquare;
            StatusLabel.Text = "Select entities or press right button to end";
        }

        private void ribbonButtonModifyCopy_DropDownShowing(object sender, EventArgs e)
        {
            if (dxfReaderNETControl1.DXF.SelectedEntities.Count == 0)
            {
                foreach (RibbonButton item in ribbonButtonModifyCopy.DropDownItems)
                {
                    item.Enabled = false;
                }

            }
            else
            {
                foreach (RibbonButton item in ribbonButtonModifyCopy.DropDownItems)
                {
                    item.Enabled = true;
                }
            }
        }

        private void ribbonButtonDrawLineContinous_Click(object sender, EventArgs e)
        {
            CurrentFunction = FunctionsEnum.Lines;
            CheckSnap();
            StatusLabel.Text = "Select points with left mouse click. Right mouse clic to end.";
        }

        private void ribbonButtonSplineControlPoints_Click(object sender, EventArgs e)
        {
            CurrentFunction = FunctionsEnum.Spline;
            CheckSnap();
            StatusLabel.Text = "Select control points with left mouse click. Right mouse clic to end.";
        }



        private void ribbonButtonGridRuler_Click(object sender, EventArgs e)
        {
            dxfReaderNETControl1.ShowGridRuler = !dxfReaderNETControl1.ShowGridRuler;
        }

        private void ribbonButtonDrawHatchNormal_Click(object sender, EventArgs e)
        {
            HatchSelector hatchSelector = new HatchSelector();
            hatchSelector.TextBoxScale.Text = m_HatchScale;
            hatchSelector.TextBoxRotation.Text = m_HatchRotation;

            hatchSelector.ComboBox1.Items.Clear();

            hatchSelector.ComboBox1.Items.AddRange(new object[] {
            "SOLID",
            "ANGLE",
            "ANSI31",
            "ANSI32",
            "ANSI33",
            "ANSI34",
            "ANSI35",
            "ANSI36",
            "ANSI37",
            "ANSI38",
            "AR-B816",
            "AR-B816C",
            "AR-B88",
            "AR-BRELM",
            "AR-BRSTD",
            "AR-CONC",
            "AR-HBONE",
            "AR-PARQ1",
            "AR-RROOF",
            "AR-RSHKE",
            "AR-SAND",
            "BOX",
            "BRASS",
            "BRICK",
            "BRSTONE",
            "CLAY",
            "CORK",
            "CROSS",
            "DASH",
            "DOLMIT",
            "DOTS",
            "EARTH",
            "ESCHER",
            "FLEX",
            "GRASS",
            "GRATE",
            "GRAVEL",
            "HEX",
            "HONEY",
            "HOUND",
            "INSUL",
            "ACAD_ISO02W100",
            "ACAD_ISO03W100",
            "ACAD_ISO04W100",
            "ACAD_ISO05W100",
            "ACAD_ISO06W100",
            "ACAD_ISO07W100",
            "ACAD_ISO08W100",
            "ACAD_ISO09W100",
            "ACAD_ISO10W100",
            "ACAD_ISO11W100",
            "ACAD_ISO12W100",
            "ACAD_ISO13W100",
            "ACAD_ISO14W100",
            "ACAD_ISO15W100",
            "LINE",
            "MUDST",
            "NET",
            "NET3",
            "PLAST",
            "PLASTI",
            "SACNCR",
            "SQUARE",
            "STARS",
            "STEEL",
            "SWAMP",
            "TRANS",
            "TRIANG",
            "ZIGZAG"});
            if (hatchPatternsCustom != null)
            {
                for (int k = 0; k < hatchPatternsCustom.Count; k++)
                {
                    hatchSelector.ComboBox1.Items.Add(hatchPatternsCustom[k].Name);
                }

            }
            hatchSelector.ComboBox1.SelectedIndex = hatchSelector.ComboBox1.FindString(m_PatternName);
            hatchSelector.comboBox2.SelectedIndex = hatchSelector.comboBox2.FindString(m_HatchBoundaries);


            if (hatchSelector.ShowDialog() == DialogResult.OK)
            {
                m_HatchScale = hatchSelector.TextBoxScale.Text;
                m_HatchRotation = hatchSelector.TextBoxRotation.Text;
                m_PatternName = hatchSelector.ComboBox1.Text;

                m_HatchBoundaries = hatchSelector.comboBox2.Text;
                Boundary.Clear();
                BoundaryOutermost.Clear();

                switch (m_HatchBoundaries)
                {
                    case "Choose entities":
                        dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHairSquare;
                        StatusLabel.Text = "Select entities with left mouse click. Right mouse clic to finish.";
                        CurrentFunction = FunctionsEnum.Hatch;
                        break;
                    case "Define polygon":
                        CheckSnap();
                        StatusLabel.Text = "Select points with left mouse click. Right mouse clic to close.";
                        CurrentFunction = FunctionsEnum.HatchBoundaries;
                        break;

                }
            }

        }

        private void ribbonButtonDrawHatch_Click(object sender, EventArgs e)
        {
            ribbonButtonDrawHatchNormal_Click(sender, e);
        }



        private void ribbonButtonDrawHatchGradient_Click(object sender, EventArgs e)
        {
            GradientSelector gradientSelector = new GradientSelector();

            gradientSelector.TextBoxRotation.Text = m_GradientHatchRotation;
            gradientSelector.ComboBox1.SelectedIndex = gradientSelector.ComboBox1.FindString(m_GradientPatternName);
            gradientSelector.comboBox2.SelectedIndex = gradientSelector.comboBox2.FindString(m_GradientHatchBoundaries);
            gradientSelector.checkBoxCentered.Checked = m_GradientHatchCentered;
            gradientSelector.buttonColor1.BackColor = AciColor.FromCadIndex(m_GradientAciColor1).ToColor();
            gradientSelector.buttonColor2.BackColor = AciColor.FromCadIndex(m_GradientAciColor2).ToColor();

            gradientSelector.buttonColor1.Tag = m_GradientAciColor1;
            gradientSelector.buttonColor2.Tag = m_GradientAciColor2;

            if (gradientSelector.ShowDialog() == DialogResult.OK)
            {

                m_GradientHatchCentered = gradientSelector.checkBoxCentered.Checked;
                m_GradientAciColor1 = (short)gradientSelector.buttonColor1.Tag;
                m_GradientAciColor2 = (short)gradientSelector.buttonColor2.Tag;

                m_GradientHatchRotation = gradientSelector.TextBoxRotation.Text;
                m_GradientPatternName = gradientSelector.ComboBox1.Text;

                m_GradientHatchBoundaries = gradientSelector.comboBox2.Text;
                Boundary.Clear();
                BoundaryOutermost.Clear();

                switch (m_GradientHatchBoundaries)
                {
                    case "Choose entities":
                        dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHairSquare;
                        StatusLabel.Text = "Select entities with left mouse click. Right mouse clic to finish.";
                        CurrentFunction = FunctionsEnum.GradientHatch;
                        break;
                    case "Define polygon":
                        CheckSnap();
                        StatusLabel.Text = "Select points with left mouse click. Right mouse clic to close.";
                        CurrentFunction = FunctionsEnum.GradientHatchBoundaries;
                        break;

                }
            }
        }

        private void ribbonButtonViewRefresh_Click(object sender, EventArgs e)
        {
            dxfReaderNETControl1.Refresh();
        }

        private void ribbonButtonViewPan_Click(object sender, EventArgs e)
        {
            CurrentFunction = FunctionsEnum.Pan1;

            StatusLabel.Text = "Select start point";
        }

        private void ribbonButtonInquiryMeasurecenter_Click(object sender, EventArgs e)
        {
            CurrentFunction = FunctionsEnum.LocatePoint;
            dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHairQuestionMark;

            StatusLabel.Text = "Select the point with a mouse clic";

        }

        private void ribbonButtonInquiryMeasureRadius_Click(object sender, EventArgs e)
        {
            CurrentFunction = FunctionsEnum.Radius;
            dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHairSquareQuestionMark;

            StatusLabel.Text = "Select circle or arc";
        }

        private void ribbonButtonInquiryMeasurePoly_Click(object sender, EventArgs e)
        {
            CurrentFunction = FunctionsEnum.PolylineLenght;
            dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHairQuestionMark;
            StatusLabel.Text = "Select points with left mouse click. Right mouse click to end.";
        }

        private void ribbonButtonModifyExplodeInsert_Click(object sender, EventArgs e)
        {
            CurrentFunction = FunctionsEnum.ExplodeInsert;
            dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHairSquareQuestionMark;
            StatusLabel.Text = "Select insert entity";
        }

        private void ribbonButtonModifyExplodePoly_Click(object sender, EventArgs e)
        {
            CurrentFunction = FunctionsEnum.ExplodePoly;
            dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHairSquareQuestionMark;
            StatusLabel.Text = "Select polyline or light weight polyline entity";
        }

        private void ribbonButtonModifyExplodeCircle_Click(object sender, EventArgs e)
        {
            CurrentFunction = FunctionsEnum.ExplodeCircle;
            dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHairSquareQuestionMark;
            StatusLabel.Text = "Select circle entity";
        }

        private void ribbonButtonModifyExplodeArc_Click(object sender, EventArgs e)
        {
            CurrentFunction = FunctionsEnum.ExplodeArc;
            dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHairSquareQuestionMark;
            StatusLabel.Text = "Select arc entity";
        }

        private void ribbonButtonModifyExplodeEllipse_Click(object sender, EventArgs e)
        {
            CurrentFunction = FunctionsEnum.ExplodeEllipse;
            dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHairSquareQuestionMark;
            StatusLabel.Text = "Select ellipse entity";
        }

        private void ribbonButtonModifyLines2Poly_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure?", "DXFReader.NET Demo Program", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                LwPolyline newPoly = new LwPolyline(dxfReaderNETControl1.DXF.SelectedEntities);
                if (newPoly != null)
                {
                    if (newPoly.Vertexes.Count > 0)
                    {
                        newPoly.Color = dxfReaderNETControl1.DXF.CurrentColor;
                        dxfReaderNETControl1.DXF.AddEntity(newPoly);
                        dxfReaderNETControl1.DXF.RemoveEntities(dxfReaderNETControl1.DXF.SelectedEntities);
                        dxfReaderNETControl1.DXF.SelectedEntities.Clear();
                        dxfReaderNETControl1.Refresh();
                    }
                }

            }
        }

        private void ribbonButtonModifyOffset_Click(object sender, EventArgs e)
        {
            string inputValue = m_offset.ToString();
            if (ShowInputDialog(ref inputValue, "Specify offset:", true) == DialogResult.OK)
            {
                m_offset = double.Parse(inputValue, System.Globalization.CultureInfo.CurrentCulture);

                if (m_offset != 0)
                {
                    CurrentFunction = FunctionsEnum.Offset1;

                    dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHairSquare;
                    StatusLabel.Text = "Select entity to offset";
                }
            }
        }

        private void ribbonButtonHelpRegister_Click(object sender, EventArgs e)
        {
            dxfReaderNETControl1.RegisterComponent();
        }

        private void ribbonButtonHelpAbout_Click(object sender, EventArgs e)
        {
            dxfReaderNETControl1.About();
        }

        private void ribbonButtonModifyBlock_Click(object sender, EventArgs e)
        {

            string inputValue = m_newBlockName;
            if (ShowInputDialog(ref inputValue, "Block name?", false) == DialogResult.OK)
            {

                if (inputValue != "")
                {
                    m_newBlockName = inputValue.ToUpper();
                    bool blockExists = false;
                    foreach (DXFReaderNET.Blocks.Block blk in dxfReaderNETControl1.DXF.Blocks)
                    {
                        if (blk.Name.ToUpper() == m_newBlockName)
                        {
                            blockExists = true;
                            break;
                        }
                    }

                    if (blockExists)
                    {
                        StatusLabel.Text = "Block name already exists";
                    }
                    else
                    {
                        CheckSnap();
                        CurrentFunction = FunctionsEnum.Block;
                        StatusLabel.Text = "Select base point";
                    }
                }
            }


        }

        private void ribbonButtonDrawInsertBlock_Click(object sender, EventArgs e)
        {

            BlockSelector blockSelector = new BlockSelector();
            blockSelector.TextBoxScale.Text = m_BlockScale;
            blockSelector.TextBoxRotation.Text = m_BlockRotation;
            blockSelector.ComboBox1.Items.Clear();
            blockSelector.DXFReaderNETControl = dxfReaderNETControl1;
            foreach (DXFReaderNET.Blocks.Block _block in dxfReaderNETControl1.DXF.Blocks.Items)
            {
                if (_block.Entities.Count > 0 || _block.AttributeDefinitions.Count > 0)
                {
                    if (!_block.Name.StartsWith("*"))
                        blockSelector.ComboBox1.Items.Add(_block.Name.ToString());
                }
            }

            if (m_BlockName != "")
            {
                blockSelector.ComboBox1.SelectedIndex = blockSelector.ComboBox1.FindString(m_BlockName);
            }
            if (blockSelector.ShowDialog() == DialogResult.OK)
            {

                m_BlockRotation = blockSelector.TextBoxRotation.Text;
                m_BlockName = blockSelector.ComboBox1.Text;
                m_BlockScale = blockSelector.TextBoxScale.Text;
                if (m_BlockName != "")
                {

                    CheckSnap();
                    CurrentFunction = FunctionsEnum.Insert;
                    StatusLabel.Text = "Select insertion point";
                }

            }
        }

        private void ribbonButtonModifyRotate_Click(object sender, EventArgs e)
        {
            CurrentFunction = FunctionsEnum.RotateAxis1;
            CheckSnap();
            StatusLabel.Text = "Select start point of the mirror axis";

        }


        private void ribbonButtonShowgrid_Click(object sender, EventArgs e)
        {
            StatusLabelGrid_Click(sender, e);
        }

        private void ribbonButtonAnnotationsDimensionAlignedStartEnd_Click(object sender, EventArgs e)
        {
            CheckSnap();
            CurrentFunction = FunctionsEnum.AlignedDimension1;
            StatusLabel.Text = "Select start point";
        }

        private void ribbonButtonAnnotationsDimensionAlignedLine_Click(object sender, EventArgs e)
        {

            dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHairSquare;
            CurrentFunction = FunctionsEnum.AlignedDimensionLine1;
            StatusLabel.Text = "Select line";
        }

        private void ribbonButtonAnnotationsText_Click(object sender, EventArgs e)
        {
            string inputValue = m_Text;
            if (ShowInputDialog(ref inputValue, "Text?", false) == DialogResult.OK)
            {

                if (inputValue != "")
                {
                    m_Text = inputValue;

                    inputValue = dxfReaderNETControl1.DXF.CurrentTextSize.ToString();
                    if (ShowInputDialog(ref inputValue, "Text height?", true) == DialogResult.OK)
                    {
                        dxfReaderNETControl1.DXF.CurrentTextSize = double.Parse(inputValue, System.Globalization.CultureInfo.CurrentCulture);

                        if (dxfReaderNETControl1.DXF.CurrentTextSize > 0)
                        {
                            CheckSnap();
                            CurrentFunction = FunctionsEnum.Text;
                            StatusLabel.Text = "Select insert point";
                        }
                    }

                }
            }
        }

        private void ribbonButtonAnnotationsDimensionLinearStartEnd_Click(object sender, EventArgs e)
        {
            CheckSnap();
            CurrentFunction = FunctionsEnum.LinearDimension1;
            StatusLabel.Text = "Select start point";
        }

        private void ribbonButtonAnnotationsDimensionLinearLine_Click(object sender, EventArgs e)
        {
            dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHairSquare;
            CurrentFunction = FunctionsEnum.LinearDimensionLine1;
            StatusLabel.Text = "Select line";
        }

        private bool SelectLineFromEntity(EntityObject ent)
        {
            switch (ent.Type)
            {
                case EntityType.Line:

                    SelectedLine = (Line)ent;
                    p1 = p;
                    return true;

                case EntityType.LightWeightPolyline:
                    LwPolyline lw = (LwPolyline)ent;
                    SelectedLine = null;
                    for (int k = 0; k < lw.Vertexes.Count - 1; k++)
                    {
                        Vector2 ps = lw.Vertexes[k].Position;
                        Vector2 pe = lw.Vertexes[k + 1].Position;
                        double bulge = lw.Vertexes[k].Bulge;
                        if (MathHelper.IsZero(bulge))
                        {

                            if (MathHelper.PointOnLineSegment(ps, pe, p1))
                            {
                                SelectedLine = new Line();
                                SelectedLine.StartPoint = ps.ToVector3();
                                SelectedLine.EndPoint = pe.ToVector3();
                                break;

                            }
                        }
                    }
                    if (lw.IsClosed && SelectedLine == null)
                    {
                        Vector2 ps = lw.Vertexes[lw.Vertexes.Count - 1].Position;
                        Vector2 pe = lw.Vertexes[0].Position;
                        double bulge = lw.Vertexes[lw.Vertexes.Count - 1].Bulge;
                        if (MathHelper.IsZero(bulge))
                        {

                            if (MathHelper.PointOnLineSegment(ps, pe, p1))
                            {
                                SelectedLine = new Line();
                                SelectedLine.StartPoint = ps.ToVector3();
                                SelectedLine.EndPoint = pe.ToVector3();

                            }
                        }
                    }
                    if (SelectedLine != null)
                    {
                        return true;

                    }
                    else
                    {
                        StatusLabel.Text = "No entity found";
                        return false;
                    }

                case EntityType.Polyline:
                    Polyline polyline = (Polyline)ent;
                    SelectedLine = null;
                    for (int k = 0; k < polyline.Vertexes.Count - 1; k++)
                    {
                        Vector2 ps = polyline.Vertexes[k].Position.ToVector2();
                        Vector2 pe = polyline.Vertexes[k + 1].Position.ToVector2();
                        double bulge = polyline.Vertexes[k].Bulge;
                        if (MathHelper.IsZero(bulge))
                        {

                            if (MathHelper.PointOnLineSegment(ps, pe, p1))
                            {
                                SelectedLine = new Line();
                                SelectedLine.StartPoint = ps.ToVector3();
                                SelectedLine.EndPoint = pe.ToVector3();
                                break;

                            }
                        }
                    }
                    if (polyline.IsClosed && SelectedLine == null)
                    {
                        Vector2 ps = polyline.Vertexes[polyline.Vertexes.Count - 1].Position.ToVector2();
                        Vector2 pe = polyline.Vertexes[0].Position.ToVector2();
                        double bulge = polyline.Vertexes[polyline.Vertexes.Count - 1].Bulge;
                        if (MathHelper.IsZero(bulge))
                        {

                            if (MathHelper.PointOnLineSegment(ps, pe, p1))
                            {
                                SelectedLine = new Line();
                                SelectedLine.StartPoint = ps.ToVector3();
                                SelectedLine.EndPoint = pe.ToVector3();

                            }
                        }
                    }
                    if (SelectedLine != null)
                    {
                        return true;

                    }
                    else
                    {
                        StatusLabel.Text = "No entity found";
                        return false;
                    }

                default:
                    StatusLabel.Text = "Selected entity is not a line";
                    return false;

            }


        }

        private void ribbonButtonAnnotationsDimensionAngular2Lines_Click(object sender, EventArgs e)
        {
            dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHairSquare;
            CurrentFunction = FunctionsEnum.AngularDimension2Lines1;
            StatusLabel.Text = "Select first line";
        }

        private void ribbonButtonAnnotationsDimensionAngularArc_Click(object sender, EventArgs e)
        {
            dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHairSquare;
            CurrentFunction = FunctionsEnum.AngularDimensionArc1;
            StatusLabel.Text = "Select arc";
        }

        private void ribbonButtonAnnotationsDimensionAngular3points_Click(object sender, EventArgs e)
        {
            CheckSnap();
            CurrentFunction = FunctionsEnum.AngularDimensionCenterStartEnd1;
            StatusLabel.Text = "Select center point";
        }

        private void ribbonButtonAnnotationsDimensionDiameter_Click(object sender, EventArgs e)
        {
            dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHairSquare;
            CurrentFunction = FunctionsEnum.DiametricDimension1;
            StatusLabel.Text = "Select circle or arc";
        }

        private void ribbonButtonAnnotationsDimensionradius_Click(object sender, EventArgs e)
        {
            dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHairSquare;
            CurrentFunction = FunctionsEnum.RadialDimension1;
            StatusLabel.Text = "Select circle or arc";
        }

        private void ribbonComboBoxDimensionStyle_DropDownItemClicked(object sender, RibbonItemEventArgs e)
        {
            if (((RibbonComboBox)sender).SelectedItem.Text != "")
            {
                dxfReaderNETControl1.DXF.DrawingVariables.DimStyle = ((RibbonComboBox)sender).SelectedItem.Text.Trim();
            }
        }



        private void ribbonButtonAnnotationsDimension_Click(object sender, EventArgs e)
        {
            ribbonButtonAnnotationsDimensionAlignedStartEnd_Click(sender, e);
        }

        private void ribbonButtonDrawMethodstext_Click(object sender, EventArgs e)
        {
            string inputValue = m_DrawText;
            if (ShowInputDialog(ref inputValue, "Text?", false) == DialogResult.OK)
            {

                if (inputValue != "")
                {
                    m_DrawText = inputValue;

                    inputValue = m_DrawTextHeight.ToString();
                    if (ShowInputDialog(ref inputValue, "Text height?", true) == DialogResult.OK)
                    {
                        m_DrawTextHeight = double.Parse(inputValue, System.Globalization.CultureInfo.CurrentCulture);

                        if (m_DrawTextHeight > 0)
                        {
                            CheckSnap();
                            CurrentFunction = FunctionsEnum.DrawText;
                            StatusLabel.Text = "Select insert point";
                        }
                    }

                }
            }
        }

        private void ribbonButtonPropertiesUnits_Click(object sender, EventArgs e)
        {
            dxfReaderNETControl1.ShowDrawingUnits();
        }

        private void ribbonButtonDrawMethodsClearPoints_Click(object sender, EventArgs e)
        {
            dxfReaderNETControl1.ClearDrawnElements(DrawElementsType.Points);
        }

        private void ribbonButtonDrawMethodsClearLines_Click(object sender, EventArgs e)
        {
            dxfReaderNETControl1.ClearDrawnElements(DrawElementsType.Lines);
        }

        private void ribbonButtonDrawMethodsClearCircles_Click(object sender, EventArgs e)
        {
            dxfReaderNETControl1.ClearDrawnElements(DrawElementsType.Circles);
        }

        private void ribbonButtonDrawMethodsClearArcs_Click(object sender, EventArgs e)
        {
            dxfReaderNETControl1.ClearDrawnElements(DrawElementsType.Arcs);
        }

        private void ribbonButtonDrawMethodsClearPolygons_Click(object sender, EventArgs e)
        {
            dxfReaderNETControl1.ClearDrawnElements(DrawElementsType.Polygons);
        }

        private void ribbonButtonDrawMethodsClearTexts_Click(object sender, EventArgs e)
        {
            dxfReaderNETControl1.ClearDrawnElements(DrawElementsType.Texts);
        }

        private void ribbonButtonDrawMethodsClearImages_Click(object sender, EventArgs e)
        {
            dxfReaderNETControl1.ClearDrawnElements(DrawElementsType.Images);
        }

        private void ribbonTextBoxLtScale_TextBoxKeyPress(object sender, KeyPressEventArgs e)
        {

            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != decimalSeparetor))
            {
                e.Handled = true;
            }

        }

        private void ribbonTextBoxElevation_TextBoxKeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != decimalSeparetor))
            {
                e.Handled = true;
            }
        }

        private void ribbonTextBoxThickness_TextBoxKeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != decimalSeparetor))
            {
                e.Handled = true;
            }
        }

        private void ribbonTextBoxLtScale_TextBoxValidated(object sender, EventArgs e)
        {
            dxfReaderNETControl1.DXF.CurrentLineTypeScale = double.Parse(ribbonTextBoxLtScale.TextBoxText, System.Globalization.CultureInfo.CurrentCulture);
        }

        private void ribbonTextBoxElevation_TextBoxValidated(object sender, EventArgs e)
        {
            dxfReaderNETControl1.DXF.CurrentElevation = double.Parse(ribbonTextBoxElevation.TextBoxText, System.Globalization.CultureInfo.CurrentCulture);
        }

        private void ribbonTextBoxThickness_TextBoxValidated(object sender, EventArgs e)
        {
            dxfReaderNETControl1.DXF.CurrentThickness = double.Parse(ribbonTextBoxThickness.TextBoxText, System.Globalization.CultureInfo.CurrentCulture);
        }

        private void ribbonButtonTest2_Click(object sender, EventArgs e)
        {

            CurrentFunction = FunctionsEnum.MoveEnt1;
            StatusLabel.Text = "Select entity";

            dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHairSquare;

        }

        private void ribbonButtonTest3_Click(object sender, EventArgs e)
        {
            CurrentFunction = FunctionsEnum.MoveEntitiesRubber1;

            StatusLabel.Text = "Select start point of selection rectangle";
        }

        private void ribbonColorChooserRubberBand_Click(object sender, EventArgs e)
        {


            colorDialog1.Color = m_RubberBandColor;

            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                m_RubberBandColor = colorDialog1.Color;

                ribbonColorChooserRubberBand.Color = colorDialog1.Color;
            }
        }

        private void ribbonButtonExplodeSplineSingle_Click(object sender, EventArgs e)
        {
            CurrentFunction = FunctionsEnum.ExplodeSpline;
            dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHairSquareQuestionMark;
            StatusLabel.Text = "Select spline entity";
        }

        private void ribbonButtonExplodeSplineRectangle_Click(object sender, EventArgs e)
        {
            CurrentFunction = FunctionsEnum.ExplodeSplineRect1;
            StatusLabel.Text = "Select start point of selection rectangle";
        }

        private void ribbonButtonPlotPreview_Click(object sender, EventArgs e)
        {
            ribbonOrbMenuItem5_Click(sender, e);
        }

        private void printPreviewControl1_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)

            {
                case Keys.Escape:
                    printPreviewControl1.Visible = false;
                    dxfReaderNETControl1.Visible = true;

                    break;

            }
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            printPreviewControl1.Visible = false;
            dxfReaderNETControl1.Visible = true;
            ribbon1.Visible = true;
            toolStripPlotPreview.Visible = false;
            OnPlotPreview = false;

        }

        private void ribbonOrbMenuItemPlot_Click(object sender, EventArgs e)
        {


            if (dxfReaderNETControl1.PlotMode == PlotModeType.Window)
            {
                CurrentFunction = FunctionsEnum.PlotWindow1;
                StatusLabel.Text = "Select start point of the ploting window";
            }
            else
            {

                PlotDrawing();

            }


        }

        private void PlotDrawing()
        {
            PrintDialog pd = new PrintDialog();

            if (pd.ShowDialog() == DialogResult.OK)
            {
                dxfReaderNETControl1.Plot(pd.PrinterSettings.PrinterName, pd.PrinterSettings.Copies);
            }
        }

        private void toolStripButtonPlot_Click(object sender, EventArgs e)
        {

            ribbonOrbMenuItemPlot_Click(sender, e);
        }

        private void ribbonButtonPlotModeDisplay_Click(object sender, EventArgs e)
        {
            dxfReaderNETControl1.PlotMode = PlotModeType.Display;
        }

        private void ribbonButtonPlotModeExtents_Click(object sender, EventArgs e)
        {
            dxfReaderNETControl1.PlotMode = PlotModeType.Extents;
        }

        private void ribbonButtonPlotModeLimits_Click(object sender, EventArgs e)
        {
            dxfReaderNETControl1.PlotMode = PlotModeType.Limits;
        }

        private void ribbonButtonPlotModeWindow_Click(object sender, EventArgs e)
        {
            dxfReaderNETControl1.PlotMode = PlotModeType.Window;
        }

        private void ribbonButtonPlotRenderingColor_Click(object sender, EventArgs e)
        {
            dxfReaderNETControl1.PlotRendering = PlotRenderingType.Color;
        }

        private void ribbonButtonPlotRenderingGrayScale_Click(object sender, EventArgs e)
        {
            dxfReaderNETControl1.PlotRendering = PlotRenderingType.GrayScale;
        }

        private void ribbonButtonPlotRenderingMonochrome_Click(object sender, EventArgs e)
        {
            dxfReaderNETControl1.PlotRendering = PlotRenderingType.Monochrome;
        }

        private void ribbonButtonPlotRotationPortrait_Click(object sender, EventArgs e)
        {
            dxfReaderNETControl1.PlotRotation = PlotOrientationType.Portrait;
        }

        private void ribbonButtonPlotRotationLandscape_Click(object sender, EventArgs e)
        {
            dxfReaderNETControl1.PlotRotation = PlotOrientationType.Landscape;
        }

        private void ribbonButtonPlotUnitsInchs_Click(object sender, EventArgs e)
        {
            dxfReaderNETControl1.PlotUnits = PlotUnitsType.Inchs;
        }

        private void ribbonButtonPlotUnitsMillimeters_Click(object sender, EventArgs e)
        {
            dxfReaderNETControl1.PlotUnits = PlotUnitsType.Millimeters;
        }

        private void ribbonButtonDrawPolylineSpline_Click(object sender, EventArgs e)
        {
            CurrentFunction = FunctionsEnum.Spline;
            CheckSnap();
            vertexes.Clear();
            StatusLabel.Text = "Select control points with left mouse click. Right mouse clic to end.";
        }

        private void ribbonUpDownPlotMarginTop_DownButtonClicked(object sender, MouseEventArgs e)
        {
            float value = dxfReaderNETControl1.PlotMarginTop;
            switch (dxfReaderNETControl1.PlotUnits)
            {
                case PlotUnitsType.Millimeters:
                    if (value > 0) value -= 1;
                    dxfReaderNETControl1.PlotMarginTop = value;
                    ribbonUpDownPlotMarginTop.TextBoxText = value.ToString("###0");
                    break;
                case PlotUnitsType.Inchs:
                    if (value > 0) value -= 0.1F;
                    dxfReaderNETControl1.PlotMarginTop = value;
                    ribbonUpDownPlotMarginTop.TextBoxText = value.ToString("#0.0");
                    break;


            }

        }

        private void ribbonUpDownPlotMarginTop_UpButtonClicked(object sender, MouseEventArgs e)
        {
            float value = dxfReaderNETControl1.PlotMarginTop;
            switch (dxfReaderNETControl1.PlotUnits)
            {
                case PlotUnitsType.Millimeters:
                    if (value < 290) value += 1;
                    dxfReaderNETControl1.PlotMarginTop = value;
                    ribbonUpDownPlotMarginTop.TextBoxText = value.ToString("###0");
                    break;
                case PlotUnitsType.Inchs:
                    if (value < 11) value += 0.1F;
                    dxfReaderNETControl1.PlotMarginTop = value;
                    ribbonUpDownPlotMarginTop.TextBoxText = value.ToString("#0.0");
                    break;


            }

        }

        private void ribbonUpDownPlotMarginBottom_DownButtonClicked(object sender, MouseEventArgs e)
        {
            float value = dxfReaderNETControl1.PlotMarginBottom;
            switch (dxfReaderNETControl1.PlotUnits)
            {
                case PlotUnitsType.Millimeters:
                    if (value > 0) value -= 1;
                    dxfReaderNETControl1.PlotMarginBottom = value;
                    ribbonUpDownPlotMarginBottom.TextBoxText = value.ToString("###0");
                    break;
                case PlotUnitsType.Inchs:
                    if (value > 0) value -= 0.1F;
                    dxfReaderNETControl1.PlotMarginBottom = value;
                    ribbonUpDownPlotMarginBottom.TextBoxText = value.ToString("#0.0");
                    break;


            }

        }

        private void ribbonUpDownPlotMarginBottom_UpButtonClicked(object sender, MouseEventArgs e)
        {
            float value = dxfReaderNETControl1.PlotMarginBottom;
            switch (dxfReaderNETControl1.PlotUnits)
            {
                case PlotUnitsType.Millimeters:
                    if (value < 290) value += 1;
                    dxfReaderNETControl1.PlotMarginBottom = value;
                    ribbonUpDownPlotMarginBottom.TextBoxText = value.ToString("###0");
                    break;
                case PlotUnitsType.Inchs:
                    if (value < 11) value += 0.1F;
                    dxfReaderNETControl1.PlotMarginBottom = value;
                    ribbonUpDownPlotMarginBottom.TextBoxText = value.ToString("#0.0");
                    break;


            }

        }

        private void ribbonUpDownPlotMarginLeft_DownButtonClicked(object sender, MouseEventArgs e)
        {
            float value = dxfReaderNETControl1.PlotMarginLeft;
            switch (dxfReaderNETControl1.PlotUnits)
            {
                case PlotUnitsType.Millimeters:
                    if (value > 0) value -= 1;
                    dxfReaderNETControl1.PlotMarginLeft = value;
                    ribbonUpDownPlotMarginLeft.TextBoxText = value.ToString("###0");
                    break;
                case PlotUnitsType.Inchs:
                    if (value > 0) value -= 0.1F;
                    dxfReaderNETControl1.PlotMarginLeft = value;
                    ribbonUpDownPlotMarginLeft.TextBoxText = value.ToString("#0.0");
                    break;


            }
        }

        private void ribbonUpDownPlotMarginLeft_UpButtonClicked(object sender, MouseEventArgs e)
        {
            float value = dxfReaderNETControl1.PlotMarginLeft;
            switch (dxfReaderNETControl1.PlotUnits)
            {
                case PlotUnitsType.Millimeters:
                    if (value < 210) value += 1;
                    dxfReaderNETControl1.PlotMarginLeft = value;
                    ribbonUpDownPlotMarginLeft.TextBoxText = value.ToString("###0");
                    break;
                case PlotUnitsType.Inchs:
                    if (value < 8.5) value += 0.1F;
                    dxfReaderNETControl1.PlotMarginLeft = value;
                    ribbonUpDownPlotMarginLeft.TextBoxText = value.ToString("#0.0");
                    break;


            }
        }

        private void ribbonUpDownPlotMarginRight_DownButtonClicked(object sender, MouseEventArgs e)
        {
            float value = dxfReaderNETControl1.PlotMarginRight;
            switch (dxfReaderNETControl1.PlotUnits)
            {
                case PlotUnitsType.Millimeters:
                    if (value > 0) value -= 1;
                    dxfReaderNETControl1.PlotMarginRight = value;
                    ribbonUpDownPlotMarginRight.TextBoxText = value.ToString("###0");
                    break;
                case PlotUnitsType.Inchs:
                    if (value > 0) value -= 0.1F;
                    dxfReaderNETControl1.PlotMarginRight = value;
                    ribbonUpDownPlotMarginRight.TextBoxText = value.ToString("#0.0");
                    break;


            }
        }

        private void ribbonUpDownPlotMarginRight_UpButtonClicked(object sender, MouseEventArgs e)
        {
            float value = dxfReaderNETControl1.PlotMarginRight;
            switch (dxfReaderNETControl1.PlotUnits)
            {
                case PlotUnitsType.Millimeters:
                    if (value < 210) value += 1;
                    dxfReaderNETControl1.PlotMarginRight = value;
                    ribbonUpDownPlotMarginRight.TextBoxText = value.ToString("###0");
                    break;
                case PlotUnitsType.Inchs:
                    if (value < 8.5) value += 0.1F;
                    dxfReaderNETControl1.PlotMarginRight = value;
                    ribbonUpDownPlotMarginRight.TextBoxText = value.ToString("#0.0");
                    break;


            }
        }

        private void ribbonUpDownPlotMarginTop_TextBoxKeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != decimalSeparetor))
            {
                e.Handled = true;
            }
        }

        private void ribbonUpDownPlotMarginTop_TextBoxValidated(object sender, EventArgs e)
        {
            dxfReaderNETControl1.PlotMarginTop = float.Parse(ribbonUpDownPlotMarginTop.TextBoxText, System.Globalization.CultureInfo.CurrentCulture);
        }

        private void ribbonUpDownPlotMarginBottom_TextBoxKeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != decimalSeparetor))
            {
                e.Handled = true;
            }
        }

        private void ribbonUpDownPlotMarginLeft_TextBoxKeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != decimalSeparetor))
            {
                e.Handled = true;
            }
        }

        private void ribbonUpDownPlotMarginLeft_TextBoxValidated(object sender, EventArgs e)
        {
            dxfReaderNETControl1.PlotMarginLeft = float.Parse(ribbonUpDownPlotMarginLeft.TextBoxText, System.Globalization.CultureInfo.CurrentCulture);
        }

        private void ribbonUpDownPlotMarginBottom_TextBoxValidated(object sender, EventArgs e)
        {
            dxfReaderNETControl1.PlotMarginBottom = float.Parse(ribbonUpDownPlotMarginBottom.TextBoxText, System.Globalization.CultureInfo.CurrentCulture);
        }

        private void ribbonUpDownPlotMarginRight_TextBoxKeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != decimalSeparetor))
            {
                e.Handled = true;
            }
        }

        private void ribbonUpDownPlotMarginRight_TextBoxValidated(object sender, EventArgs e)
        {
            dxfReaderNETControl1.PlotMarginRight = float.Parse(ribbonUpDownPlotMarginRight.TextBoxText, System.Globalization.CultureInfo.CurrentCulture);
        }

        private void ribbonTextBoxPlotOriginX_TextBoxKeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != decimalSeparetor))
            {
                e.Handled = true;
            }
        }

        private void ribbonTextBoxPlotOriginX_TextBoxValidated(object sender, EventArgs e)
        {
            Vector2 po = new Vector2(float.Parse(ribbonTextBoxPlotOriginX.TextBoxText, System.Globalization.CultureInfo.CurrentCulture), dxfReaderNETControl1.PlotOffset.Y);
            dxfReaderNETControl1.PlotOffset = po;
        }

        private void ribbonTextBoxPlotOriginY_TextBoxKeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != decimalSeparetor))
            {
                e.Handled = true;
            }
        }

        private void ribbonTextBoxPlotOriginY_TextBoxValidated(object sender, EventArgs e)
        {
            Vector2 po = new Vector2(dxfReaderNETControl1.PlotOffset.X, float.Parse(ribbonTextBoxPlotOriginY.TextBoxText, System.Globalization.CultureInfo.CurrentCulture));
            dxfReaderNETControl1.PlotOffset = po;
        }

        private void ribbonTextBoxPlotScale_TextBoxKeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != decimalSeparetor))
            {
                e.Handled = true;
            }
        }

        private void ribbonTextBoxPlotScale_TextBoxValidated(object sender, EventArgs e)
        {
            dxfReaderNETControl1.PlotScale = float.Parse(ribbonTextBoxPlotScale.TextBoxText, System.Globalization.CultureInfo.CurrentCulture);
        }

        private void ribbonUpDownPlotPenWidth_DownButtonClicked(object sender, MouseEventArgs e)
        {
            float value = dxfReaderNETControl1.PlotPenWidth;
            if (value > 0) value -= 1;
            dxfReaderNETControl1.PlotPenWidth = value;
            ribbonUpDownPlotPenWidth.TextBoxText = MathHelper.ToFormattedUnit(value);
        }

        private void ribbonUpDownPlotPenWidth_UpButtonClicked(object sender, MouseEventArgs e)
        {
            float value = dxfReaderNETControl1.PlotPenWidth;
            if (value < 20) value += 1;
            dxfReaderNETControl1.PlotPenWidth = value;
            ribbonUpDownPlotPenWidth.TextBoxText = MathHelper.ToFormattedUnit(value);
        }

        private void ribbonUpDownPlotPenWidth_TextBoxKeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != decimalSeparetor))
            {
                e.Handled = true;
            }
        }

        private void ribbonUpDownPlotPenWidth_TextBoxValidated(object sender, EventArgs e)
        {
            dxfReaderNETControl1.PlotPenWidth = float.Parse(ribbonUpDownPlotPenWidth.TextBoxText, System.Globalization.CultureInfo.CurrentCulture);
        }

        private void ribbonButtonModifyCopyScale_Click(object sender, EventArgs e)
        {
            string inputValue = m_scale.ToString();
            if (ShowInputDialog(ref inputValue, "Scale factor", true) == DialogResult.OK)
            {
                m_scale = double.Parse(inputValue, System.Globalization.CultureInfo.CurrentCulture);

                if (m_scale != 1)
                {
                    CurrentFunction = FunctionsEnum.ScaleEntities;
                    CheckSnap();
                    StatusLabel.Text = "Select base point";
                }
            }
        }

        private void ribbonButton1SaveTest_Click(object sender, EventArgs e)
        {
            saveFileDialog1.DefaultExt = "dxf";
            saveFileDialog1.Filter = "DXF|*.dxf";
            saveFileDialog1.FileName = "";



            saveFileDialog1.InitialDirectory = CurrentSaveDXFPath;
            if (dxfReaderNETControl1.FileName == null)
            {
                saveFileDialog1.FileName = "drawing.dxf";
            }
            else
            {
                saveFileDialog1.FileName = dxfReaderNETControl1.FileName;
            }


            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {


                if (dxfReaderNETControl1.WriteDXF(saveFileDialog1.FileName, DXFReaderNET.Header.DxfVersion.AutoCad2013, dxfReaderNETControl1.DXF.IsBinary))
                {
                    StatusLabel.Text = "DXF file saved";
                }
                else
                {
                    StatusLabel.Text = "Error in saving DXF file";
                }
                CurrentSaveDXFPath = Path.GetDirectoryName(saveFileDialog1.FileName);
                AddMRU(saveFileDialog1.FileName);

                SaveRegistry();
            }
        }

        private void StatusLabelGrid_Click(object sender, EventArgs e)
        {
            dxfReaderNETControl1.ShowGrid = !dxfReaderNETControl1.ShowGrid;
            ribbonButtonShowgrid.Checked = dxfReaderNETControl1.ShowGrid;
            ShowStatusLabels();
            dxfReaderNETControl1.Refresh();


        }

        private void StatusLabelOrtho_Click(object sender, EventArgs e)
        {
            if (dxfReaderNETControl1.DXF.DrawingVariables.OrthoMode == 0)
            {
                dxfReaderNETControl1.DXF.DrawingVariables.OrthoMode = 1;
            }
            else
            {
                dxfReaderNETControl1.DXF.DrawingVariables.OrthoMode = 0;
            }
            ShowStatusLabels();
        }

        private void StatusLabelSnap_Click(object sender, EventArgs e)
        {
            dxfReaderNETControl1.DXF.VPorts["*Active"].SnapMode = !dxfReaderNETControl1.DXF.VPorts["*Active"].SnapMode;
            ShowStatusLabels();
        }

        private void ribbonComboBoxTextStyle_DropDownItemClicked(object sender, RibbonItemEventArgs e)
        {
            if (((RibbonComboBox)sender).SelectedItem.Text != "")
            {
                dxfReaderNETControl1.DXF.CurrentTextStyle = ((RibbonComboBox)sender).SelectedItem.Text.Trim();
            }
        }

        private void ribbonComboBoxLayout_DropDownItemClicked(object sender, RibbonItemEventArgs e)
        {
            if (((RibbonComboBox)sender).SelectedItem.Text != "")
            {
                dxfReaderNETControl1.DXF.ActiveLayout = ((RibbonComboBox)sender).SelectedItem.Text.Trim();
                dxfReaderNETControl1.Refresh();
                dxfReaderNETControl1.ZoomExtents();
            }
        }

        private void ribbonButtonDrawBlock_DropDownShowing(object sender, EventArgs e)
        {
            if (NumBlocks() == 0)
            {
                ribbonButtonDrawInsertBlock.Enabled = false;

            }
            else
            {
                ribbonButtonDrawInsertBlock.Enabled = true;

            }
        }

        private int NumBlocks()
        {
            int n = 0;
            foreach (DXFReaderNET.Blocks.Block _block in dxfReaderNETControl1.DXF.Blocks.Items)
            {
                if (_block.Entities.Count > 0 || _block.AttributeDefinitions.Count > 0)
                {
                    if (!_block.Name.StartsWith("*"))
                        n++;
                }
            }
            return n;
        }

        private void ribbonLabel6_Click(object sender, EventArgs e)
        {
            ribbonColorChooserForeColor_Click(sender, e);
        }

        private void ribbonButtonDrawEllipse_Click(object sender, EventArgs e)
        {
            StatusLabel.Text = "Select axis start point";
            CurrentFunction = FunctionsEnum.Ellipse1;
            CheckSnap();
        }

        private void ribbonButtonDrawHatchPatterns_Click(object sender, EventArgs e)
        {
            openFileDialog1.DefaultExt = "pat";
            openFileDialog1.Filter = "Hatch Pattern definition file|*.pat|All files (*.*)|*.*";
            openFileDialog1.FileName = "";

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                LoadPAT(openFileDialog1.FileName);

            }
        }
        private void LoadPAT(string PATfilename)
        {

            List<HatchPattern> patterns = new List<HatchPattern>();
            patterns.Clear();
            patterns = dxfReaderNETControl1.ReadHatchPatternsFromFile(PATfilename);

            foreach (HatchPattern pattern in patterns)
            {
                if (hatchPatternsCustom.Contains(pattern))
                {
                    hatchPatternsCustom.Remove(pattern);
                }
                hatchPatternsCustom.Add(pattern);
            }



        }

        private void Form1_Resize(object sender, EventArgs e)
        {
            labelCommands.Left = statusStrip1.Width / 2 - labelCommands.Width / 2;
            labelCommands.Top = statusStrip1.Top - labelCommands.Height;
        }

        private void ribbonButtonCommandLine_Click(object sender, EventArgs e)
        {
            labelCommands.Visible = ribbonButtonCommandLine.Checked;

        }
        private void ShowCommandLine()
        {
            if (labelCommands.Visible)
            {
                cmdCoord = "";
                switch (CurrentFunction)
                {

                    case FunctionsEnum.None:
                        labelCommands.Text = "";

                        break;
                    case FunctionsEnum.Line1:
                        labelCommands.Text = "LINE specify start point: ";
                        break;
                    case FunctionsEnum.Line2:
                        labelCommands.Text = "LINE specify end point: ";
                        break;
                }
            }
        }


        private void setPoint()
        {
            EntityObject ent = null;
            m_LastAddedEntity = null;

            switch (CurrentFunction)
            {

                case FunctionsEnum.RadialDimension2:

                    CurrentFunction = FunctionsEnum.None;
                    dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHair;
                    StatusLabel.Text = "";
                    switch (SelectedEntity.Type)
                    {
                        case EntityType.Arc:
                            m_LastAddedEntity = dxfReaderNETControl1.AddRadialDimension((Arc)SelectedEntity, p.ToVector3(), dxfReaderNETControl1.DXF.DrawingVariables.DimStyle, dxfReaderNETControl1.DXF.CurrentColor.Index);
                            break;
                        case EntityType.Circle:
                            m_LastAddedEntity = dxfReaderNETControl1.AddRadialDimension((Circle)SelectedEntity, p.ToVector3(), dxfReaderNETControl1.DXF.DrawingVariables.DimStyle, dxfReaderNETControl1.DXF.CurrentColor.Index);
                            break;
                    }


                    break;
                case FunctionsEnum.RadialDimension1:

                    StatusLabel.Text = "";
                    ent = dxfReaderNETControl1.GetEntity(p);
                    if (ent != null)
                    {
                        if (ent.Type == EntityType.Arc || ent.Type == EntityType.Circle)
                        {
                            SelectedEntity = ent;
                            StatusLabel.Text = "Select dimension position";
                            CurrentFunction = FunctionsEnum.RadialDimension2;
                        }
                        else
                        {
                            StatusLabel.Text = "Entity is not a circle or arc";
                        }

                    }
                    else
                    {
                        StatusLabel.Text = "No entity found";
                    }
                    break;

                case FunctionsEnum.DiametricDimension2:

                    CurrentFunction = FunctionsEnum.None;
                    dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHair;
                    StatusLabel.Text = "";
                    switch (SelectedEntity.Type)
                    {
                        case EntityType.Arc:
                            m_LastAddedEntity = dxfReaderNETControl1.AddDiametricDimension((Arc)SelectedEntity, p.ToVector3(), dxfReaderNETControl1.DXF.DrawingVariables.DimStyle, dxfReaderNETControl1.DXF.CurrentColor.Index);
                            break;
                        case EntityType.Circle:
                            m_LastAddedEntity = dxfReaderNETControl1.AddDiametricDimension((Circle)SelectedEntity, p.ToVector3(), dxfReaderNETControl1.DXF.DrawingVariables.DimStyle, dxfReaderNETControl1.DXF.CurrentColor.Index);
                            break;
                    }


                    break;
                case FunctionsEnum.DiametricDimension1:

                    StatusLabel.Text = "";
                    ent = dxfReaderNETControl1.GetEntity(p);
                    if (ent != null)
                    {
                        if (ent.Type == EntityType.Arc || ent.Type == EntityType.Circle)
                        {
                            SelectedEntity = ent;
                            StatusLabel.Text = "Select dimension position";
                            CurrentFunction = FunctionsEnum.DiametricDimension2;
                        }
                        else
                        {
                            StatusLabel.Text = "Entity is not a circle or arc";
                        }

                    }
                    else
                    {
                        StatusLabel.Text = "No entity found";
                    }
                    break;



                case FunctionsEnum.AngularDimensionCenterStartEnd4:
                    CurrentFunction = FunctionsEnum.None;
                    dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHair;
                    StatusLabel.Text = "";


                    m_LastAddedEntity = dxfReaderNETControl1.AddAngularDimension(p1.ToVector3(), p2.ToVector3(), p3.ToVector3(), p.ToVector3(), dxfReaderNETControl1.DXF.DrawingVariables.DimStyle, dxfReaderNETControl1.DXF.CurrentColor.Index);

                    break;

                case FunctionsEnum.AngularDimensionCenterStartEnd3:
                    dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHair;
                    CurrentFunction = FunctionsEnum.AngularDimensionCenterStartEnd4;
                    StatusLabel.Text = "Select dimension position";
                    p3 = p;
                    break;

                case FunctionsEnum.AngularDimensionCenterStartEnd2:
                    CurrentFunction = FunctionsEnum.AngularDimensionCenterStartEnd3;
                    StatusLabel.Text = "Select end point";
                    p2 = p;
                    break;

                case FunctionsEnum.AngularDimensionCenterStartEnd1:
                    CurrentFunction = FunctionsEnum.AngularDimensionCenterStartEnd2;
                    StatusLabel.Text = "Select start point";
                    p1 = p;
                    break;


                case FunctionsEnum.AngularDimensionArc2:
                    CurrentFunction = FunctionsEnum.None;
                    dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHair;
                    StatusLabel.Text = "";


                    m_LastAddedEntity = dxfReaderNETControl1.AddAngularDimension((Arc)SelectedEntity, p.ToVector3(), dxfReaderNETControl1.DXF.DrawingVariables.DimStyle, dxfReaderNETControl1.DXF.CurrentColor.Index);

                    break;

                case FunctionsEnum.AngularDimensionArc1:


                    SelectedLine = null;
                    SelectedLine1 = null;

                    StatusLabel.Text = "";
                    ent = dxfReaderNETControl1.GetEntity(p);
                    if (ent != null)
                    {
                        if (ent.Type == EntityType.Arc)
                        {
                            SelectedEntity = ent;
                            StatusLabel.Text = "Select dimension position";
                            CurrentFunction = FunctionsEnum.AngularDimensionArc2;
                        }
                        else
                        {
                            StatusLabel.Text = "Entity is not an arc";
                        }

                    }
                    else
                    {
                        StatusLabel.Text = "No entity found";
                    }
                    break;


                case FunctionsEnum.AngularDimension2Lines3:
                    CurrentFunction = FunctionsEnum.None;
                    dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHair;
                    StatusLabel.Text = "";


                    m_LastAddedEntity = dxfReaderNETControl1.AddAngularDimension(SelectedLine, SelectedLine1, p.ToVector3(), dxfReaderNETControl1.DXF.DrawingVariables.DimStyle, dxfReaderNETControl1.DXF.CurrentColor.Index);

                    break;
                case FunctionsEnum.AngularDimension2Lines2:


                    StatusLabel.Text = "";
                    ent = dxfReaderNETControl1.GetEntity(p);
                    if (ent != null)
                    {
                        if (ent.Type == EntityType.Line)

                        {
                            SelectedLine1 = (Line)ent;
                            StatusLabel.Text = "Select dimension position";
                            dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHair;
                            CurrentFunction = FunctionsEnum.AngularDimension2Lines3;
                        }
                        else
                        {
                            StatusLabel.Text = "Entity is not a line";
                        }


                    }
                    else
                    {
                        StatusLabel.Text = "No entity found";
                    }
                    break;

                case FunctionsEnum.AngularDimension2Lines1:


                    SelectedLine = null;
                    SelectedLine1 = null;

                    StatusLabel.Text = "";
                    ent = dxfReaderNETControl1.GetEntity(p);
                    if (ent != null)
                    {
                        if (ent.Type == EntityType.Line)
                        {
                            SelectedLine = (Line)ent;
                            StatusLabel.Text = "Select second line";
                            CurrentFunction = FunctionsEnum.AngularDimension2Lines2;
                        }
                        else
                        {
                            StatusLabel.Text = "Entity is not a line";
                        }

                    }
                    else
                    {
                        StatusLabel.Text = "No entity found";
                    }
                    break;


                case FunctionsEnum.LinearDimensionLine2:
                    CurrentFunction = FunctionsEnum.None;
                    dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHair;
                    StatusLabel.Text = "";
                    p2 = p;

                    double dimrotation = 0;
                    if (SelectedLine.StartPoint.X < SelectedLine.EndPoint.X)
                    {
                        if (p.X > SelectedLine.EndPoint.X || p.X < SelectedLine.StartPoint.X)
                        {
                            dimrotation = 90;
                        }

                    }
                    else
                    {
                        if (p.X < SelectedLine.EndPoint.X || p.X > SelectedLine.StartPoint.X)
                        {
                            dimrotation = 90;
                        }
                    }

                    m_LastAddedEntity = dxfReaderNETControl1.AddLinearDimension(SelectedLine, p.ToVector3(), dimrotation, dxfReaderNETControl1.DXF.DrawingVariables.DimStyle, dxfReaderNETControl1.DXF.CurrentColor.Index);

                    break;

                case FunctionsEnum.LinearDimensionLine1:

                    p1 = p;
                    dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHair;
                    StatusLabel.Text = "";
                    ent = dxfReaderNETControl1.GetEntity(p);
                    if (ent != null)
                    {
                        if (SelectLineFromEntity(ent))
                        {
                            StatusLabel.Text = "Select dimension position";
                            CurrentFunction = FunctionsEnum.LinearDimensionLine2;
                        }


                    }
                    else
                    {
                        StatusLabel.Text = "No entity found";
                    }
                    break;

                case FunctionsEnum.LinearDimension3:
                    CurrentFunction = FunctionsEnum.None;
                    dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHair;
                    StatusLabel.Text = "";
                    p3 = p;

                    dimrotation = 0;

                    if (p.X > p2.X || p.X < p1.X)
                    {
                        dimrotation = 90;

                    }

                    m_LastAddedEntity = dxfReaderNETControl1.AddLinearDimension(new Vector3(p1.X, p1.Y, dxfReaderNETControl1.DXF.CurrentElevation), new Vector3(p2.X, p2.Y, dxfReaderNETControl1.DXF.CurrentElevation), p.ToVector3(), dimrotation, dxfReaderNETControl1.DXF.DrawingVariables.DimStyle, dxfReaderNETControl1.DXF.CurrentColor.Index);

                    break;
                case FunctionsEnum.LinearDimension2:
                    CurrentFunction = FunctionsEnum.LinearDimension3;
                    dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHair;
                    StatusLabel.Text = "Select dimension position";
                    p2 = p;
                    break;

                case FunctionsEnum.LinearDimension1:
                    CurrentFunction = FunctionsEnum.LinearDimension2;
                    StatusLabel.Text = "Select end point";
                    p1 = p;
                    break;


                case FunctionsEnum.AlignedDimensionLine2:
                    CurrentFunction = FunctionsEnum.None;
                    dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHair;
                    StatusLabel.Text = "";
                    p2 = p;

                    m_LastAddedEntity = dxfReaderNETControl1.AddAlignedDimension(SelectedLine, p.ToVector3(), dxfReaderNETControl1.DXF.DrawingVariables.DimStyle, dxfReaderNETControl1.DXF.CurrentColor.Index);

                    break;

                case FunctionsEnum.AlignedDimensionLine1:

                    p1 = p;
                    dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHair;
                    StatusLabel.Text = "";
                    ent = dxfReaderNETControl1.GetEntity(p);
                    if (ent != null)
                    {
                        if (SelectLineFromEntity(ent))
                        {
                            StatusLabel.Text = "Select dimension position";
                            CurrentFunction = FunctionsEnum.AlignedDimensionLine2;
                        }


                    }
                    else
                    {
                        StatusLabel.Text = "No entity found";
                    }
                    break;


                case FunctionsEnum.AlignedDimension3:
                    CurrentFunction = FunctionsEnum.None;
                    dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHair;
                    StatusLabel.Text = "";
                    p3 = p;



                    m_LastAddedEntity = dxfReaderNETControl1.AddAlignedDimension(new Vector3(p1.X, p1.Y, dxfReaderNETControl1.DXF.CurrentElevation), new Vector3(p2.X, p2.Y, dxfReaderNETControl1.DXF.CurrentElevation), p.ToVector3(), dxfReaderNETControl1.DXF.DrawingVariables.DimStyle, dxfReaderNETControl1.DXF.CurrentColor.Index);

                    break;
                case FunctionsEnum.AlignedDimension2:
                    CurrentFunction = FunctionsEnum.AlignedDimension3;
                    dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHair;
                    StatusLabel.Text = "Select dimension position";
                    p2 = p;
                    break;

                case FunctionsEnum.AlignedDimension1:
                    CurrentFunction = FunctionsEnum.AlignedDimension2;
                    StatusLabel.Text = "Select end point";
                    p1 = p;
                    break;


                case FunctionsEnum.Text:
                    dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHair;
                    StatusLabel.Text = "";
                    CurrentFunction = FunctionsEnum.None;

                    p2 = p;
                    m_LastAddedEntity = dxfReaderNETControl1.AddText(m_Text, new Vector3(p2.X, p2.Y, dxfReaderNETControl1.DXF.CurrentElevation), new Vector3(p2.X, p2.Y, dxfReaderNETControl1.DXF.CurrentElevation), dxfReaderNETControl1.DXF.CurrentTextSize, 0, TextAlignment.BaselineLeft, dxfReaderNETControl1.DXF.CurrentTextStyle, dxfReaderNETControl1.DXF.CurrentColor.Index);

                    break;

                case FunctionsEnum.RotateAxis2:
                    dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHair;
                    StatusLabel.Text = "";
                    CurrentFunction = FunctionsEnum.None;
                    p2 = p;
                    double rotAngle = Vector2.Angle(p1, p2) * MathHelper.RadToDeg;
                    dxfReaderNETControl1.DXF.RotateEntitiesAboutAxis(dxfReaderNETControl1.DXF.SelectedEntities, rotAngle, p1.ToVector3(), p2.ToVector3());

                    dxfReaderNETControl1.Refresh();
                    dxfReaderNETControl1.DXF.SelectedEntities.Clear();
                    break;

                case FunctionsEnum.RotateAxis1:
                    CurrentFunction = FunctionsEnum.RotateAxis2;
                    StatusLabel.Text = "Select end point of the mirror axis";
                    p1 = p;
                    break;

                case FunctionsEnum.Insert:
                    CurrentFunction = FunctionsEnum.None;
                    dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHair;
                    StatusLabel.Text = "";
                    p2 = p;

                    m_LastAddedEntity = dxfReaderNETControl1.AddInsert(m_BlockName, new Vector3(p2.X, p2.Y, dxfReaderNETControl1.DXF.CurrentElevation), double.Parse(m_BlockRotation, System.Globalization.CultureInfo.CurrentCulture), new Vector3(double.Parse(m_BlockScale, System.Globalization.CultureInfo.CurrentCulture), double.Parse(m_BlockScale, System.Globalization.CultureInfo.CurrentCulture), double.Parse(m_BlockScale, System.Globalization.CultureInfo.CurrentCulture)));

                    break;
                case FunctionsEnum.Block:
                    CurrentFunction = FunctionsEnum.None;

                    StatusLabel.Text = "";

                    if (dxfReaderNETControl1.AddBlock(m_newBlockName, p.ToVector3(), dxfReaderNETControl1.DXF.SelectedEntities) != null)
                    {
                        StatusLabel.Text = "Block '" + m_newBlockName + "' created";
                        dxfReaderNETControl1.DXF.SelectedEntities.Clear();
                        dxfReaderNETControl1.Refresh();
                        m_newBlockName = "";
                    }
                    break;


                case FunctionsEnum.Offset2:
                    CurrentFunction = FunctionsEnum.None;

                    StatusLabel.Text = "";

                    if (dxfReaderNETControl1.Offset(m_entOffset, m_offset, p.ToVector3()) == null)
                    {
                        StatusLabel.Text = "The selected entity is not suitable for offset";
                    }

                    else
                    {

                        dxfReaderNETControl1.Refresh();
                    }

                    break;

                case FunctionsEnum.Offset1:
                    dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHair;
                    m_entOffset = dxfReaderNETControl1.GetEntity(p);
                    if (m_entOffset != null)
                    {

                        StatusLabel.Text = "Select offset position";
                        CurrentFunction = FunctionsEnum.Offset2;

                    }
                    else
                    {
                        StatusLabel.Text = "No entity found";
                    }
                    break;

                case FunctionsEnum.ExplodePoly:
                    CurrentFunction = FunctionsEnum.None;
                    dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHair;
                    StatusLabel.Text = "";
                    ent = dxfReaderNETControl1.GetEntity(p);
                    if (ent != null)
                    {
                        switch (ent.Type)
                        {
                            case EntityType.LightWeightPolyline:
                                List<EntityObject> newLines = new List<EntityObject>();
                                newLines = ((LwPolyline)ent).Explode();
                                int nLines = 0;
                                int nArcs = 0;
                                foreach (EntityObject lEnt in newLines)
                                {
                                    switch (lEnt.Type)
                                    {
                                        case EntityType.Line:
                                            nLines++;
                                            break;
                                        case EntityType.Arc:
                                            nArcs++;
                                            break;
                                    }

                                }
                                dxfReaderNETControl1.DXF.AddEntities(newLines);
                                dxfReaderNETControl1.DXF.RemoveEntity(ent);
                                dxfReaderNETControl1.Refresh();
                                StatusLabel.Text = "Light weight polyline entity exploded into " + nLines.ToString() + " new line(s) and " + nArcs.ToString() + " new arc(s)";
                                break;
                            case EntityType.Polyline:
                                newLines = new List<EntityObject>();
                                newLines = ((Polyline)ent).Explode();
                                nLines = 0;
                                nArcs = 0;
                                foreach (EntityObject lEnt in newLines)
                                {
                                    switch (lEnt.Type)
                                    {
                                        case EntityType.Line:
                                            nLines++;
                                            break;
                                        case EntityType.Arc:
                                            nArcs++;
                                            break;
                                    }

                                }
                                dxfReaderNETControl1.DXF.AddEntities(newLines);
                                dxfReaderNETControl1.DXF.RemoveEntity(ent);
                                dxfReaderNETControl1.Refresh();
                                StatusLabel.Text = "Polyline entity exploded into " + nLines.ToString() + " new line(s) and " + nArcs.ToString() + " new arc(s)";
                                break;
                            default:
                                StatusLabel.Text = "Selected entity is not a polyline or light weight polyline";
                                break;
                        }


                    }
                    break;
                case FunctionsEnum.ExplodeInsert:
                    CurrentFunction = FunctionsEnum.None;
                    dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHair;
                    StatusLabel.Text = "";
                    ent = dxfReaderNETControl1.GetEntity(p);
                    if (ent != null)
                    {
                        if (ent.Type == EntityType.Insert)
                        {
                            List<EntityObject> insertEntities = new List<EntityObject>();
                            insertEntities = ((Insert)ent).Explode();
                            dxfReaderNETControl1.DXF.AddEntities(insertEntities);
                            dxfReaderNETControl1.DXF.RemoveEntity(ent);
                            dxfReaderNETControl1.Refresh();
                            StatusLabel.Text = "Insert entity exploded into " + insertEntities.Count.ToString() + " new entities";
                        }
                        else
                        {
                            StatusLabel.Text = "Selected entity is not an insert";
                        }

                    }
                    else
                    {
                        StatusLabel.Text = "No entity found";
                    }
                    break;
                case FunctionsEnum.ExplodeSpline:
                    CurrentFunction = FunctionsEnum.None;
                    dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHair;
                    StatusLabel.Text = "";
                    ent = dxfReaderNETControl1.GetEntity(p);
                    if (ent != null)
                    {
                        if (ent.Type == EntityType.Spline)
                        {
                            List<EntityObject> insertEntities = new List<EntityObject>();

                            dxfReaderNETControl1.DXF.AddEntity(((Spline)ent).ToPolyline(((Spline)ent).ControlPoints.Count));
                            dxfReaderNETControl1.DXF.RemoveEntity(ent);
                            dxfReaderNETControl1.Refresh();
                            StatusLabel.Text = "Spline entity exploded into a new polyline";
                        }
                        else
                        {
                            StatusLabel.Text = "Selected entity is not a spline";
                        }

                    }
                    else
                    {
                        StatusLabel.Text = "No entity found";
                    }
                    break;
                case FunctionsEnum.ExplodeCircle:
                    CurrentFunction = FunctionsEnum.None;
                    dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHair;
                    StatusLabel.Text = "";
                    ent = dxfReaderNETControl1.GetEntity(p);
                    if (ent != null)
                    {
                        if (ent.Type == EntityType.Circle)
                        {
                            List<EntityObject> insertEntities = new List<EntityObject>();

                            dxfReaderNETControl1.DXF.AddEntity(((Circle)ent).ToPolyline(100));
                            dxfReaderNETControl1.DXF.RemoveEntity(ent);
                            dxfReaderNETControl1.Refresh();
                            StatusLabel.Text = "Circle entity exploded into a new light weight polyline";
                        }
                        else
                        {
                            StatusLabel.Text = "Selected entity is not a circle";
                        }

                    }
                    else
                    {
                        StatusLabel.Text = "No entity found";
                    }
                    break;
                case FunctionsEnum.ExplodeArc:
                    CurrentFunction = FunctionsEnum.None;
                    dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHair;
                    StatusLabel.Text = "";
                    ent = dxfReaderNETControl1.GetEntity(p);
                    if (ent != null)
                    {
                        if (ent.Type == EntityType.Arc)
                        {

                            dxfReaderNETControl1.DXF.AddEntity(((Arc)ent).ToPolyline(100));
                            dxfReaderNETControl1.DXF.RemoveEntity(ent);
                            dxfReaderNETControl1.Refresh();
                            StatusLabel.Text = "Arc entity exploded into a new light weight polyline";
                        }
                        else
                        {
                            StatusLabel.Text = "Selected entity is not an Arc";
                        }

                    }
                    else
                    {
                        StatusLabel.Text = "No entity found";
                    }
                    break;
                case FunctionsEnum.ExplodeEllipse:
                    CurrentFunction = FunctionsEnum.None;
                    dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHair;
                    StatusLabel.Text = "";
                    ent = dxfReaderNETControl1.GetEntity(p);
                    if (ent != null)
                    {
                        if (ent.Type == EntityType.Ellipse)
                        {

                            dxfReaderNETControl1.DXF.AddEntity(((Ellipse)ent).ToPolyline(100));
                            dxfReaderNETControl1.DXF.RemoveEntity(ent);
                            dxfReaderNETControl1.Refresh();
                            StatusLabel.Text = "Ellipse entity exploded into a new light weight polyline";
                        }
                        else
                        {
                            StatusLabel.Text = "Selected entity is not an ellipse";
                        }

                    }
                    else
                    {
                        StatusLabel.Text = "No entity found";
                    }
                    break;

                case FunctionsEnum.GradientHatch:
                case FunctionsEnum.Hatch:
                    ent = dxfReaderNETControl1.GetEntity(p);
                    if (ent != null)
                    {
                        if (ent.Type == EntityType.Circle || ent.Type == EntityType.LightWeightPolyline || ent.Type == EntityType.Line || ent.Type == EntityType.Arc || ent.Type == EntityType.Spline || ent.Type == EntityType.Ellipse)
                        {
                            Boundary.Add(ent);
                            dxfReaderNETControl1.HighLight(ent);
                        }
                    }
                    break;
                case FunctionsEnum.HatchOutermost:
                case FunctionsEnum.GradientHatchOutermost:
                    ent = dxfReaderNETControl1.GetEntity(p);
                    if (ent != null)
                    {
                        if (ent.Type == EntityType.Circle || ent.Type == EntityType.LightWeightPolyline || ent.Type == EntityType.Line || ent.Type == EntityType.Arc || ent.Type == EntityType.Spline || ent.Type == EntityType.Ellipse)
                        {
                            BoundaryOutermost.Add(ent);
                            dxfReaderNETControl1.HighLight(ent);
                        }
                    }
                    break;

                case FunctionsEnum.Ray2:
                    CurrentFunction = FunctionsEnum.None;
                    dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHair;
                    p2 = p;
                    StatusLabel.Text = "";
                    m_LastAddedEntity = dxfReaderNETControl1.AddRay(new Vector3(p1.X, p1.Y, dxfReaderNETControl1.DXF.CurrentElevation), new Vector3(p2.X - p1.X, p2.Y - p1.Y, dxfReaderNETControl1.DXF.CurrentElevation), dxfReaderNETControl1.DXF.CurrentColor.Index);

                    break;

                case FunctionsEnum.Ray1:
                    CurrentFunction = FunctionsEnum.Ray2;
                    StatusLabel.Text = "Select direction of ray";
                    p1 = p;
                    break;

                case FunctionsEnum.Xline2:
                    CurrentFunction = FunctionsEnum.None;
                    dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHair;
                    p2 = p;
                    StatusLabel.Text = "";
                    m_LastAddedEntity = dxfReaderNETControl1.AddXLine(new Vector3(p1.X, p1.Y, dxfReaderNETControl1.DXF.CurrentElevation), new Vector3(p2.X - p1.X, p2.Y - p1.Y, dxfReaderNETControl1.DXF.CurrentElevation), dxfReaderNETControl1.DXF.CurrentColor.Index);


                    break;

                case FunctionsEnum.Xline1:
                    CurrentFunction = FunctionsEnum.Xline2;
                    StatusLabel.Text = "Select direction of construction line";
                    p1 = p;
                    break;


                case FunctionsEnum.Circle3p3:
                    CurrentFunction = FunctionsEnum.None;
                    dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHair;
                    StatusLabel.Text = "";
                    p3 = p;
                    m_LastAddedEntity = dxfReaderNETControl1.AddCircle(new Vector3(p1.X, p1.Y, dxfReaderNETControl1.DXF.CurrentElevation), new Vector3(p2.X, p2.Y, dxfReaderNETControl1.DXF.CurrentElevation), new Vector3(p3.X, p3.Y, dxfReaderNETControl1.DXF.CurrentElevation), dxfReaderNETControl1.DXF.CurrentColor.Index);

                    break;
                case FunctionsEnum.Circle3p2:
                    CurrentFunction = FunctionsEnum.Circle3p3;
                    StatusLabel.Text = "Select third point";
                    p2 = p;
                    break;

                case FunctionsEnum.Circle3p1:
                    CurrentFunction = FunctionsEnum.Circle3p2;
                    StatusLabel.Text = "Select second point";
                    p1 = p;
                    break;

                case FunctionsEnum.Circle2:
                    CurrentFunction = FunctionsEnum.None;
                    dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHair;
                    StatusLabel.Text = "";
                    p2 = p;

                    m_LastAddedEntity = dxfReaderNETControl1.AddCircle(new Vector3(p1.X, p1.Y, dxfReaderNETControl1.DXF.CurrentElevation), Vector2.Distance(p1, p2), dxfReaderNETControl1.DXF.CurrentColor.Index);

                    break;

                case FunctionsEnum.Circle1:
                    CurrentFunction = FunctionsEnum.Circle2;
                    StatusLabel.Text = "Select radius";
                    p1 = p;
                    break;
                case FunctionsEnum.Line2:
                    CurrentFunction = FunctionsEnum.None;
                    dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHair;
                    StatusLabel.Text = "";
                    p2 = p;

                    m_LastAddedEntity = dxfReaderNETControl1.AddLine(new Vector3(p1.X, p1.Y, dxfReaderNETControl1.DXF.CurrentElevation), new Vector3(p2.X, p2.Y, dxfReaderNETControl1.DXF.CurrentElevation), dxfReaderNETControl1.DXF.CurrentColor.Index);

                    break;

                case FunctionsEnum.Line1:
                    CurrentFunction = FunctionsEnum.Line2;
                    StatusLabel.Text = "Select end point of the line";
                    p1 = p;
                    break;
                case FunctionsEnum.GradientHatchBoundaries:
                case FunctionsEnum.HatchBoundaries:
                case FunctionsEnum.Spline:
                case FunctionsEnum.Lines:
                case FunctionsEnum.Polyline:
                case FunctionsEnum.LwPolyline:
                case FunctionsEnum.PolylineLenght:
                case FunctionsEnum.Area:
                case FunctionsEnum.DrawPolygon:
                    vertexes.Add(p);
                    break;
                case FunctionsEnum.Radius:
                    StatusLabel.Text = "";
                    CurrentFunction = FunctionsEnum.None;
                    dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHair;
                    ent = dxfReaderNETControl1.GetEntity(p);
                    if (ent != null)
                    {
                        if (ent.Type == EntityType.Circle || ent.Type == EntityType.Arc)
                        {
                            if (ent.Type == EntityType.Circle)
                            {
                                StatusLabel.Text = "Radius: " + MathHelper.ToFormattedUnit(((Circle)ent).Radius);
                                StatusLabel.Text += " Diameter: " + MathHelper.ToFormattedUnit(((Circle)ent).Radius * 2);
                                StatusLabel.Text += " Area: " + MathHelper.ToFormattedUnit(((Circle)ent).Radius * ((Circle)ent).Radius * MathHelper.PI);

                            }
                            if (ent.Type == EntityType.Arc)
                            {
                                StatusLabel.Text = "Radius: " + MathHelper.ToFormattedUnit(((Arc)ent).Radius);
                                StatusLabel.Text += " Diameter: " + MathHelper.ToFormattedUnit(((Arc)ent).Radius * 2);
                                StatusLabel.Text += " Lenght: " + MathHelper.ToFormattedUnit(((Arc)ent).Lenght);

                            }

                        }
                        else
                        {
                            StatusLabel.Text = "Selected entity is not a circle or arc";
                        }
                    }
                    else
                    {
                        StatusLabel.Text = "No entity found";
                    }

                    break;
                case FunctionsEnum.Point:
                    CurrentFunction = FunctionsEnum.None;
                    dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHair;
                    StatusLabel.Text = "";
                    m_LastAddedEntity = dxfReaderNETControl1.AddPoint(new Vector3(p.X, p.Y, dxfReaderNETControl1.DXF.CurrentElevation), dxfReaderNETControl1.DXF.CurrentColor.Index);

                    break;
                case FunctionsEnum.LocatePoint:
                    CurrentFunction = FunctionsEnum.None;
                    dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHair;

                    StatusLabel.Text = "X: " + MathHelper.ToFormattedUnit(p.X);
                    StatusLabel.Text += " Y: " + MathHelper.ToFormattedUnit(p.Y);

                    break;
                case FunctionsEnum.GetGroupEntities:
                    StatusLabel.Text = "";
                    CurrentFunction = FunctionsEnum.None;
                    dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHair;
                    ent = dxfReaderNETControl1.GetEntity(screenP);

                    if (ent != null)
                    {
                        bool isPresent = false;
                        foreach (DXFReaderNET.Objects.Group _group in dxfReaderNETControl1.DXF.Groups)
                        {
                            if (_group.Entities.Contains(ent))
                            {
                                foreach (EntityObject _ent in _group.Entities)
                                {

                                    if (!dxfReaderNETControl1.DXF.SelectedEntities.Contains(_ent))
                                        dxfReaderNETControl1.DXF.SelectedEntities.Add(_ent);
                                    dxfReaderNETControl1.HighLight(_ent);

                                }
                                isPresent = true;

                            }
                            if (!isPresent)
                            {
                                StatusLabel.Text = "The selected entity is not part of a group";
                            }
                        }

                    }
                    else
                    {
                        StatusLabel.Text = "No entity found";
                    }
                    break;
                case FunctionsEnum.GetEntity:
                    StatusLabel.Text = "";
                    CurrentFunction = FunctionsEnum.None;
                    dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHair;
                    ent = dxfReaderNETControl1.GetEntity(screenP);
                    if (ent != null)
                    {
                        if (!dxfReaderNETControl1.DXF.SelectedEntities.Contains(ent))
                            dxfReaderNETControl1.DXF.SelectedEntities.Add(ent);
                        dxfReaderNETControl1.HighLight(ent);
                    }
                    else
                    {
                        StatusLabel.Text = "No entity found";
                    }
                    break;
                case FunctionsEnum.MoveEnt1:
                    StatusLabel.Text = "";
                    CurrentFunction = FunctionsEnum.None;
                    dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHair;
                    ent = dxfReaderNETControl1.GetEntity(screenP);
                    if (ent != null)
                    {

                        CurrentFunction = FunctionsEnum.MoveEnt2;
                        SelectedEntity = ent;
                        p1 = p;

                    }
                    else
                    {
                        StatusLabel.Text = "No entity found";
                    }
                    break;

                case FunctionsEnum.GetEntities:
                    ent = dxfReaderNETControl1.GetEntity(screenP);
                    if (ent != null)
                    {
                        if (!dxfReaderNETControl1.DXF.SelectedEntities.Contains(ent))
                            dxfReaderNETControl1.DXF.SelectedEntities.Add(ent);
                        dxfReaderNETControl1.HighLight(ent);
                    }


                    break;
                case FunctionsEnum.ListXdata:
                    StatusLabel.Text = "";
                    CurrentFunction = FunctionsEnum.None;
                    dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHair;
                    ent = dxfReaderNETControl1.GetEntity(screenP);
                    if (ent != null)
                    {
                        string strOutput = "";
                        foreach (DXFReaderNET.Tables.ApplicationRegistry appReg in dxfReaderNETControl1.DXF.ApplicationRegistries)
                        {
                            if (ent.XData.ContainsAppId(appReg.Name))
                            {
                                strOutput += "Registered Application Name: " + appReg.Name + System.Environment.NewLine;
                                foreach (XDataRecord xRec in ent.XData[appReg.Name].XDataRecord)
                                {

                                    strOutput += xRec.ToString() + System.Environment.NewLine;

                                }
                                strOutput += System.Environment.NewLine;
                            }
                        }

                        if (strOutput != "")
                        {
                            MessageBox.Show(strOutput, ent.CodeName + " " + ent.Handle + " - Extended Data");
                        }
                        else
                        {
                            StatusLabel.Text = "No extended data for entity present";
                        }
                    }
                    else
                    {
                        StatusLabel.Text = "No entity found";
                    }

                    break;
                case FunctionsEnum.EntityProperties:
                    StatusLabel.Text = "";
                    CurrentFunction = FunctionsEnum.None;
                    dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHair;
                    ent = dxfReaderNETControl1.GetEntity(screenP);
                    if (ent != null)
                    {
                        dxfReaderNETControl1.PropertiesDialogText = "Entity properties";
                        dxfReaderNETControl1.ShowProperties(ent);
                    }
                    else
                    {
                        StatusLabel.Text = "No entity found";
                    }

                    break;

                case FunctionsEnum.SetLimits1:
                    CurrentFunction = FunctionsEnum.SetLimits2;
                    StatusLabel.Text = "Select end point";
                    p1 = p;
                    break;
                case FunctionsEnum.SetLimits2:
                    p2 = p;
                    CurrentFunction = FunctionsEnum.None;
                    dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHair;
                    toolStripStatusLabelInfo.Text = "";
                    StatusLabel.Text = "";

                    dxfReaderNETControl1.SetLimits(p1, p2);
                    break;
                case FunctionsEnum.ZoomWindow2:
                    p2 = p;
                    CurrentFunction = FunctionsEnum.None;
                    dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHair;
                    toolStripStatusLabelInfo.Text = "";
                    StatusLabel.Text = "";
                    dxfReaderNETControl1.ZoomWindow(p1, p2);
                    break;
                case FunctionsEnum.ZoomWindow1:
                    CurrentFunction = FunctionsEnum.ZoomWindow2;
                    StatusLabel.Text = "Select end point of the window";
                    p1 = p;
                    break;


                case FunctionsEnum.PlotWindow2:
                    p2 = p;
                    CurrentFunction = FunctionsEnum.None;
                    dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHair;
                    toolStripStatusLabelInfo.Text = "";
                    StatusLabel.Text = "";
                    dxfReaderNETControl1.DXF.DrawingVariables.PLimMin = p1;
                    dxfReaderNETControl1.DXF.DrawingVariables.PLimMax = p2;

                    if (OnPlotPreview)
                    {
                        PlotPreview();
                    }
                    else
                    {
                        PlotDrawing();
                    }
                    break;
                case FunctionsEnum.PlotWindow1:
                    CurrentFunction = FunctionsEnum.PlotWindow2;
                    StatusLabel.Text = "Select end point of the ploting window";
                    p1 = p;
                    break;


                case FunctionsEnum.Pan2:
                    CurrentFunction = FunctionsEnum.None;
                    dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHair;
                    p2 = p;
                    toolStripStatusLabelInfo.Text = "";
                    dxfReaderNETControl1.Pan(p1, p2);
                    break;
                case FunctionsEnum.Pan1:
                    CurrentFunction = FunctionsEnum.Pan2;
                    StatusLabel.Text = "Select end point";
                    p1 = p;
                    break;
                case FunctionsEnum.Distance2:
                    CurrentFunction = FunctionsEnum.None;
                    dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHair;
                    p2 = p;
                    toolStripStatusLabelInfo.Text = "";


                    StatusLabel.Text = "Distance: " + MathHelper.ToFormattedUnit(DXFReaderNET.Vector2.Distance(p1, p2));
                    StatusLabel.Text += " Angle in XY Plane: " + MathHelper.ToFormattedAngle(DXFReaderNET.Vector2.Angle(p1, p2));

                    StatusLabel.Text += " Delta X: " + MathHelper.ToFormattedUnit(p2.X - p1.X);
                    StatusLabel.Text += " Delta Y: " + MathHelper.ToFormattedUnit(p2.Y - p1.Y);


                    break;
                case FunctionsEnum.Distance1:
                    CurrentFunction = FunctionsEnum.Distance2;
                    StatusLabel.Text = "Select end point";
                    p1 = p;
                    break;


                case FunctionsEnum.Rectangle2:
                    CurrentFunction = FunctionsEnum.None;
                    dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHair;
                    StatusLabel.Text = "";
                    p2 = p;
                    List<LwPolylineVertex> polyVertexes = new List<LwPolylineVertex>();
                    polyVertexes.Add(new LwPolylineVertex(p1.X, p1.Y));
                    polyVertexes.Add(new LwPolylineVertex(p1.X, p2.Y));
                    polyVertexes.Add(new LwPolylineVertex(p2.X, p2.Y));
                    polyVertexes.Add(new LwPolylineVertex(p2.X, p1.Y));

                    m_LastAddedEntity = dxfReaderNETControl1.AddLightWeightPolyline(polyVertexes, true, 0, dxfReaderNETControl1.DXF.CurrentColor.Index);

                    break;

                case FunctionsEnum.Rectangle1:
                    CurrentFunction = FunctionsEnum.Rectangle2;
                    StatusLabel.Text = "Select end corner of the rectangle";
                    p1 = p;
                    break;
                case FunctionsEnum.Trace2:
                    CurrentFunction = FunctionsEnum.None;
                    dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHair;
                    StatusLabel.Text = "";
                    p2 = p;

                    m_LastAddedEntity = dxfReaderNETControl1.AddTrace(new Vector3(p1.X, p1.Y, dxfReaderNETControl1.DXF.CurrentElevation), new Vector3(p2.X, p2.Y, dxfReaderNETControl1.DXF.CurrentElevation), dxfReaderNETControl1.DXF.CurrentColor.Index);

                    break;

                case FunctionsEnum.Trace1:
                    CurrentFunction = FunctionsEnum.Trace2;
                    StatusLabel.Text = "Select end point of the trace";
                    p1 = p;
                    break;


                case FunctionsEnum.Solid4:
                    CurrentFunction = FunctionsEnum.None;
                    dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHair;
                    StatusLabel.Text = "";
                    p4 = p;

                    m_LastAddedEntity = dxfReaderNETControl1.AddSolid(new Vector3(p1.X, p1.Y, dxfReaderNETControl1.DXF.CurrentElevation), new Vector3(p2.X, p2.Y, dxfReaderNETControl1.DXF.CurrentElevation), new Vector3(p4.X, p4.Y, dxfReaderNETControl1.DXF.CurrentElevation), new Vector3(p3.X, p3.Y, dxfReaderNETControl1.DXF.CurrentElevation), dxfReaderNETControl1.DXF.CurrentColor.Index);

                    break;
                case FunctionsEnum.Solid3:
                    CurrentFunction = FunctionsEnum.Solid4;
                    StatusLabel.Text = "Select fourth point or press right button to end";
                    p3 = p;
                    break;
                case FunctionsEnum.Solid2:
                    CurrentFunction = FunctionsEnum.Solid3;
                    StatusLabel.Text = "Select third point";
                    p2 = p;
                    break;
                case FunctionsEnum.Solid1:
                    CurrentFunction = FunctionsEnum.Solid2;
                    StatusLabel.Text = "Select second point";
                    p1 = p;
                    break;

                case FunctionsEnum.Polygon2:
                    CurrentFunction = FunctionsEnum.None;
                    dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHair;
                    StatusLabel.Text = "";
                    p2 = p;

                    m_LastAddedEntity = dxfReaderNETControl1.AddPolygon(new Vector3(p1.X, p1.Y, dxfReaderNETControl1.DXF.CurrentElevation), Vector2.Distance(p1, p2), PolygonSides, Vector2.Angle(p1, p2) * MathHelper.RadToDeg, dxfReaderNETControl1.DXF.CurrentColor.Index);

                    break;

                case FunctionsEnum.Polygon1:
                    CurrentFunction = FunctionsEnum.Polygon2;
                    StatusLabel.Text = "Select radius and rotation";
                    p1 = p;
                    break;

                case FunctionsEnum.ImageFixedSize:
                    CurrentFunction = FunctionsEnum.None;
                    dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHair;
                    StatusLabel.Text = "";
                    p2 = p;
                    m_LastAddedEntity = dxfReaderNETControl1.AddImage(m_ImageFileName, new Vector3(p2.X, p2.Y, dxfReaderNETControl1.DXF.CurrentElevation), m_ImageWidth, m_ImageHeight, double.Parse(m_ImageRotation, System.Globalization.CultureInfo.CurrentCulture), short.Parse(m_ImageTransparency, System.Globalization.CultureInfo.CurrentCulture), dxfReaderNETControl1.DXF.CurrentColor.Index);

                    break;

                case FunctionsEnum.Image2:
                    CurrentFunction = FunctionsEnum.None;
                    dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHair;
                    StatusLabel.Text = "";
                    p2 = p;
                    m_LastAddedEntity = dxfReaderNETControl1.AddImage(m_ImageFileName, new Vector3(p1.X, p1.Y, dxfReaderNETControl1.DXF.CurrentElevation), p2.X - p1.X, p2.Y - p1.Y, double.Parse(m_ImageRotation, System.Globalization.CultureInfo.CurrentCulture), short.Parse(m_ImageTransparency, System.Globalization.CultureInfo.CurrentCulture), dxfReaderNETControl1.DXF.CurrentColor.Index);
                    break;

                case FunctionsEnum.Image1:
                    CurrentFunction = FunctionsEnum.Image2;
                    StatusLabel.Text = "Select end corner of the image";
                    p1 = p;
                    break;


                case FunctionsEnum.PDFUnderlay:
                    CurrentFunction = FunctionsEnum.None;
                    dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHair;
                    StatusLabel.Text = "";
                    p1 = p;
                    double scale = double.Parse(m_PDFScale, System.Globalization.CultureInfo.CurrentCulture);
                    m_LastAddedEntity = dxfReaderNETControl1.AddPDFUnderlay(m_PDFFileName, new Vector3(p1.X, p1.Y, dxfReaderNETControl1.DXF.CurrentElevation), double.Parse(m_PDFRotation, System.Globalization.CultureInfo.CurrentCulture), new Vector3(scale, scale, 1), short.Parse(m_PDFTransparency, System.Globalization.CultureInfo.CurrentCulture), dxfReaderNETControl1.DXF.CurrentColor.Index);

                    break;

                case FunctionsEnum.Ellipse3:
                    CurrentFunction = FunctionsEnum.None;
                    dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHair;
                    StatusLabel.Text = "";
                    p3 = p;
                    Vector3 center = Vector2.MidPoint(p1, p2).ToVector3();
                    center.Z = dxfReaderNETControl1.DXF.CurrentElevation;
                    double rotation = Vector2.Angle(p1, p2) * MathHelper.RadToDeg;
                    double MajorAxis = Vector2.Distance(p1, p2);
                    //double MinorAxis = Vector2.Distance(center.ToVector2(), p3) * 2;
                    double MinorAxis = Vector2.Distance(Vector2.MidPoint(p1, p2), p);
                    if (MinorAxis > MajorAxis)
                    {
                        double b = MinorAxis;
                        MinorAxis = MajorAxis;
                        MajorAxis = b;
                        rotation += 90;
                    }
                    m_LastAddedEntity = dxfReaderNETControl1.AddEllipse(center, MajorAxis, MinorAxis, rotation, dxfReaderNETControl1.DXF.CurrentColor.Index);

                    break;

                case FunctionsEnum.Ellipse2:
                    CurrentFunction = FunctionsEnum.Ellipse3;
                    StatusLabel.Text = "Select other axis end point";
                    p2 = p;
                    break;

                case FunctionsEnum.Ellipse1:
                    CurrentFunction = FunctionsEnum.Ellipse2;
                    StatusLabel.Text = "Select axis end point";
                    p1 = p;
                    break;

                case FunctionsEnum.Circle2p2:
                    CurrentFunction = FunctionsEnum.None;
                    dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHair;
                    StatusLabel.Text = "";
                    p2 = p;
                    center = Vector2.MidPoint(p1, p2).ToVector3();
                    center.Z = dxfReaderNETControl1.DXF.CurrentElevation;
                    m_LastAddedEntity = dxfReaderNETControl1.AddCircle(center, Vector2.Distance(p1, p2) / 2, dxfReaderNETControl1.DXF.CurrentColor.Index);

                    break;

                case FunctionsEnum.Circle2p1:
                    CurrentFunction = FunctionsEnum.Circle2p2;
                    StatusLabel.Text = "Select diameter end point";
                    p1 = p;
                    break;

                case FunctionsEnum.DrawText:
                    dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHair;
                    StatusLabel.Text = "";
                    CurrentFunction = FunctionsEnum.None;

                    p1 = p;
                    dxfReaderNETControl1.DrawText(DrawPen, m_DrawText, p1, m_DrawTextHeight, 0, ribbonButtonDrawMethodsStore.Checked);

                    break;

                case FunctionsEnum.DrawLine2:
                    CurrentFunction = FunctionsEnum.None;
                    dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHair;
                    StatusLabel.Text = "";
                    p2 = p;

                    dxfReaderNETControl1.DrawLine(DrawPen, p1, p2, ribbonButtonDrawMethodsStore.Checked);


                    break;

                case FunctionsEnum.DrawLine1:
                    CurrentFunction = FunctionsEnum.DrawLine2;
                    StatusLabel.Text = "Select end point of the line";
                    p1 = p;
                    break;

                case FunctionsEnum.DrawCircle2:
                    CurrentFunction = FunctionsEnum.None;
                    dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHair;
                    StatusLabel.Text = "";
                    p2 = p;
                    dxfReaderNETControl1.DrawCircle(DrawPen, p1, Vector2.Distance(p1, p2), ribbonButtonDrawMethodsFill.Checked, ribbonButtonDrawMethodsStore.Checked);

                    break;

                case FunctionsEnum.DrawCircle1:
                    CurrentFunction = FunctionsEnum.DrawCircle2;
                    StatusLabel.Text = "Select radius";
                    p1 = p;
                    break;
                case FunctionsEnum.Arc3:
                    CurrentFunction = FunctionsEnum.None;
                    dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHair;
                    StatusLabel.Text = "";
                    p3 = p;
                    m_LastAddedEntity = dxfReaderNETControl1.AddArc(new Vector3(p1.X, p1.Y, dxfReaderNETControl1.DXF.CurrentElevation), Vector2.Distance(p1, p2), Vector2.Angle(p1, p2) * MathHelper.RadToDeg, Vector2.Angle(p1, p3) * MathHelper.RadToDeg, dxfReaderNETControl1.DXF.CurrentColor.Index);

                    break;
                case FunctionsEnum.Arc2:
                    CurrentFunction = FunctionsEnum.Arc3;
                    StatusLabel.Text = "Select end angle";
                    p2 = p;
                    break;

                case FunctionsEnum.Arc1:
                    CurrentFunction = FunctionsEnum.Arc2;
                    StatusLabel.Text = "Select start angle";
                    p1 = p;
                    break;

                case FunctionsEnum.ArcStartMiddleEnd3:
                    CurrentFunction = FunctionsEnum.None;
                    dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHair;
                    StatusLabel.Text = "";
                    p3 = p;
                    m_LastAddedEntity = dxfReaderNETControl1.AddArc(new Vector3(p1.X, p1.Y, dxfReaderNETControl1.DXF.CurrentElevation), new Vector3(p2.X, p2.Y, dxfReaderNETControl1.DXF.CurrentElevation), new Vector3(p3.X, p3.Y, dxfReaderNETControl1.DXF.CurrentElevation), dxfReaderNETControl1.DXF.CurrentColor.Index);

                    break;
                case FunctionsEnum.ArcStartMiddleEnd2:
                    CurrentFunction = FunctionsEnum.ArcStartMiddleEnd3;
                    StatusLabel.Text = "Select end point";
                    p2 = p;
                    break;

                case FunctionsEnum.ArcStartMiddleEnd1:
                    CurrentFunction = FunctionsEnum.ArcStartMiddleEnd2;
                    StatusLabel.Text = "Select middle point";
                    p1 = p;
                    break;

                case FunctionsEnum.DrawArc3:
                    CurrentFunction = FunctionsEnum.None;
                    dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHair;
                    StatusLabel.Text = "";
                    p3 = p;

                    dxfReaderNETControl1.DrawArc(DrawPen, p1, Vector2.Distance(p1, p2), Vector2.Angle(p1, p2) * MathHelper.RadToDeg, Vector2.Angle(p1, p3) * MathHelper.RadToDeg, ribbonButtonDrawMethodsStore.Checked);

                    break;
                case FunctionsEnum.DrawArc2:
                    CurrentFunction = FunctionsEnum.DrawArc3;
                    StatusLabel.Text = "Select end angle";
                    p2 = p;
                    break;

                case FunctionsEnum.DrawArc1:
                    CurrentFunction = FunctionsEnum.DrawArc2;
                    StatusLabel.Text = "Select start angle";
                    p1 = p;
                    break;
                case FunctionsEnum.DrawPoint:
                    CurrentFunction = FunctionsEnum.None;
                    dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHair;
                    StatusLabel.Text = "";
                    p1 = p;
                    dxfReaderNETControl1.DrawPoint(DrawPen, p1, ribbonButtonDrawMethodsStore.Checked);
                    break;

                case FunctionsEnum.DrawImageFixedSize:
                    CurrentFunction = FunctionsEnum.None;
                    dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHair;
                    StatusLabel.Text = "";
                    p2 = p;
                    dxfReaderNETControl1.DrawImage(System.Drawing.Image.FromFile(m_ImageFileName), new Vector2(p2.X, p2.Y), m_ImageWidth, m_ImageHeight, float.Parse(m_ImageRotation, System.Globalization.CultureInfo.CurrentCulture), short.Parse(m_ImageTransparency, System.Globalization.CultureInfo.CurrentCulture), ribbonButtonDrawMethodsStore.Checked);

                    break;


                case FunctionsEnum.DrawImage2:
                    CurrentFunction = FunctionsEnum.None;
                    dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHair;
                    StatusLabel.Text = "";
                    p2 = p;

                    dxfReaderNETControl1.DrawImage(System.Drawing.Image.FromFile(m_ImageFileName), new Vector2(p1.X, p1.Y), (float)(p2.X - p1.X), (float)(p2.Y - p1.Y), float.Parse(m_ImageRotation, System.Globalization.CultureInfo.CurrentCulture), short.Parse(m_ImageTransparency, System.Globalization.CultureInfo.CurrentCulture), ribbonButtonDrawMethodsStore.Checked);
                    break;

                case FunctionsEnum.DrawImage1:
                    CurrentFunction = FunctionsEnum.DrawImage2;
                    StatusLabel.Text = "Select end corner of the image";
                    p1 = p;
                    break;


                case FunctionsEnum.GetEntities2:
                    CurrentFunction = FunctionsEnum.None;
                    dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHair;
                    StatusLabel.Text = "";
                    p2 = p;

                    foreach (EntityObject entity in dxfReaderNETControl1.GetEntities(p1, p2))
                    {

                        if (!dxfReaderNETControl1.DXF.SelectedEntities.Contains(entity))
                        {
                            dxfReaderNETControl1.DXF.SelectedEntities.Add(entity);
                        }
                    }


                    dxfReaderNETControl1.HighLight(dxfReaderNETControl1.DXF.SelectedEntities);

                    break;



                case FunctionsEnum.GetEntities1:
                    CurrentFunction = FunctionsEnum.GetEntities2;
                    StatusLabel.Text = "Select end point of selection rectangle";
                    p1 = p;
                    break;


                case FunctionsEnum.ExplodeSplineRect2:
                    CurrentFunction = FunctionsEnum.None;
                    dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHair;
                    StatusLabel.Text = "";
                    p2 = p;
                    long n_splines = 0;
                    foreach (EntityObject myEnt in dxfReaderNETControl1.GetEntities(p1, p2))


                    {
                        if (myEnt.Type == EntityType.Spline)
                        {

                            dxfReaderNETControl1.DXF.AddEntity(((Spline)myEnt).ToPolyline(((Spline)myEnt).ControlPoints.Count));
                            dxfReaderNETControl1.DXF.RemoveEntity(myEnt);
                            n_splines++;
                        }

                    }

                    dxfReaderNETControl1.Refresh();
                    StatusLabel.Text = n_splines.ToString() + " spline entities exploded into  new polylines";
                    break;

                case FunctionsEnum.ExplodeSplineRect1:
                    CurrentFunction = FunctionsEnum.ExplodeSplineRect2;
                    StatusLabel.Text = "Select end point of selection rectangle";
                    p1 = p;
                    break;
                case FunctionsEnum.MoveEntitiesRubber3:


                    CurrentFunction = FunctionsEnum.None;
                    dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHair;
                    p3 = p;


                    dxfReaderNETControl1.DXF.ModifyEntities(dxfReaderNETControl1.DXF.SelectedEntities, p1, p3 - p2);
                    dxfReaderNETControl1.Refresh();
                    dxfReaderNETControl1.DXF.SelectedEntities.Clear();

                    break;
                case FunctionsEnum.MoveEntitiesRubber2:
                    CurrentFunction = FunctionsEnum.MoveEntitiesRubber3;
                    p2 = p;
                    StatusLabel.Text = "Select traslation point";


                    foreach (EntityObject entity in dxfReaderNETControl1.GetEntities(p1, p2))
                    {

                        if (!dxfReaderNETControl1.DXF.SelectedEntities.Contains(entity))
                        {
                            dxfReaderNETControl1.DXF.SelectedEntities.Add(entity);
                        }
                    }

                    break;

                case FunctionsEnum.MoveEntitiesRubber1:
                    CurrentFunction = FunctionsEnum.MoveEntitiesRubber2;
                    StatusLabel.Text = "Select end point of selection rectangle";
                    p1 = p;
                    break;

                case FunctionsEnum.CopyEntities2:
                    CurrentFunction = FunctionsEnum.None;
                    dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHair;
                    StatusLabel.Text = "";
                    p2 = p;
                    List<EntityObject> newEntities = new List<EntityObject>();
                    foreach (EntityObject entity in dxfReaderNETControl1.DXF.SelectedEntities)
                    {
                        newEntities.Add((EntityObject)entity.Clone());
                    }


                    dxfReaderNETControl1.DXF.ModifyEntities(newEntities, p1, p2 - p1);
                    dxfReaderNETControl1.DXF.AddEntities(newEntities);
                    dxfReaderNETControl1.Refresh();
                    dxfReaderNETControl1.DXF.SelectedEntities.Clear();

                    break;

                case FunctionsEnum.CopyEntities1:
                    CurrentFunction = FunctionsEnum.CopyEntities2;
                    StatusLabel.Text = "Select translation point";
                    p1 = p;
                    break;


                case FunctionsEnum.MoveEnt2:

                    CurrentFunction = FunctionsEnum.None;
                    dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHair;
                    StatusLabel.Text = "";
                    p2 = p;

                    dxfReaderNETControl1.DXF.ModifyEntity(ref SelectedEntity, p1, p2 - p1);


                    dxfReaderNETControl1.Refresh();

                    SelectedEntity = null;
                    break;

                case FunctionsEnum.MoveEntities2:
                    CurrentFunction = FunctionsEnum.None;
                    dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHair;
                    StatusLabel.Text = "";
                    p2 = p;

                    dxfReaderNETControl1.DXF.ModifyEntities(dxfReaderNETControl1.DXF.SelectedEntities, p1, p2 - p1);

                    dxfReaderNETControl1.Refresh();
                    dxfReaderNETControl1.DXF.SelectedEntities.Clear();

                    break;

                case FunctionsEnum.MoveEntities1:
                    CurrentFunction = FunctionsEnum.MoveEntities2;
                    StatusLabel.Text = "Select translation point";
                    p1 = p;
                    break;

                case FunctionsEnum.RotateEntities:
                    CurrentFunction = FunctionsEnum.None;
                    dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHair;
                    StatusLabel.Text = "";
                    p1 = p;

                    dxfReaderNETControl1.DXF.ModifyEntities(dxfReaderNETControl1.DXF.SelectedEntities, p1, Vector2.Zero, 1, m_rotation);

                    dxfReaderNETControl1.Refresh();
                    dxfReaderNETControl1.DXF.SelectedEntities.Clear();

                    break;
                case FunctionsEnum.ScaleEntities:
                    CurrentFunction = FunctionsEnum.None;
                    dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHair;
                    StatusLabel.Text = "";
                    p1 = p;

                    dxfReaderNETControl1.DXF.ModifyEntities(dxfReaderNETControl1.DXF.SelectedEntities, p1, Vector2.Zero, m_scale, 0);

                    dxfReaderNETControl1.Refresh();
                    dxfReaderNETControl1.DXF.SelectedEntities.Clear();

                    break;


            }
        }

        private void ribbonButtonModPropColor_Click(object sender, EventArgs e)
        {
            AciColor newColor = new AciColor();
            AciColor oldColor = new AciColor();
            if (dxfReaderNETControl1.DXF.SelectedEntities.Count == 1)
            {
                oldColor = dxfReaderNETControl1.DXF.SelectedEntities[0].Color;
            }
            newColor = dxfReaderNETControl1.ShowPalette(oldColor);
            if (oldColor != newColor)
            {
                foreach (EntityObject ent in dxfReaderNETControl1.DXF.SelectedEntities)
                {
                    ent.Color = newColor;


                }
                dxfReaderNETControl1.Refresh();
                dxfReaderNETControl1.DXF.SelectedEntities.Clear();
            }
        }

        private void ribbonButtonModifyProperties_DropDownShowing(object sender, EventArgs e)
        {
            if (dxfReaderNETControl1.DXF.SelectedEntities.Count == 0)
            {
                ribbonButtonModPropColor.Enabled = false;
                ribbonButtonModPropLayer.Enabled = false;
                ribbonButtonModPropLineType.Enabled = false;
                ribbonButtonModPropGroup.Enabled = false;
            }
            else
            {
                ribbonButtonModPropColor.Enabled = true;
                ribbonButtonModPropLayer.Enabled = true;
                ribbonButtonModPropLineType.Enabled = true;
                ribbonButtonModPropGroup.Enabled = true;

            }
        }

        private void ribbonButtonModPropLayer_DropDownItemClicked(object sender, RibbonItemEventArgs e)
        {
            string newLayer = e.Item.Text;
            DXFReaderNET.Tables.Layer layer = dxfReaderNETControl1.DXF.Layers[newLayer];
            foreach (EntityObject ent in dxfReaderNETControl1.DXF.SelectedEntities)
            {

                ent.Layer = layer;


            }
            dxfReaderNETControl1.Refresh();
            dxfReaderNETControl1.DXF.SelectedEntities.Clear();
        }

        private void ribbonButtonModPropLayer_DropDownShowing(object sender, EventArgs e)
        {
            if (dxfReaderNETControl1.DXF.SelectedEntities.Count == 1)
            {

                foreach (RibbonButton layeItem in ribbonButtonModPropLayer.DropDownItems)
                {
                    layeItem.Checked = false;
                    if (layeItem.Text == dxfReaderNETControl1.DXF.SelectedEntities[0].Layer.Name)
                    {
                        layeItem.Checked = true;
                    }


                }
            }
        }

        private void ribbonButtonModPropLineType_DropDownShowing(object sender, EventArgs e)
        {
            if (dxfReaderNETControl1.DXF.SelectedEntities.Count == 1)
            {

                foreach (RibbonButton ltineItem in ribbonButtonModPropLineType.DropDownItems)
                {
                    ltineItem.Checked = false;
                    if (ltineItem.Text == dxfReaderNETControl1.DXF.SelectedEntities[0].Linetype.Name)
                    {
                        ltineItem.Checked = true;
                    }


                }
            }
        }

        private void ribbonButtonModPropLineType_DropDownItemClicked(object sender, RibbonItemEventArgs e)
        {
            string newLtype = e.Item.Text;
            DXFReaderNET.Tables.Linetype ltype = dxfReaderNETControl1.DXF.Linetypes[newLtype];
            foreach (EntityObject ent in dxfReaderNETControl1.DXF.SelectedEntities)
            {

                ent.Linetype = ltype;


            }
            dxfReaderNETControl1.Refresh();
            dxfReaderNETControl1.DXF.SelectedEntities.Clear();
        }

        private void dxfReaderNETControl1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                pstart = dxfReaderNETControl1.CurrentWCSpoint;
            }
        }

        private void ribbonButtonInquiryXdata_Click(object sender, EventArgs e)
        {
            CurrentFunction = FunctionsEnum.ListXdata;
            dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHairSquareQuestionMark;
            StatusLabel.Text = "Select entity";
        }

        private void dxfReaderNETControl1_DrawingStatus(object sender, DrawingStatusEventArgs e)
        {
            toolStripProgressBar1.Value = e.Progress;
        }

        private void dxfReaderNETControl1_ReadStatus(object sender, ReadStatusEventArgs e)
        {
            toolStripProgressBar1.Value = e.Progress;
        }

        private void dxfReaderNETControl1_StartPlot(object sender, StartPlotEventArgs e)
        {
            StatusLabel.Text = "Plotting DXF file...";
            Application.DoEvents();
        }

        private void dxfReaderNETControl1_EndPlot(object sender, EndPlotEventArgs e)
        {
            toolStripProgressBar1.Value = 0;
            StatusLabel.Text = "DXF file plottted";
            Application.DoEvents();
        }

        private void dxfReaderNETControl1_PlotStatus(object sender, PlotStatusEventArgs e)
        {
            toolStripProgressBar1.Value = e.Progress;
        }

        private void dxfReaderNETControl1_StartWrite(object sender, StartWriteEventArgs e)
        {
            StatusLabel.Text = "Saving DXF file...";
            Application.DoEvents();
        }

        private void dxfReaderNETControl1_EndWrite(object sender, EndWriteEventArgs e)
        {
            toolStripProgressBar1.Value = 0;
            StatusLabel.Text = "DXF file saved";
            Application.DoEvents();
        }

        private void dxfReaderNETControl1_WriteStatus(object sender, WriteStatusEventArgs e)
        {
            toolStripProgressBar1.Value = e.Progress;
        }

        private void dxfReaderNETControl1_StartDrawing(object sender, StartDrawingEventArgs e)
        {
            StatusLabel.Text = "Drawing DXF file...";
            Application.DoEvents();
        }

        private void dxfReaderNETControl1_StartRead(object sender, StartReadEventArgs e)
        {
            StatusLabel.Text = "Loading DXF file...";
            Application.DoEvents();
        }

        private void dxfReaderNETControl1_Error(object sender, DXFReaderNET.ErrorEventArgs e)
        {
            if (e.ErrorCode != 0)
            {
                
                MessageBox.Show("Error: " + e.ErrorCode.ToString() + " - " + e.ErrorString, "DXFReader.NET Demo Program", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void ribbonButtonModPropGroup_DropDownItemClicked(object sender, RibbonItemEventArgs e)
        {
            string inputValue = "";
            if (ShowInputDialog(ref inputValue, "New group name", false) == DialogResult.OK)
            {
                if (inputValue != "")
                {
                    bool isPresent = false;
                    foreach (DXFReaderNET.Objects.Group _group in dxfReaderNETControl1.DXF.Groups)
                    {
                        if (_group.Name.Trim().ToLower() == inputValue.Trim().ToLower())
                        {
                            isPresent = true;
                            break;
                        }
                    }
                    if (!isPresent)
                    {
                        DXFReaderNET.Objects.Group newGgroup = new DXFReaderNET.Objects.Group(inputValue);

                        foreach (EntityObject ent in dxfReaderNETControl1.DXF.SelectedEntities)
                        {

                            newGgroup.Entities.Add(ent);

                        }
                        dxfReaderNETControl1.DXF.Groups.Add(newGgroup);
                        RibbonButton newItem = new RibbonButton();
                        newItem.Text = inputValue;
                        ribbonButtonModPropGroup.DropDownItems.Add(newItem);
                    }

                }
            }
        }

        private void ribbonButtonModifySelectGroup_Click(object sender, EventArgs e)
        {
            CurrentFunction = FunctionsEnum.GetGroupEntities;
            dxfReaderNETControl1.CustomCursor = CustomCursorType.CrossHairSquare;
            StatusLabel.Text = "Select an entity of a group";
        }

        private void ribbonButtonModPropGroup_DropDownShowing(object sender, EventArgs e)
        {

        }
    }
}

